fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:base_stone_overworld
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:dirt
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:leaves
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:logs
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:sand
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:terracotta
fill ~ ~0 ~ ~ ~3 ~ air replace gravel
fill ~ ~0 ~ ~ ~3 ~ air replace snow_block
fill ~ ~0 ~ ~ ~3 ~ air replace clay
fill ~ ~0 ~ ~ ~3 ~ air replace sandstone
fill ~ ~0 ~ ~ ~3 ~ air replace red_sandstone
fill ~ ~0 ~ ~ ~3 ~ air replace ice
fill ~ ~0 ~ ~ ~3 ~ air replace packed_ice
fill ~ ~0 ~ ~ ~3 ~ air replace calcite
fill ~ ~0 ~ ~ ~3 ~ air replace short_grass
fill ~ ~0 ~ ~ ~3 ~ air replace tall_grass
fill ~ ~0 ~ ~ ~3 ~ air replace fern
fill ~ ~0 ~ ~ ~3 ~ air replace large_fern
fill ~ ~0 ~ ~ ~3 ~ air replace #minecraft:flowers
fill ~ ~0 ~ ~ ~3 ~ air replace snow
fill ~ ~0 ~ ~ ~3 ~ air replace vine
fill ~ ~0 ~ ~ ~3 ~ air replace sugar_cane
fill ~ ~0 ~ ~ ~3 ~ air replace bamboo
fill ~ ~0 ~ ~ ~3 ~ air replace sweet_berry_bush
fill ~ ~0 ~ ~ ~3 ~ air replace dead_bush
fill ~ ~0 ~ ~ ~3 ~ air replace glow_lichen
$fill ~-$(ox) ~-1 ~-$(oz) ~$(ox) ~-1 ~$(oz) $(bed)
$setblock ~ ~ ~ rail[shape=$(down)]
execute if block ~ ~2 ~ air run setblock ~ ~2 ~ light[level=15]
$execute if block ~$(ox) ~0 ~$(oz) #minecraft:replaceable unless block ~$(ox) ~0 ~$(oz) light run setblock ~$(ox) ~0 ~$(oz) $(fence)
$execute if block ~-$(ox) ~0 ~-$(oz) #minecraft:replaceable unless block ~-$(ox) ~0 ~-$(oz) light run setblock ~-$(ox) ~0 ~-$(oz) $(fence)
$tp @s ~$(dx) ~-1 ~$(dz)
scoreboard players add #dy rieles 1
scoreboard players remove #ady rieles 1
