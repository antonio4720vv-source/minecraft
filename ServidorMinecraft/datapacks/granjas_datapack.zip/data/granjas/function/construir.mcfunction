execute unless entity @e[type=minecraft:marker,tag=granjas_hub,limit=1] run tellraw @s {"text":"Primero usa /function granjas:aplanar","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] run function granjas:_construir
