tellraw @a {"text":"Construyendo plaza, fuente y portal del End...","color":"yellow"}
tp @a[distance=..14] ~ ~1 ~18
fill ~-14 ~-1 ~-14 ~14 ~-1 ~14 polished_andesite
fill ~-1 ~-1 ~-42 ~1 ~-1 ~-15 stone_bricks
fill ~-1 ~-1 ~15 ~1 ~-1 ~43 stone_bricks
fill ~15 ~-1 ~-1 ~54 ~-1 ~1 stone_bricks
fill ~-48 ~-1 ~-1 ~-15 ~-1 ~1 stone_bricks
function granjas:_fuente
execute positioned ~28 ~ ~-25 run function granjas:_portal_end
