tellraw @a {"text":"[Fase 1] Limpiando (2/2)...","color":"yellow"}
fill ~-2 ~30 ~-4 ~33 ~44 ~26 air
fill ~34 ~30 ~-4 ~69 ~44 ~26 air
fill ~70 ~30 ~-4 ~70 ~44 ~26 air
fill ~-2 ~45 ~-4 ~33 ~61 ~26 air
fill ~34 ~45 ~-4 ~69 ~61 ~26 air
fill ~70 ~45 ~-4 ~70 ~61 ~26 air
fill ~-2 ~-1 ~-4 ~33 ~-1 ~26 grass_block
fill ~34 ~-1 ~-4 ~69 ~-1 ~26 grass_block
fill ~70 ~-1 ~-4 ~70 ~-1 ~26 grass_block
fill ~-2 ~-4 ~-4 ~33 ~-2 ~26 dirt
fill ~34 ~-4 ~-4 ~69 ~-2 ~26 dirt
fill ~70 ~-4 ~-4 ~70 ~-2 ~26 dirt
fill ~-2 ~-1 ~ ~70 ~-1 ~2 stone_bricks
fill ~ ~-1 ~-4 ~2 ~-1 ~26 stone_bricks
setblock ~-2 ~ ~ lantern
setblock ~6 ~ ~ lantern
setblock ~14 ~ ~ lantern
setblock ~22 ~ ~ lantern
setblock ~30 ~ ~ lantern
setblock ~38 ~ ~ lantern
setblock ~46 ~ ~ lantern
setblock ~54 ~ ~ lantern
setblock ~62 ~ ~ lantern
kill @e[type=minecraft:item,distance=..120]
