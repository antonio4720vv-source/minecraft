execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega9b
schedule function granjas:_mega10 4s replace
