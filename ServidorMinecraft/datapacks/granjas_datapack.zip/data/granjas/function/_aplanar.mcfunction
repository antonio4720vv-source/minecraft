kill @e[type=minecraft:marker,tag=granjas_hub]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_hub"]}
forceload add ~-58 ~-40 ~64 ~22
tellraw @s {"text":"Aplanando un terreno de 110 x 60 bloques alrededor tuyo... (espera 5 segundos)","color":"yellow"}
schedule function granjas:_aplanar2 5s replace
