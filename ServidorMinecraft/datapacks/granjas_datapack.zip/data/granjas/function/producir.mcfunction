schedule function granjas:producir 30s replace
execute if score #on granjas matches 1 run function granjas:_producir
