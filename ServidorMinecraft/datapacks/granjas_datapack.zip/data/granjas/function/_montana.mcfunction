tellraw @s {"text":"Construyendo MONTANA con la casa grande encima (unos 60x60 bloques)...","color":"yellow"}
fill ~-30 ~ ~-32 ~ ~11 ~ air
fill ~-30 ~12 ~-32 ~ ~23 ~ air
fill ~-30 ~ ~1 ~ ~11 ~30 air
fill ~-30 ~12 ~1 ~ ~23 ~30 air
fill ~1 ~ ~-32 ~30 ~11 ~ air
fill ~1 ~12 ~-32 ~30 ~23 ~ air
fill ~1 ~ ~1 ~30 ~11 ~30 air
fill ~1 ~12 ~1 ~30 ~23 ~30 air
fill ~-3 ~ ~-25 ~3 ~ ~-25 grass_block
fill ~-7 ~ ~-24 ~7 ~ ~-24 grass_block
fill ~-10 ~ ~-23 ~10 ~ ~-23 grass_block
fill ~-12 ~ ~-22 ~12 ~ ~-22 grass_block
fill ~-13 ~ ~-21 ~13 ~ ~-21 grass_block
fill ~-15 ~ ~-20 ~15 ~ ~-20 grass_block
fill ~-16 ~ ~-19 ~16 ~ ~-19 grass_block
fill ~-17 ~ ~-18 ~17 ~ ~-18 grass_block
fill ~-18 ~ ~-17 ~18 ~ ~-17 grass_block
fill ~-19 ~ ~-16 ~19 ~ ~-16 grass_block
fill ~-20 ~ ~-15 ~20 ~ ~-15 grass_block
fill ~-20 ~ ~-14 ~20 ~ ~-14 grass_block
fill ~-21 ~ ~-13 ~21 ~ ~-13 grass_block
fill ~-22 ~ ~-12 ~22 ~ ~-12 grass_block
fill ~-22 ~ ~-11 ~22 ~ ~-11 grass_block
fill ~-23 ~ ~-10 ~23 ~ ~-10 grass_block
fill ~-23 ~ ~-9 ~23 ~ ~-9 grass_block
fill ~-23 ~ ~-8 ~23 ~ ~-8 grass_block
fill ~-24 ~ ~-7 ~24 ~ ~-7 grass_block
fill ~-24 ~ ~-6 ~24 ~ ~-6 grass_block
fill ~-24 ~ ~-5 ~24 ~ ~-5 grass_block
fill ~-24 ~ ~-4 ~24 ~ ~-4 grass_block
fill ~-25 ~ ~-3 ~25 ~ ~-3 grass_block
fill ~-25 ~ ~-2 ~25 ~ ~-2 grass_block
fill ~-25 ~ ~-1 ~25 ~ ~-1 grass_block
fill ~-25 ~ ~ ~25 ~ ~ grass_block
fill ~-25 ~ ~1 ~25 ~ ~1 grass_block
fill ~-25 ~ ~2 ~25 ~ ~2 grass_block
fill ~-25 ~ ~3 ~25 ~ ~3 grass_block
fill ~-24 ~ ~4 ~24 ~ ~4 grass_block
fill ~-24 ~ ~5 ~24 ~ ~5 grass_block
fill ~-24 ~ ~6 ~24 ~ ~6 grass_block
fill ~-24 ~ ~7 ~24 ~ ~7 grass_block
fill ~-23 ~ ~8 ~23 ~ ~8 grass_block
fill ~-23 ~ ~9 ~23 ~ ~9 grass_block
fill ~-23 ~ ~10 ~23 ~ ~10 grass_block
fill ~-22 ~ ~11 ~22 ~ ~11 grass_block
fill ~-22 ~ ~12 ~22 ~ ~12 grass_block
fill ~-21 ~ ~13 ~21 ~ ~13 grass_block
fill ~-20 ~ ~14 ~20 ~ ~14 grass_block
fill ~-20 ~ ~15 ~20 ~ ~15 grass_block
fill ~-19 ~ ~16 ~19 ~ ~16 grass_block
fill ~-18 ~ ~17 ~18 ~ ~17 grass_block
fill ~-17 ~ ~18 ~17 ~ ~18 grass_block
fill ~-16 ~ ~19 ~16 ~ ~19 grass_block
fill ~-15 ~ ~20 ~15 ~ ~20 grass_block
fill ~-13 ~ ~21 ~13 ~ ~21 grass_block
fill ~-12 ~ ~22 ~12 ~ ~22 grass_block
fill ~-10 ~ ~23 ~10 ~ ~23 grass_block
fill ~-7 ~ ~24 ~7 ~ ~24 grass_block
fill ~-3 ~ ~25 ~3 ~ ~25 grass_block
fill ~-4 ~1 ~-24 ~4 ~1 ~-24 grass_block
fill ~-8 ~1 ~-23 ~8 ~1 ~-23 grass_block
fill ~-10 ~1 ~-22 ~10 ~1 ~-22 grass_block
fill ~-12 ~1 ~-21 ~12 ~1 ~-21 grass_block
fill ~-13 ~1 ~-20 ~13 ~1 ~-20 grass_block
fill ~-15 ~1 ~-19 ~15 ~1 ~-19 grass_block
fill ~-16 ~1 ~-18 ~16 ~1 ~-18 grass_block
fill ~-17 ~1 ~-17 ~17 ~1 ~-17 grass_block
fill ~-18 ~1 ~-16 ~18 ~1 ~-16 grass_block
fill ~-19 ~1 ~-15 ~19 ~1 ~-15 grass_block
fill ~-19 ~1 ~-14 ~19 ~1 ~-14 grass_block
fill ~-20 ~1 ~-13 ~20 ~1 ~-13 grass_block
fill ~-21 ~1 ~-12 ~21 ~1 ~-12 grass_block
fill ~-21 ~1 ~-11 ~21 ~1 ~-11 grass_block
fill ~-22 ~1 ~-10 ~22 ~1 ~-10 grass_block
fill ~-22 ~1 ~-9 ~22 ~1 ~-9 grass_block
fill ~-23 ~1 ~-8 ~23 ~1 ~-8 grass_block
fill ~-23 ~1 ~-7 ~23 ~1 ~-7 grass_block
fill ~-23 ~1 ~-6 ~23 ~1 ~-6 grass_block
fill ~-23 ~1 ~-5 ~23 ~1 ~-5 grass_block
fill ~-24 ~1 ~-4 ~24 ~1 ~-4 grass_block
fill ~-24 ~1 ~-3 ~24 ~1 ~-3 grass_block
fill ~-24 ~1 ~-2 ~24 ~1 ~-2 grass_block
fill ~-24 ~1 ~-1 ~24 ~1 ~-1 grass_block
fill ~-24 ~1 ~ ~24 ~1 ~ grass_block
fill ~-24 ~1 ~1 ~24 ~1 ~1 grass_block
fill ~-24 ~1 ~2 ~24 ~1 ~2 grass_block
fill ~-24 ~1 ~3 ~24 ~1 ~3 grass_block
fill ~-24 ~1 ~4 ~24 ~1 ~4 grass_block
fill ~-23 ~1 ~5 ~23 ~1 ~5 grass_block
fill ~-23 ~1 ~6 ~23 ~1 ~6 grass_block
fill ~-23 ~1 ~7 ~23 ~1 ~7 grass_block
fill ~-23 ~1 ~8 ~23 ~1 ~8 grass_block
fill ~-22 ~1 ~9 ~22 ~1 ~9 grass_block
fill ~-22 ~1 ~10 ~22 ~1 ~10 grass_block
fill ~-21 ~1 ~11 ~21 ~1 ~11 grass_block
fill ~-21 ~1 ~12 ~21 ~1 ~12 grass_block
fill ~-20 ~1 ~13 ~20 ~1 ~13 grass_block
fill ~-19 ~1 ~14 ~19 ~1 ~14 grass_block
fill ~-19 ~1 ~15 ~19 ~1 ~15 grass_block
fill ~-18 ~1 ~16 ~18 ~1 ~16 grass_block
fill ~-17 ~1 ~17 ~17 ~1 ~17 grass_block
fill ~-16 ~1 ~18 ~16 ~1 ~18 grass_block
fill ~-15 ~1 ~19 ~15 ~1 ~19 grass_block
fill ~-13 ~1 ~20 ~13 ~1 ~20 grass_block
fill ~-12 ~1 ~21 ~12 ~1 ~21 grass_block
fill ~-10 ~1 ~22 ~10 ~1 ~22 grass_block
fill ~-8 ~1 ~23 ~8 ~1 ~23 grass_block
fill ~-4 ~1 ~24 ~4 ~1 ~24 grass_block
fill ~-5 ~2 ~-23 ~5 ~2 ~-23 grass_block
fill ~-8 ~2 ~-22 ~8 ~2 ~-22 grass_block
fill ~-10 ~2 ~-21 ~10 ~2 ~-21 grass_block
fill ~-12 ~2 ~-20 ~12 ~2 ~-20 grass_block
fill ~-13 ~2 ~-19 ~13 ~2 ~-19 grass_block
fill ~-15 ~2 ~-18 ~15 ~2 ~-18 grass_block
fill ~-16 ~2 ~-17 ~16 ~2 ~-17 grass_block
fill ~-17 ~2 ~-16 ~17 ~2 ~-16 grass_block
fill ~-18 ~2 ~-15 ~18 ~2 ~-15 grass_block
fill ~-18 ~2 ~-14 ~18 ~2 ~-14 grass_block
fill ~-19 ~2 ~-13 ~19 ~2 ~-13 grass_block
fill ~-20 ~2 ~-12 ~20 ~2 ~-12 grass_block
fill ~-20 ~2 ~-11 ~20 ~2 ~-11 grass_block
fill ~-21 ~2 ~-10 ~21 ~2 ~-10 grass_block
fill ~-21 ~2 ~-9 ~21 ~2 ~-9 grass_block
fill ~-22 ~2 ~-8 ~22 ~2 ~-8 grass_block
fill ~-22 ~2 ~-7 ~22 ~2 ~-7 grass_block
fill ~-22 ~2 ~-6 ~22 ~2 ~-6 grass_block
fill ~-23 ~2 ~-5 ~23 ~2 ~-5 grass_block
fill ~-23 ~2 ~-4 ~23 ~2 ~-4 grass_block
fill ~-23 ~2 ~-3 ~23 ~2 ~-3 grass_block
fill ~-23 ~2 ~-2 ~23 ~2 ~-2 grass_block
fill ~-23 ~2 ~-1 ~23 ~2 ~-1 grass_block
fill ~-23 ~2 ~ ~23 ~2 ~ grass_block
fill ~-23 ~2 ~1 ~23 ~2 ~1 grass_block
fill ~-23 ~2 ~2 ~23 ~2 ~2 grass_block
fill ~-23 ~2 ~3 ~23 ~2 ~3 grass_block
fill ~-23 ~2 ~4 ~23 ~2 ~4 grass_block
fill ~-23 ~2 ~5 ~23 ~2 ~5 grass_block
fill ~-22 ~2 ~6 ~22 ~2 ~6 grass_block
fill ~-22 ~2 ~7 ~22 ~2 ~7 grass_block
fill ~-22 ~2 ~8 ~22 ~2 ~8 grass_block
fill ~-21 ~2 ~9 ~21 ~2 ~9 grass_block
fill ~-21 ~2 ~10 ~21 ~2 ~10 grass_block
fill ~-20 ~2 ~11 ~20 ~2 ~11 grass_block
fill ~-20 ~2 ~12 ~20 ~2 ~12 grass_block
fill ~-19 ~2 ~13 ~19 ~2 ~13 grass_block
fill ~-18 ~2 ~14 ~18 ~2 ~14 grass_block
fill ~-18 ~2 ~15 ~18 ~2 ~15 grass_block
fill ~-17 ~2 ~16 ~17 ~2 ~16 grass_block
fill ~-16 ~2 ~17 ~16 ~2 ~17 grass_block
fill ~-15 ~2 ~18 ~15 ~2 ~18 grass_block
fill ~-13 ~2 ~19 ~13 ~2 ~19 grass_block
fill ~-12 ~2 ~20 ~12 ~2 ~20 grass_block
fill ~-10 ~2 ~21 ~10 ~2 ~21 grass_block
fill ~-8 ~2 ~22 ~8 ~2 ~22 grass_block
fill ~-5 ~2 ~23 ~5 ~2 ~23 grass_block
fill ~-5 ~3 ~-22 ~5 ~3 ~-22 grass_block
fill ~-8 ~3 ~-21 ~8 ~3 ~-21 grass_block
fill ~-10 ~3 ~-20 ~10 ~3 ~-20 grass_block
fill ~-12 ~3 ~-19 ~12 ~3 ~-19 grass_block
fill ~-13 ~3 ~-18 ~13 ~3 ~-18 grass_block
fill ~-15 ~3 ~-17 ~15 ~3 ~-17 grass_block
fill ~-16 ~3 ~-16 ~16 ~3 ~-16 grass_block
fill ~-17 ~3 ~-15 ~17 ~3 ~-15 grass_block
fill ~-17 ~3 ~-14 ~17 ~3 ~-14 grass_block
fill ~-18 ~3 ~-13 ~18 ~3 ~-13 grass_block
fill ~-19 ~3 ~-12 ~19 ~3 ~-12 grass_block
fill ~-19 ~3 ~-11 ~19 ~3 ~-11 grass_block
fill ~-20 ~3 ~-10 ~20 ~3 ~-10 grass_block
fill ~-20 ~3 ~-9 ~20 ~3 ~-9 grass_block
fill ~-21 ~3 ~-8 ~21 ~3 ~-8 grass_block
fill ~-21 ~3 ~-7 ~21 ~3 ~-7 grass_block
fill ~-21 ~3 ~-6 ~21 ~3 ~-6 grass_block
fill ~-22 ~3 ~-5 ~22 ~3 ~-5 grass_block
fill ~-22 ~3 ~-4 ~22 ~3 ~-4 grass_block
fill ~-22 ~3 ~-3 ~22 ~3 ~-3 grass_block
fill ~-22 ~3 ~-2 ~22 ~3 ~-2 grass_block
fill ~-22 ~3 ~-1 ~22 ~3 ~-1 grass_block
fill ~-22 ~3 ~ ~22 ~3 ~ grass_block
fill ~-22 ~3 ~1 ~22 ~3 ~1 grass_block
fill ~-22 ~3 ~2 ~22 ~3 ~2 grass_block
fill ~-22 ~3 ~3 ~22 ~3 ~3 grass_block
fill ~-22 ~3 ~4 ~22 ~3 ~4 grass_block
fill ~-22 ~3 ~5 ~22 ~3 ~5 grass_block
fill ~-21 ~3 ~6 ~21 ~3 ~6 grass_block
fill ~-21 ~3 ~7 ~21 ~3 ~7 grass_block
fill ~-21 ~3 ~8 ~21 ~3 ~8 grass_block
fill ~-20 ~3 ~9 ~20 ~3 ~9 grass_block
fill ~-20 ~3 ~10 ~20 ~3 ~10 grass_block
fill ~-19 ~3 ~11 ~19 ~3 ~11 grass_block
fill ~-19 ~3 ~12 ~19 ~3 ~12 grass_block
fill ~-18 ~3 ~13 ~18 ~3 ~13 grass_block
fill ~-17 ~3 ~14 ~17 ~3 ~14 grass_block
fill ~-17 ~3 ~15 ~17 ~3 ~15 grass_block
fill ~-16 ~3 ~16 ~16 ~3 ~16 grass_block
fill ~-15 ~3 ~17 ~15 ~3 ~17 grass_block
fill ~-13 ~3 ~18 ~13 ~3 ~18 grass_block
fill ~-12 ~3 ~19 ~12 ~3 ~19 grass_block
fill ~-10 ~3 ~20 ~10 ~3 ~20 grass_block
fill ~-8 ~3 ~21 ~8 ~3 ~21 grass_block
fill ~-5 ~3 ~22 ~5 ~3 ~22 grass_block
fill ~ ~4 ~-22 ~ ~4 ~-22 grass_block
fill ~-6 ~4 ~-21 ~6 ~4 ~-21 grass_block
fill ~-9 ~4 ~-20 ~9 ~4 ~-20 grass_block
fill ~-11 ~4 ~-19 ~11 ~4 ~-19 grass_block
fill ~-12 ~4 ~-18 ~12 ~4 ~-18 grass_block
fill ~-13 ~4 ~-17 ~13 ~4 ~-17 grass_block
fill ~-15 ~4 ~-16 ~15 ~4 ~-16 grass_block
fill ~-16 ~4 ~-15 ~16 ~4 ~-15 grass_block
fill ~-16 ~4 ~-14 ~16 ~4 ~-14 grass_block
fill ~-17 ~4 ~-13 ~17 ~4 ~-13 grass_block
fill ~-18 ~4 ~-12 ~18 ~4 ~-12 grass_block
fill ~-19 ~4 ~-11 ~19 ~4 ~-11 grass_block
fill ~-19 ~4 ~-10 ~19 ~4 ~-10 grass_block
fill ~-20 ~4 ~-9 ~20 ~4 ~-9 grass_block
fill ~-20 ~4 ~-8 ~20 ~4 ~-8 grass_block
fill ~-20 ~4 ~-7 ~20 ~4 ~-7 grass_block
fill ~-21 ~4 ~-6 ~21 ~4 ~-6 grass_block
fill ~-21 ~4 ~-5 ~21 ~4 ~-5 grass_block
fill ~-21 ~4 ~-4 ~21 ~4 ~-4 grass_block
fill ~-21 ~4 ~-3 ~21 ~4 ~-3 grass_block
fill ~-21 ~4 ~-2 ~21 ~4 ~-2 grass_block
fill ~-21 ~4 ~-1 ~21 ~4 ~-1 grass_block
fill ~-22 ~4 ~ ~22 ~4 ~ grass_block
fill ~-21 ~4 ~1 ~21 ~4 ~1 grass_block
fill ~-21 ~4 ~2 ~21 ~4 ~2 grass_block
fill ~-21 ~4 ~3 ~21 ~4 ~3 grass_block
fill ~-21 ~4 ~4 ~21 ~4 ~4 grass_block
fill ~-21 ~4 ~5 ~21 ~4 ~5 grass_block
fill ~-21 ~4 ~6 ~21 ~4 ~6 grass_block
fill ~-20 ~4 ~7 ~20 ~4 ~7 grass_block
fill ~-20 ~4 ~8 ~20 ~4 ~8 grass_block
fill ~-20 ~4 ~9 ~20 ~4 ~9 grass_block
fill ~-19 ~4 ~10 ~19 ~4 ~10 grass_block
fill ~-19 ~4 ~11 ~19 ~4 ~11 grass_block
fill ~-18 ~4 ~12 ~18 ~4 ~12 grass_block
fill ~-17 ~4 ~13 ~17 ~4 ~13 grass_block
fill ~-16 ~4 ~14 ~16 ~4 ~14 grass_block
fill ~-16 ~4 ~15 ~16 ~4 ~15 grass_block
fill ~-15 ~4 ~16 ~15 ~4 ~16 grass_block
fill ~-13 ~4 ~17 ~13 ~4 ~17 grass_block
fill ~-12 ~4 ~18 ~12 ~4 ~18 grass_block
fill ~-11 ~4 ~19 ~11 ~4 ~19 grass_block
fill ~-9 ~4 ~20 ~9 ~4 ~20 grass_block
fill ~-6 ~4 ~21 ~6 ~4 ~21 grass_block
fill ~ ~4 ~22 ~ ~4 ~22 grass_block
fill ~-2 ~5 ~-21 ~2 ~5 ~-21 grass_block
fill ~-7 ~5 ~-20 ~7 ~5 ~-20 grass_block
fill ~-9 ~5 ~-19 ~9 ~5 ~-19 grass_block
fill ~-11 ~5 ~-18 ~11 ~5 ~-18 grass_block
fill ~-12 ~5 ~-17 ~12 ~5 ~-17 grass_block
fill ~-13 ~5 ~-16 ~13 ~5 ~-16 grass_block
fill ~-14 ~5 ~-15 ~14 ~5 ~-15 grass_block
fill ~-15 ~5 ~-14 ~15 ~5 ~-14 grass_block
fill ~-16 ~5 ~-13 ~16 ~5 ~-13 grass_block
fill ~-17 ~5 ~-12 ~17 ~5 ~-12 grass_block
fill ~-18 ~5 ~-11 ~18 ~5 ~-11 grass_block
fill ~-18 ~5 ~-10 ~18 ~5 ~-10 grass_block
fill ~-19 ~5 ~-9 ~19 ~5 ~-9 grass_block
fill ~-19 ~5 ~-8 ~19 ~5 ~-8 grass_block
fill ~-20 ~5 ~-7 ~20 ~5 ~-7 grass_block
fill ~-20 ~5 ~-6 ~20 ~5 ~-6 grass_block
fill ~-20 ~5 ~-5 ~20 ~5 ~-5 grass_block
fill ~-20 ~5 ~-4 ~20 ~5 ~-4 grass_block
fill ~-20 ~5 ~-3 ~20 ~5 ~-3 grass_block
fill ~-21 ~5 ~-2 ~21 ~5 ~-2 grass_block
fill ~-21 ~5 ~-1 ~21 ~5 ~-1 grass_block
fill ~-21 ~5 ~ ~21 ~5 ~ grass_block
fill ~-21 ~5 ~1 ~21 ~5 ~1 grass_block
fill ~-21 ~5 ~2 ~21 ~5 ~2 grass_block
fill ~-20 ~5 ~3 ~20 ~5 ~3 grass_block
fill ~-20 ~5 ~4 ~20 ~5 ~4 grass_block
fill ~-20 ~5 ~5 ~20 ~5 ~5 grass_block
fill ~-20 ~5 ~6 ~20 ~5 ~6 grass_block
fill ~-20 ~5 ~7 ~20 ~5 ~7 grass_block
fill ~-19 ~5 ~8 ~19 ~5 ~8 grass_block
fill ~-19 ~5 ~9 ~19 ~5 ~9 grass_block
fill ~-18 ~5 ~10 ~18 ~5 ~10 grass_block
fill ~-18 ~5 ~11 ~18 ~5 ~11 grass_block
fill ~-17 ~5 ~12 ~17 ~5 ~12 grass_block
fill ~-16 ~5 ~13 ~16 ~5 ~13 grass_block
fill ~-15 ~5 ~14 ~15 ~5 ~14 grass_block
fill ~-14 ~5 ~15 ~14 ~5 ~15 grass_block
fill ~-13 ~5 ~16 ~13 ~5 ~16 grass_block
fill ~-12 ~5 ~17 ~12 ~5 ~17 grass_block
fill ~-11 ~5 ~18 ~11 ~5 ~18 grass_block
fill ~-9 ~5 ~19 ~9 ~5 ~19 grass_block
fill ~-7 ~5 ~20 ~7 ~5 ~20 grass_block
fill ~-2 ~5 ~21 ~2 ~5 ~21 grass_block
fill ~-4 ~6 ~-20 ~4 ~6 ~-20 grass_block
fill ~-7 ~6 ~-19 ~7 ~6 ~-19 grass_block
fill ~-9 ~6 ~-18 ~9 ~6 ~-18 grass_block
fill ~-11 ~6 ~-17 ~11 ~6 ~-17 grass_block
fill ~-12 ~6 ~-16 ~12 ~6 ~-16 grass_block
fill ~-13 ~6 ~-15 ~13 ~6 ~-15 grass_block
fill ~-14 ~6 ~-14 ~14 ~6 ~-14 grass_block
fill ~-15 ~6 ~-13 ~15 ~6 ~-13 grass_block
fill ~-16 ~6 ~-12 ~16 ~6 ~-12 grass_block
fill ~-17 ~6 ~-11 ~17 ~6 ~-11 grass_block
fill ~-17 ~6 ~-10 ~17 ~6 ~-10 grass_block
fill ~-18 ~6 ~-9 ~18 ~6 ~-9 grass_block
fill ~-18 ~6 ~-8 ~18 ~6 ~-8 grass_block
fill ~-19 ~6 ~-7 ~19 ~6 ~-7 grass_block
fill ~-19 ~6 ~-6 ~19 ~6 ~-6 grass_block
fill ~-19 ~6 ~-5 ~19 ~6 ~-5 grass_block
fill ~-20 ~6 ~-4 ~20 ~6 ~-4 grass_block
fill ~-20 ~6 ~-3 ~20 ~6 ~-3 grass_block
fill ~-20 ~6 ~-2 ~20 ~6 ~-2 grass_block
fill ~-20 ~6 ~-1 ~20 ~6 ~-1 grass_block
fill ~-20 ~6 ~ ~20 ~6 ~ grass_block
fill ~-20 ~6 ~1 ~20 ~6 ~1 grass_block
fill ~-20 ~6 ~2 ~20 ~6 ~2 grass_block
fill ~-20 ~6 ~3 ~20 ~6 ~3 grass_block
fill ~-20 ~6 ~4 ~20 ~6 ~4 grass_block
fill ~-19 ~6 ~5 ~19 ~6 ~5 grass_block
fill ~-19 ~6 ~6 ~19 ~6 ~6 grass_block
fill ~-19 ~6 ~7 ~19 ~6 ~7 grass_block
fill ~-18 ~6 ~8 ~18 ~6 ~8 grass_block
fill ~-18 ~6 ~9 ~18 ~6 ~9 grass_block
fill ~-17 ~6 ~10 ~17 ~6 ~10 grass_block
fill ~-17 ~6 ~11 ~17 ~6 ~11 grass_block
fill ~-16 ~6 ~12 ~16 ~6 ~12 grass_block
fill ~-15 ~6 ~13 ~15 ~6 ~13 grass_block
fill ~-14 ~6 ~14 ~14 ~6 ~14 grass_block
fill ~-13 ~6 ~15 ~13 ~6 ~15 grass_block
fill ~-12 ~6 ~16 ~12 ~6 ~16 grass_block
fill ~-11 ~6 ~17 ~11 ~6 ~17 grass_block
fill ~-9 ~6 ~18 ~9 ~6 ~18 grass_block
fill ~-7 ~6 ~19 ~7 ~6 ~19 grass_block
fill ~-4 ~6 ~20 ~4 ~6 ~20 grass_block
fill ~-4 ~7 ~-19 ~4 ~7 ~-19 grass_block
fill ~-7 ~7 ~-18 ~7 ~7 ~-18 grass_block
fill ~-9 ~7 ~-17 ~9 ~7 ~-17 grass_block
fill ~-11 ~7 ~-16 ~11 ~7 ~-16 grass_block
fill ~-12 ~7 ~-15 ~12 ~7 ~-15 grass_block
fill ~-13 ~7 ~-14 ~13 ~7 ~-14 grass_block
fill ~-14 ~7 ~-13 ~14 ~7 ~-13 grass_block
fill ~-15 ~7 ~-12 ~15 ~7 ~-12 grass_block
fill ~-16 ~7 ~-11 ~16 ~7 ~-11 grass_block
fill ~-16 ~7 ~-10 ~16 ~7 ~-10 grass_block
fill ~-17 ~7 ~-9 ~17 ~7 ~-9 grass_block
fill ~-17 ~7 ~-8 ~17 ~7 ~-8 grass_block
fill ~-18 ~7 ~-7 ~18 ~7 ~-7 grass_block
fill ~-18 ~7 ~-6 ~18 ~7 ~-6 grass_block
fill ~-18 ~7 ~-5 ~18 ~7 ~-5 grass_block
fill ~-19 ~7 ~-4 ~19 ~7 ~-4 grass_block
fill ~-19 ~7 ~-3 ~19 ~7 ~-3 grass_block
fill ~-19 ~7 ~-2 ~19 ~7 ~-2 grass_block
fill ~-19 ~7 ~-1 ~19 ~7 ~-1 grass_block
fill ~-19 ~7 ~ ~19 ~7 ~ grass_block
fill ~-19 ~7 ~1 ~19 ~7 ~1 grass_block
fill ~-19 ~7 ~2 ~19 ~7 ~2 grass_block
fill ~-19 ~7 ~3 ~19 ~7 ~3 grass_block
fill ~-19 ~7 ~4 ~19 ~7 ~4 grass_block
fill ~-18 ~7 ~5 ~18 ~7 ~5 grass_block
fill ~-18 ~7 ~6 ~18 ~7 ~6 grass_block
fill ~-18 ~7 ~7 ~18 ~7 ~7 grass_block
fill ~-17 ~7 ~8 ~17 ~7 ~8 grass_block
fill ~-17 ~7 ~9 ~17 ~7 ~9 grass_block
fill ~-16 ~7 ~10 ~16 ~7 ~10 grass_block
fill ~-16 ~7 ~11 ~16 ~7 ~11 grass_block
fill ~-15 ~7 ~12 ~15 ~7 ~12 grass_block
fill ~-14 ~7 ~13 ~14 ~7 ~13 grass_block
fill ~-13 ~7 ~14 ~13 ~7 ~14 grass_block
fill ~-12 ~7 ~15 ~12 ~7 ~15 grass_block
fill ~-11 ~7 ~16 ~11 ~7 ~16 grass_block
fill ~-9 ~7 ~17 ~9 ~7 ~17 grass_block
fill ~-7 ~7 ~18 ~7 ~7 ~18 grass_block
fill ~-4 ~7 ~19 ~4 ~7 ~19 grass_block
fill ~-5 ~8 ~-18 ~5 ~8 ~-18 grass_block
fill ~-8 ~8 ~-17 ~8 ~8 ~-17 grass_block
fill ~-9 ~8 ~-16 ~9 ~8 ~-16 grass_block
fill ~-11 ~8 ~-15 ~11 ~8 ~-15 grass_block
fill ~-12 ~8 ~-14 ~12 ~8 ~-14 grass_block
fill ~-13 ~8 ~-13 ~13 ~8 ~-13 grass_block
fill ~-14 ~8 ~-12 ~14 ~8 ~-12 grass_block
fill ~-15 ~8 ~-11 ~15 ~8 ~-11 grass_block
fill ~-15 ~8 ~-10 ~15 ~8 ~-10 grass_block
fill ~-16 ~8 ~-9 ~16 ~8 ~-9 grass_block
fill ~-17 ~8 ~-8 ~17 ~8 ~-8 grass_block
fill ~-17 ~8 ~-7 ~17 ~8 ~-7 grass_block
fill ~-17 ~8 ~-6 ~17 ~8 ~-6 grass_block
fill ~-18 ~8 ~-5 ~18 ~8 ~-5 grass_block
fill ~-18 ~8 ~-4 ~18 ~8 ~-4 grass_block
fill ~-18 ~8 ~-3 ~18 ~8 ~-3 grass_block
fill ~-18 ~8 ~-2 ~18 ~8 ~-2 grass_block
fill ~-18 ~8 ~-1 ~18 ~8 ~-1 grass_block
fill ~-18 ~8 ~ ~18 ~8 ~ grass_block
fill ~-18 ~8 ~1 ~18 ~8 ~1 grass_block
fill ~-18 ~8 ~2 ~18 ~8 ~2 grass_block
fill ~-18 ~8 ~3 ~18 ~8 ~3 grass_block
fill ~-18 ~8 ~4 ~18 ~8 ~4 grass_block
fill ~-18 ~8 ~5 ~18 ~8 ~5 grass_block
fill ~-17 ~8 ~6 ~17 ~8 ~6 grass_block
fill ~-17 ~8 ~7 ~17 ~8 ~7 grass_block
fill ~-17 ~8 ~8 ~17 ~8 ~8 grass_block
fill ~-16 ~8 ~9 ~16 ~8 ~9 grass_block
fill ~-15 ~8 ~10 ~15 ~8 ~10 grass_block
fill ~-15 ~8 ~11 ~15 ~8 ~11 grass_block
fill ~-14 ~8 ~12 ~14 ~8 ~12 grass_block
fill ~-13 ~8 ~13 ~13 ~8 ~13 grass_block
fill ~-12 ~8 ~14 ~12 ~8 ~14 grass_block
fill ~-11 ~8 ~15 ~11 ~8 ~15 grass_block
fill ~-9 ~8 ~16 ~9 ~8 ~16 grass_block
fill ~-8 ~8 ~17 ~8 ~8 ~17 grass_block
fill ~-5 ~8 ~18 ~5 ~8 ~18 grass_block
fill ~ ~9 ~-18 ~ ~9 ~-18 grass_block
fill ~-5 ~9 ~-17 ~5 ~9 ~-17 grass_block
fill ~-8 ~9 ~-16 ~8 ~9 ~-16 grass_block
fill ~-9 ~9 ~-15 ~9 ~9 ~-15 grass_block
fill ~-11 ~9 ~-14 ~11 ~9 ~-14 grass_block
fill ~-12 ~9 ~-13 ~12 ~9 ~-13 grass_block
fill ~-13 ~9 ~-12 ~13 ~9 ~-12 grass_block
fill ~-14 ~9 ~-11 ~14 ~9 ~-11 grass_block
fill ~-14 ~9 ~-10 ~14 ~9 ~-10 grass_block
fill ~-15 ~9 ~-9 ~15 ~9 ~-9 grass_block
fill ~-16 ~9 ~-8 ~16 ~9 ~-8 grass_block
fill ~-16 ~9 ~-7 ~16 ~9 ~-7 grass_block
fill ~-16 ~9 ~-6 ~16 ~9 ~-6 grass_block
fill ~-17 ~9 ~-5 ~17 ~9 ~-5 grass_block
fill ~-17 ~9 ~-4 ~17 ~9 ~-4 grass_block
fill ~-17 ~9 ~-3 ~17 ~9 ~-3 grass_block
fill ~-17 ~9 ~-2 ~17 ~9 ~-2 grass_block
fill ~-17 ~9 ~-1 ~17 ~9 ~-1 grass_block
fill ~-18 ~9 ~ ~18 ~9 ~ grass_block
fill ~-17 ~9 ~1 ~17 ~9 ~1 grass_block
fill ~-17 ~9 ~2 ~17 ~9 ~2 grass_block
fill ~-17 ~9 ~3 ~17 ~9 ~3 grass_block
fill ~-17 ~9 ~4 ~17 ~9 ~4 grass_block
fill ~-17 ~9 ~5 ~17 ~9 ~5 grass_block
fill ~-16 ~9 ~6 ~16 ~9 ~6 grass_block
fill ~-16 ~9 ~7 ~16 ~9 ~7 grass_block
fill ~-16 ~9 ~8 ~16 ~9 ~8 grass_block
fill ~-15 ~9 ~9 ~15 ~9 ~9 grass_block
fill ~-14 ~9 ~10 ~14 ~9 ~10 grass_block
fill ~-14 ~9 ~11 ~14 ~9 ~11 grass_block
fill ~-13 ~9 ~12 ~13 ~9 ~12 grass_block
fill ~-12 ~9 ~13 ~12 ~9 ~13 grass_block
fill ~-11 ~9 ~14 ~11 ~9 ~14 grass_block
fill ~-9 ~9 ~15 ~9 ~9 ~15 grass_block
fill ~-8 ~9 ~16 ~8 ~9 ~16 grass_block
fill ~-5 ~9 ~17 ~5 ~9 ~17 grass_block
fill ~ ~9 ~18 ~ ~9 ~18 grass_block
fill ~-2 ~10 ~-17 ~2 ~10 ~-17 grass_block
fill ~-6 ~10 ~-16 ~6 ~10 ~-16 grass_block
fill ~-8 ~10 ~-15 ~8 ~10 ~-15 grass_block
fill ~-9 ~10 ~-14 ~9 ~10 ~-14 grass_block
fill ~-11 ~10 ~-13 ~11 ~10 ~-13 grass_block
fill ~-12 ~10 ~-12 ~12 ~10 ~-12 grass_block
fill ~-13 ~10 ~-11 ~13 ~10 ~-11 grass_block
fill ~-13 ~10 ~-10 ~13 ~10 ~-10 grass_block
fill ~-14 ~10 ~-9 ~14 ~10 ~-9 grass_block
fill ~-15 ~10 ~-8 ~15 ~10 ~-8 grass_block
fill ~-15 ~10 ~-7 ~15 ~10 ~-7 grass_block
fill ~-16 ~10 ~-6 ~16 ~10 ~-6 grass_block
fill ~-16 ~10 ~-5 ~16 ~10 ~-5 grass_block
fill ~-16 ~10 ~-4 ~16 ~10 ~-4 grass_block
fill ~-16 ~10 ~-3 ~16 ~10 ~-3 grass_block
fill ~-17 ~10 ~-2 ~17 ~10 ~-2 grass_block
fill ~-17 ~10 ~-1 ~17 ~10 ~-1 grass_block
fill ~-17 ~10 ~ ~17 ~10 ~ grass_block
fill ~-17 ~10 ~1 ~17 ~10 ~1 grass_block
fill ~-17 ~10 ~2 ~17 ~10 ~2 grass_block
fill ~-16 ~10 ~3 ~16 ~10 ~3 grass_block
fill ~-16 ~10 ~4 ~16 ~10 ~4 grass_block
fill ~-16 ~10 ~5 ~16 ~10 ~5 grass_block
fill ~-16 ~10 ~6 ~16 ~10 ~6 grass_block
fill ~-15 ~10 ~7 ~15 ~10 ~7 grass_block
fill ~-15 ~10 ~8 ~15 ~10 ~8 grass_block
fill ~-14 ~10 ~9 ~14 ~10 ~9 grass_block
fill ~-13 ~10 ~10 ~13 ~10 ~10 grass_block
fill ~-13 ~10 ~11 ~13 ~10 ~11 grass_block
fill ~-12 ~10 ~12 ~12 ~10 ~12 grass_block
fill ~-11 ~10 ~13 ~11 ~10 ~13 grass_block
fill ~-9 ~10 ~14 ~9 ~10 ~14 grass_block
fill ~-8 ~10 ~15 ~8 ~10 ~15 grass_block
fill ~-6 ~10 ~16 ~6 ~10 ~16 grass_block
fill ~-2 ~10 ~17 ~2 ~10 ~17 grass_block
fill ~-3 ~11 ~-16 ~3 ~11 ~-16 grass_block
fill ~-6 ~11 ~-15 ~6 ~11 ~-15 grass_block
fill ~-8 ~11 ~-14 ~8 ~11 ~-14 grass_block
fill ~-9 ~11 ~-13 ~9 ~11 ~-13 grass_block
fill ~-11 ~11 ~-12 ~11 ~11 ~-12 grass_block
fill ~-12 ~11 ~-11 ~12 ~11 ~-11 grass_block
fill ~-12 ~11 ~-10 ~12 ~11 ~-10 grass_block
fill ~-13 ~11 ~-9 ~13 ~11 ~-9 grass_block
fill ~-14 ~11 ~-8 ~14 ~11 ~-8 grass_block
fill ~-14 ~11 ~-7 ~14 ~11 ~-7 grass_block
fill ~-15 ~11 ~-6 ~15 ~11 ~-6 grass_block
fill ~-15 ~11 ~-5 ~15 ~11 ~-5 grass_block
fill ~-15 ~11 ~-4 ~15 ~11 ~-4 grass_block
fill ~-16 ~11 ~-3 ~16 ~11 ~-3 grass_block
fill ~-16 ~11 ~-2 ~16 ~11 ~-2 grass_block
fill ~-16 ~11 ~-1 ~16 ~11 ~-1 grass_block
fill ~-16 ~11 ~ ~16 ~11 ~ grass_block
fill ~-16 ~11 ~1 ~16 ~11 ~1 grass_block
fill ~-16 ~11 ~2 ~16 ~11 ~2 grass_block
fill ~-16 ~11 ~3 ~16 ~11 ~3 grass_block
fill ~-15 ~11 ~4 ~15 ~11 ~4 grass_block
fill ~-15 ~11 ~5 ~15 ~11 ~5 grass_block
fill ~-15 ~11 ~6 ~15 ~11 ~6 grass_block
fill ~-14 ~11 ~7 ~14 ~11 ~7 grass_block
fill ~-14 ~11 ~8 ~14 ~11 ~8 grass_block
fill ~-13 ~11 ~9 ~13 ~11 ~9 grass_block
fill ~-12 ~11 ~10 ~12 ~11 ~10 grass_block
fill ~-12 ~11 ~11 ~12 ~11 ~11 grass_block
fill ~-11 ~11 ~12 ~11 ~11 ~12 grass_block
fill ~-9 ~11 ~13 ~9 ~11 ~13 grass_block
fill ~-8 ~11 ~14 ~8 ~11 ~14 grass_block
fill ~-6 ~11 ~15 ~6 ~11 ~15 grass_block
fill ~-3 ~11 ~16 ~3 ~11 ~16 grass_block
fill ~-4 ~12 ~-15 ~4 ~12 ~-15 grass_block
fill ~-6 ~12 ~-14 ~6 ~12 ~-14 grass_block
fill ~-8 ~12 ~-13 ~8 ~12 ~-13 grass_block
fill ~-9 ~12 ~-12 ~9 ~12 ~-12 grass_block
fill ~-11 ~12 ~-11 ~11 ~12 ~-11 grass_block
fill ~-11 ~12 ~-10 ~11 ~12 ~-10 grass_block
fill ~-12 ~12 ~-9 ~12 ~12 ~-9 grass_block
fill ~-13 ~12 ~-8 ~13 ~12 ~-8 grass_block
fill ~-13 ~12 ~-7 ~13 ~12 ~-7 grass_block
fill ~-14 ~12 ~-6 ~14 ~12 ~-6 grass_block
fill ~-14 ~12 ~-5 ~14 ~12 ~-5 grass_block
fill ~-15 ~12 ~-4 ~15 ~12 ~-4 grass_block
fill ~-15 ~12 ~-3 ~15 ~12 ~-3 grass_block
fill ~-15 ~12 ~-2 ~15 ~12 ~-2 grass_block
fill ~-15 ~12 ~-1 ~15 ~12 ~-1 grass_block
fill ~-15 ~12 ~ ~15 ~12 ~ grass_block
fill ~-15 ~12 ~1 ~15 ~12 ~1 grass_block
fill ~-15 ~12 ~2 ~15 ~12 ~2 grass_block
fill ~-15 ~12 ~3 ~15 ~12 ~3 grass_block
fill ~-15 ~12 ~4 ~15 ~12 ~4 grass_block
fill ~-14 ~12 ~5 ~14 ~12 ~5 grass_block
fill ~-14 ~12 ~6 ~14 ~12 ~6 grass_block
fill ~-13 ~12 ~7 ~13 ~12 ~7 grass_block
fill ~-13 ~12 ~8 ~13 ~12 ~8 grass_block
fill ~-12 ~12 ~9 ~12 ~12 ~9 grass_block
fill ~-11 ~12 ~10 ~11 ~12 ~10 grass_block
fill ~-11 ~12 ~11 ~11 ~12 ~11 grass_block
fill ~-9 ~12 ~12 ~9 ~12 ~12 grass_block
fill ~-8 ~12 ~13 ~8 ~12 ~13 grass_block
fill ~-6 ~12 ~14 ~6 ~12 ~14 grass_block
fill ~-4 ~12 ~15 ~4 ~12 ~15 grass_block
fill ~-4 ~13 ~-14 ~4 ~13 ~-14 grass_block
fill ~-7 ~13 ~-13 ~7 ~13 ~-13 grass_block
fill ~-8 ~13 ~-12 ~8 ~13 ~-12 grass_block
fill ~-9 ~13 ~-11 ~9 ~13 ~-11 grass_block
fill ~-10 ~13 ~-10 ~10 ~13 ~-10 grass_block
fill ~-11 ~13 ~-9 ~11 ~13 ~-9 grass_block
fill ~-12 ~13 ~-8 ~12 ~13 ~-8 grass_block
fill ~-13 ~13 ~-7 ~13 ~13 ~-7 grass_block
fill ~-13 ~13 ~-6 ~13 ~13 ~-6 grass_block
fill ~-13 ~13 ~-5 ~13 ~13 ~-5 grass_block
fill ~-14 ~13 ~-4 ~14 ~13 ~-4 grass_block
fill ~-14 ~13 ~-3 ~14 ~13 ~-3 grass_block
fill ~-14 ~13 ~-2 ~14 ~13 ~-2 grass_block
fill ~-14 ~13 ~-1 ~14 ~13 ~-1 grass_block
fill ~-14 ~13 ~ ~14 ~13 ~ grass_block
fill ~-14 ~13 ~1 ~14 ~13 ~1 grass_block
fill ~-14 ~13 ~2 ~14 ~13 ~2 grass_block
fill ~-14 ~13 ~3 ~14 ~13 ~3 grass_block
fill ~-14 ~13 ~4 ~14 ~13 ~4 grass_block
fill ~-13 ~13 ~5 ~13 ~13 ~5 grass_block
fill ~-13 ~13 ~6 ~13 ~13 ~6 grass_block
fill ~-13 ~13 ~7 ~13 ~13 ~7 grass_block
fill ~-12 ~13 ~8 ~12 ~13 ~8 grass_block
fill ~-11 ~13 ~9 ~11 ~13 ~9 grass_block
fill ~-10 ~13 ~10 ~10 ~13 ~10 grass_block
fill ~-9 ~13 ~11 ~9 ~13 ~11 grass_block
fill ~-8 ~13 ~12 ~8 ~13 ~12 grass_block
fill ~-7 ~13 ~13 ~7 ~13 ~13 grass_block
fill ~-4 ~13 ~14 ~4 ~13 ~14 grass_block
fill ~ ~14 ~-14 ~ ~14 ~-14 grass_block
fill ~-5 ~14 ~-13 ~5 ~14 ~-13 grass_block
fill ~-7 ~14 ~-12 ~7 ~14 ~-12 grass_block
fill ~-8 ~14 ~-11 ~8 ~14 ~-11 grass_block
fill ~-9 ~14 ~-10 ~9 ~14 ~-10 grass_block
fill ~-10 ~14 ~-9 ~10 ~14 ~-9 grass_block
fill ~-11 ~14 ~-8 ~11 ~14 ~-8 grass_block
fill ~-12 ~14 ~-7 ~12 ~14 ~-7 grass_block
fill ~-12 ~14 ~-6 ~12 ~14 ~-6 grass_block
fill ~-13 ~14 ~-5 ~13 ~14 ~-5 grass_block
fill ~-13 ~14 ~-4 ~13 ~14 ~-4 grass_block
fill ~-13 ~14 ~-3 ~13 ~14 ~-3 grass_block
fill ~-13 ~14 ~-2 ~13 ~14 ~-2 grass_block
fill ~-13 ~14 ~-1 ~13 ~14 ~-1 grass_block
fill ~-14 ~14 ~ ~14 ~14 ~ grass_block
fill ~-13 ~14 ~1 ~13 ~14 ~1 grass_block
fill ~-13 ~14 ~2 ~13 ~14 ~2 grass_block
fill ~-13 ~14 ~3 ~13 ~14 ~3 grass_block
fill ~-13 ~14 ~4 ~13 ~14 ~4 grass_block
fill ~-13 ~14 ~5 ~13 ~14 ~5 grass_block
fill ~-12 ~14 ~6 ~12 ~14 ~6 grass_block
fill ~-12 ~14 ~7 ~12 ~14 ~7 grass_block
fill ~-11 ~14 ~8 ~11 ~14 ~8 grass_block
fill ~-10 ~14 ~9 ~10 ~14 ~9 grass_block
fill ~-9 ~14 ~10 ~9 ~14 ~10 grass_block
fill ~-8 ~14 ~11 ~8 ~14 ~11 grass_block
fill ~-7 ~14 ~12 ~7 ~14 ~12 grass_block
fill ~-5 ~14 ~13 ~5 ~14 ~13 grass_block
fill ~ ~14 ~14 ~ ~14 ~14 grass_block
fill ~-2 ~15 ~-13 ~2 ~15 ~-13 grass_block
fill ~-5 ~15 ~-12 ~5 ~15 ~-12 grass_block
fill ~-7 ~15 ~-11 ~7 ~15 ~-11 grass_block
fill ~-8 ~15 ~-10 ~8 ~15 ~-10 grass_block
fill ~-9 ~15 ~-9 ~9 ~15 ~-9 grass_block
fill ~-10 ~15 ~-8 ~10 ~15 ~-8 grass_block
fill ~-11 ~15 ~-7 ~11 ~15 ~-7 grass_block
fill ~-11 ~15 ~-6 ~11 ~15 ~-6 grass_block
fill ~-12 ~15 ~-5 ~12 ~15 ~-5 grass_block
fill ~-12 ~15 ~-4 ~12 ~15 ~-4 grass_block
fill ~-12 ~15 ~-3 ~12 ~15 ~-3 grass_block
fill ~-13 ~15 ~-2 ~13 ~15 ~-2 grass_block
fill ~-13 ~15 ~-1 ~13 ~15 ~-1 grass_block
fill ~-13 ~15 ~ ~13 ~15 ~ grass_block
fill ~-13 ~15 ~1 ~13 ~15 ~1 grass_block
fill ~-13 ~15 ~2 ~13 ~15 ~2 grass_block
fill ~-12 ~15 ~3 ~12 ~15 ~3 grass_block
fill ~-12 ~15 ~4 ~12 ~15 ~4 grass_block
fill ~-12 ~15 ~5 ~12 ~15 ~5 grass_block
fill ~-11 ~15 ~6 ~11 ~15 ~6 grass_block
fill ~-11 ~15 ~7 ~11 ~15 ~7 grass_block
fill ~-10 ~15 ~8 ~10 ~15 ~8 grass_block
fill ~-9 ~15 ~9 ~9 ~15 ~9 grass_block
fill ~-8 ~15 ~10 ~8 ~15 ~10 grass_block
fill ~-7 ~15 ~11 ~7 ~15 ~11 grass_block
fill ~-5 ~15 ~12 ~5 ~15 ~12 grass_block
fill ~-2 ~15 ~13 ~2 ~15 ~13 grass_block
place feature minecraft:spruce ~9 ~9 ~16
place feature minecraft:spruce ~18 ~8 ~6
place feature minecraft:spruce ~18 ~8 ~-6
place feature minecraft:spruce ~9 ~9 ~-16
place feature minecraft:spruce ~-10 ~8 ~-16
place feature minecraft:spruce ~-18 ~8 ~-6
place feature minecraft:spruce ~-18 ~8 ~6
place feature minecraft:spruce ~-10 ~8 ~16
fill ~-2 ~ ~-29 ~2 ~5 ~-29 air
fill ~-1 ~ ~-29 ~1 ~ ~-29 stone_brick_stairs[facing=south]
setblock ~-2 ~ ~-29 stone_bricks
setblock ~2 ~ ~-29 stone_bricks
setblock ~-2 ~1 ~-29 stone_brick_wall
setblock ~2 ~1 ~-29 stone_brick_wall
fill ~-2 ~ ~-28 ~2 ~ ~-28 stone_bricks
fill ~-2 ~1 ~-28 ~2 ~6 ~-28 air
fill ~-1 ~1 ~-28 ~1 ~1 ~-28 stone_brick_stairs[facing=south]
setblock ~-2 ~1 ~-28 stone_bricks
setblock ~2 ~1 ~-28 stone_bricks
setblock ~-2 ~2 ~-28 stone_brick_wall
setblock ~2 ~2 ~-28 stone_brick_wall
fill ~-2 ~ ~-27 ~2 ~1 ~-27 stone_bricks
fill ~-2 ~2 ~-27 ~2 ~7 ~-27 air
fill ~-1 ~2 ~-27 ~1 ~2 ~-27 stone_brick_stairs[facing=south]
setblock ~-2 ~2 ~-27 stone_bricks
setblock ~2 ~2 ~-27 stone_bricks
setblock ~-2 ~3 ~-27 stone_brick_wall
setblock ~2 ~3 ~-27 stone_brick_wall
fill ~-2 ~ ~-26 ~2 ~2 ~-26 stone_bricks
fill ~-2 ~3 ~-26 ~2 ~8 ~-26 air
fill ~-1 ~3 ~-26 ~1 ~3 ~-26 stone_brick_stairs[facing=south]
setblock ~-2 ~3 ~-26 stone_bricks
setblock ~2 ~3 ~-26 stone_bricks
setblock ~-2 ~4 ~-26 stone_brick_wall
setblock ~2 ~4 ~-26 stone_brick_wall
setblock ~-2 ~5 ~-26 lantern
setblock ~2 ~5 ~-26 lantern
fill ~-2 ~ ~-25 ~2 ~3 ~-25 stone_bricks
fill ~-2 ~4 ~-25 ~2 ~9 ~-25 air
fill ~-1 ~4 ~-25 ~1 ~4 ~-25 stone_brick_stairs[facing=south]
setblock ~-2 ~4 ~-25 stone_bricks
setblock ~2 ~4 ~-25 stone_bricks
setblock ~-2 ~5 ~-25 stone_brick_wall
setblock ~2 ~5 ~-25 stone_brick_wall
fill ~-2 ~ ~-24 ~2 ~4 ~-24 stone_bricks
fill ~-2 ~5 ~-24 ~2 ~10 ~-24 air
fill ~-1 ~5 ~-24 ~1 ~5 ~-24 stone_brick_stairs[facing=south]
setblock ~-2 ~5 ~-24 stone_bricks
setblock ~2 ~5 ~-24 stone_bricks
setblock ~-2 ~6 ~-24 stone_brick_wall
setblock ~2 ~6 ~-24 stone_brick_wall
fill ~-2 ~ ~-23 ~2 ~5 ~-23 stone_bricks
fill ~-2 ~6 ~-23 ~2 ~11 ~-23 air
fill ~-1 ~6 ~-23 ~1 ~6 ~-23 stone_brick_stairs[facing=south]
setblock ~-2 ~6 ~-23 stone_bricks
setblock ~2 ~6 ~-23 stone_bricks
setblock ~-2 ~7 ~-23 stone_brick_wall
setblock ~2 ~7 ~-23 stone_brick_wall
fill ~-2 ~ ~-22 ~2 ~6 ~-22 stone_bricks
fill ~-2 ~7 ~-22 ~2 ~12 ~-22 air
fill ~-1 ~7 ~-22 ~1 ~7 ~-22 stone_brick_stairs[facing=south]
setblock ~-2 ~7 ~-22 stone_bricks
setblock ~2 ~7 ~-22 stone_bricks
setblock ~-2 ~8 ~-22 stone_brick_wall
setblock ~2 ~8 ~-22 stone_brick_wall
setblock ~-2 ~9 ~-22 lantern
setblock ~2 ~9 ~-22 lantern
fill ~-2 ~ ~-21 ~2 ~7 ~-21 stone_bricks
fill ~-2 ~8 ~-21 ~2 ~13 ~-21 air
fill ~-1 ~8 ~-21 ~1 ~8 ~-21 stone_brick_stairs[facing=south]
setblock ~-2 ~8 ~-21 stone_bricks
setblock ~2 ~8 ~-21 stone_bricks
setblock ~-2 ~9 ~-21 stone_brick_wall
setblock ~2 ~9 ~-21 stone_brick_wall
fill ~-2 ~ ~-20 ~2 ~8 ~-20 stone_bricks
fill ~-2 ~9 ~-20 ~2 ~14 ~-20 air
fill ~-1 ~9 ~-20 ~1 ~9 ~-20 stone_brick_stairs[facing=south]
setblock ~-2 ~9 ~-20 stone_bricks
setblock ~2 ~9 ~-20 stone_bricks
setblock ~-2 ~10 ~-20 stone_brick_wall
setblock ~2 ~10 ~-20 stone_brick_wall
fill ~-2 ~ ~-19 ~2 ~9 ~-19 stone_bricks
fill ~-2 ~10 ~-19 ~2 ~15 ~-19 air
fill ~-1 ~10 ~-19 ~1 ~10 ~-19 stone_brick_stairs[facing=south]
setblock ~-2 ~10 ~-19 stone_bricks
setblock ~2 ~10 ~-19 stone_bricks
setblock ~-2 ~11 ~-19 stone_brick_wall
setblock ~2 ~11 ~-19 stone_brick_wall
fill ~-2 ~ ~-18 ~2 ~10 ~-18 stone_bricks
fill ~-2 ~11 ~-18 ~2 ~16 ~-18 air
fill ~-1 ~11 ~-18 ~1 ~11 ~-18 stone_brick_stairs[facing=south]
setblock ~-2 ~11 ~-18 stone_bricks
setblock ~2 ~11 ~-18 stone_bricks
setblock ~-2 ~12 ~-18 stone_brick_wall
setblock ~2 ~12 ~-18 stone_brick_wall
setblock ~-2 ~13 ~-18 lantern
setblock ~2 ~13 ~-18 lantern
fill ~-2 ~ ~-17 ~2 ~11 ~-17 stone_bricks
fill ~-2 ~12 ~-17 ~2 ~17 ~-17 air
fill ~-1 ~12 ~-17 ~1 ~12 ~-17 stone_brick_stairs[facing=south]
setblock ~-2 ~12 ~-17 stone_bricks
setblock ~2 ~12 ~-17 stone_bricks
setblock ~-2 ~13 ~-17 stone_brick_wall
setblock ~2 ~13 ~-17 stone_brick_wall
fill ~-2 ~ ~-16 ~2 ~12 ~-16 stone_bricks
fill ~-2 ~13 ~-16 ~2 ~18 ~-16 air
fill ~-1 ~13 ~-16 ~1 ~13 ~-16 stone_brick_stairs[facing=south]
setblock ~-2 ~13 ~-16 stone_bricks
setblock ~2 ~13 ~-16 stone_bricks
setblock ~-2 ~14 ~-16 stone_brick_wall
setblock ~2 ~14 ~-16 stone_brick_wall
fill ~-2 ~ ~-15 ~2 ~13 ~-15 stone_bricks
fill ~-2 ~14 ~-15 ~2 ~19 ~-15 air
fill ~-1 ~14 ~-15 ~1 ~14 ~-15 stone_brick_stairs[facing=south]
setblock ~-2 ~14 ~-15 stone_bricks
setblock ~2 ~14 ~-15 stone_bricks
setblock ~-2 ~15 ~-15 stone_brick_wall
setblock ~2 ~15 ~-15 stone_brick_wall
fill ~-2 ~ ~-14 ~2 ~14 ~-14 stone_bricks
fill ~-2 ~15 ~-14 ~2 ~20 ~-14 air
fill ~-1 ~15 ~-14 ~1 ~15 ~-14 stone_brick_stairs[facing=south]
setblock ~-2 ~15 ~-14 stone_bricks
setblock ~2 ~15 ~-14 stone_bricks
setblock ~-2 ~16 ~-14 stone_brick_wall
setblock ~2 ~16 ~-14 stone_brick_wall
setblock ~-2 ~17 ~-14 lantern
setblock ~2 ~17 ~-14 lantern
execute positioned ~-8 ~16 ~-6 run function granjas:_casa_grande
summon minecraft:text_display ~ ~2 ~-31 {billboard:"center",text:{text:"SUBIDA A LA CASA",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Montana lista: sube por la escalera del lado norte. La casa grande esta en la cima.","color":"green"}
