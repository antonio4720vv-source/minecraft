data modify storage granjas:riel l set value {tag:"granjas_mega",y:15,sep:15,bed:"smooth_sandstone",fence:"birch_fence",lamp:"lantern",name:"LINEA DORADA"}
function granjas:_rl_ini with storage granjas:riel l
