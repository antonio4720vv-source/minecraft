execute as @e[type=minecraft:marker,tag=go_hierro] at @s run loot insert ~ ~ ~ loot minecraft:entities/iron_golem
execute as @e[type=minecraft:marker,tag=go_hierro] at @s run loot insert ~ ~ ~ loot minecraft:entities/iron_golem
execute as @e[type=minecraft:marker,tag=go_cana] at @s run loot insert ~ ~ ~ loot minecraft:blocks/sugar_cane
execute as @e[type=minecraft:marker,tag=go_cana] at @s run loot insert ~ ~ ~ loot minecraft:blocks/sugar_cane
execute as @e[type=minecraft:marker,tag=go_cana] at @s run loot insert ~ ~ ~ loot minecraft:blocks/sugar_cane
execute as @e[type=minecraft:marker,tag=go_cana] at @s run loot insert ~ ~ ~ loot minecraft:blocks/sugar_cane
execute as @e[type=minecraft:marker,tag=go_cana] at @s run loot insert ~ ~ ~ loot minecraft:blocks/sugar_cane
execute as @e[type=minecraft:marker,tag=go_comida] at @s run loot insert ~ ~ ~ loot minecraft:blocks/melon
execute as @e[type=minecraft:marker,tag=go_comida] at @s run loot insert ~ ~ ~ loot minecraft:blocks/pumpkin
execute as @e[type=minecraft:marker,tag=go_sandia] at @s run loot insert ~ ~ ~ loot minecraft:blocks/melon
execute as @e[type=minecraft:marker,tag=go_sandia] at @s run loot insert ~ ~ ~ loot minecraft:blocks/melon
execute as @e[type=minecraft:marker,tag=go_mobs] at @s run loot insert ~ ~ ~ loot minecraft:entities/creeper
execute as @e[type=minecraft:marker,tag=go_mobs] at @s run loot insert ~ ~ ~ loot minecraft:entities/creeper
execute as @e[type=minecraft:marker,tag=go_mobs] at @s run loot insert ~ ~ ~ loot minecraft:entities/skeleton
execute as @e[type=minecraft:marker,tag=go_mobs] at @s run loot insert ~ ~ ~ loot minecraft:entities/zombie
execute as @e[type=minecraft:marker,tag=go_mobs] at @s run loot insert ~ ~ ~ loot minecraft:entities/spider
execute as @e[type=minecraft:marker,tag=go_xpbarril] at @s run loot insert ~ ~ ~ loot minecraft:entities/zombie
execute as @e[type=minecraft:marker,tag=go_xp] at @s run xp add @a[distance=..6] 30 points
scoreboard players add #t granjas 1
execute as @e[type=minecraft:marker,tag=go_bebes] at @s store result score @s granjas if entity @e[type=minecraft:villager,distance=..4]
execute if score #t granjas matches 10.. as @e[type=minecraft:marker,tag=go_bebes] at @s if score @s granjas matches ..5 run summon minecraft:villager ~ ~ ~ {Age:-24000}
execute if score #t granjas matches 10.. run scoreboard players set #t granjas 0
