execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~130 ~ ~-110 run forceload add ~ ~
tellraw @a {"text":"[TODO] Empezando la fase 2...","color":"yellow"}
execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~130 ~ ~-110 run function granjas:fase2
