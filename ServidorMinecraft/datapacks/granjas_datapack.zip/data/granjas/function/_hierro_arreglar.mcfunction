tellraw @s {"text":"Arreglando la granja de hierro...","color":"yellow"}
kill @e[type=iron_golem,distance=..40]
fill ~8 ~4 ~8 ~9 ~4 ~9 air
fill ~8 ~3 ~8 ~9 ~3 ~9 soul_campfire[lit=true]
tellraw @s {"text":"Arreglada: ahora los golems caen a un foso con fogatas y mueren. Si no estabas parado DENTRO de la puerta de hierro, no funciono: vuelve a intentarlo.","color":"green"}
