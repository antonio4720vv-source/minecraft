execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega10b
schedule function granjas:_mega11 4s replace
