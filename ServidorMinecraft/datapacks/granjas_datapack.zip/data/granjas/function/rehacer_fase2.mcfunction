execute unless entity @e[type=minecraft:marker,tag=granjas_f2,limit=1] run tellraw @s {"text":"No encuentro la Fase 2. Usa /function granjas:fase2 donde la quieras.","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run function granjas:_f2_0
