forceload remove all
tellraw @s {"text":"Las granjas ya no se mantienen cargadas cuando te alejas.","color":"yellow"}
