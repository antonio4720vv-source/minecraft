kill @e[type=minecraft:marker,tag=granjas_f4]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_f4"]}
function granjas:_f4_0
