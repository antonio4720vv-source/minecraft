tellraw @s {"text":"Construyendo SALA DE COMERCIO v2...","color":"yellow"}
fill ~-4 ~-1 ~-3 ~31 ~5 ~5 air
fill ~-4 ~-1 ~-3 ~31 ~-1 ~5 stone_bricks
fill ~-2 ~-1 ~-3 ~30 ~3 ~4 stone_bricks
fill ~-1 ~ ~2 ~29 ~1 ~3 air
fill ~ ~ ~ ~ ~1 ~ air
setblock ~ ~1 ~1 air
setblock ~ ~ ~-1 blast_furnace
setblock ~ ~2 ~2 glowstone
summon minecraft:villager ~ ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Armero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:armorer",level:1,type:"minecraft:plains"}}
fill ~2 ~ ~ ~2 ~1 ~ air
setblock ~2 ~1 ~1 air
setblock ~2 ~ ~-1 smoker
setblock ~2 ~2 ~2 glowstone
summon minecraft:villager ~2 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Carnicero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:butcher",level:1,type:"minecraft:plains"}}
fill ~4 ~ ~ ~4 ~1 ~ air
setblock ~4 ~1 ~1 air
setblock ~4 ~ ~-1 cartography_table
setblock ~4 ~2 ~2 glowstone
summon minecraft:villager ~4 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Cartografo",CustomNameVisible:1b,VillagerData:{profession:"minecraft:cartographer",level:1,type:"minecraft:plains"}}
fill ~6 ~ ~ ~6 ~1 ~ air
setblock ~6 ~1 ~1 air
setblock ~6 ~ ~-1 brewing_stand
setblock ~6 ~2 ~2 glowstone
summon minecraft:villager ~6 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Clerigo",CustomNameVisible:1b,VillagerData:{profession:"minecraft:cleric",level:1,type:"minecraft:plains"}}
fill ~8 ~ ~ ~8 ~1 ~ air
setblock ~8 ~1 ~1 air
setblock ~8 ~ ~-1 composter
setblock ~8 ~2 ~2 glowstone
summon minecraft:villager ~8 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Granjero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:farmer",level:1,type:"minecraft:plains"}}
fill ~10 ~ ~ ~10 ~1 ~ air
setblock ~10 ~1 ~1 air
setblock ~10 ~ ~-1 barrel
setblock ~10 ~2 ~2 glowstone
summon minecraft:villager ~10 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Pescador",CustomNameVisible:1b,VillagerData:{profession:"minecraft:fisherman",level:1,type:"minecraft:plains"}}
fill ~12 ~ ~ ~12 ~1 ~ air
setblock ~12 ~1 ~1 air
setblock ~12 ~ ~-1 fletching_table
setblock ~12 ~2 ~2 glowstone
summon minecraft:villager ~12 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Flechero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:fletcher",level:1,type:"minecraft:plains"}}
fill ~14 ~ ~ ~14 ~1 ~ air
setblock ~14 ~1 ~1 air
setblock ~14 ~ ~-1 cauldron
setblock ~14 ~2 ~2 glowstone
summon minecraft:villager ~14 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Peletero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:leatherworker",level:1,type:"minecraft:plains"}}
fill ~16 ~ ~ ~16 ~1 ~ air
setblock ~16 ~1 ~1 air
setblock ~16 ~ ~-1 lectern
setblock ~16 ~2 ~2 glowstone
summon minecraft:villager ~16 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 1",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~18 ~ ~ ~18 ~1 ~ air
setblock ~18 ~1 ~1 air
setblock ~18 ~ ~-1 lectern
setblock ~18 ~2 ~2 glowstone
summon minecraft:villager ~18 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 2",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~20 ~ ~ ~20 ~1 ~ air
setblock ~20 ~1 ~1 air
setblock ~20 ~ ~-1 lectern
setblock ~20 ~2 ~2 glowstone
summon minecraft:villager ~20 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 3",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~22 ~ ~ ~22 ~1 ~ air
setblock ~22 ~1 ~1 air
setblock ~22 ~ ~-1 stonecutter
setblock ~22 ~2 ~2 glowstone
summon minecraft:villager ~22 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Albanil",CustomNameVisible:1b,VillagerData:{profession:"minecraft:mason",level:1,type:"minecraft:plains"}}
fill ~24 ~ ~ ~24 ~1 ~ air
setblock ~24 ~1 ~1 air
setblock ~24 ~ ~-1 loom
setblock ~24 ~2 ~2 glowstone
summon minecraft:villager ~24 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Pastor",CustomNameVisible:1b,VillagerData:{profession:"minecraft:shepherd",level:1,type:"minecraft:plains"}}
fill ~26 ~ ~ ~26 ~1 ~ air
setblock ~26 ~1 ~1 air
setblock ~26 ~ ~-1 smithing_table
setblock ~26 ~2 ~2 glowstone
summon minecraft:villager ~26 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Herrero de herramientas",CustomNameVisible:1b,VillagerData:{profession:"minecraft:toolsmith",level:1,type:"minecraft:plains"}}
fill ~28 ~ ~ ~28 ~1 ~ air
setblock ~28 ~1 ~1 air
setblock ~28 ~ ~-1 grindstone
setblock ~28 ~2 ~2 glowstone
summon minecraft:villager ~28 ~ ~ {PersistenceRequired:1b,Xp:1,CustomName:"Herrero de armas",CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:1,type:"minecraft:plains"}}
setblock ~-2 ~ ~2 iron_door[half=lower,facing=east,hinge=left]
setblock ~-2 ~1 ~2 iron_door[half=upper,facing=east,hinge=left]
setblock ~-3 ~1 ~3 stone_button[face=wall,facing=west]
setblock ~-1 ~1 ~3 stone_button[face=wall,facing=east]
summon minecraft:text_display ~-3 ~3 ~2 {billboard:"center",text:{text:"SALA DE COMERCIO\n15 aldeanos con profesion",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Sala de comercio lista: 15 aldeanos (3 bibliotecarios para libros encantados). Cada uno muestra su nombre encima.","color":"green"}
