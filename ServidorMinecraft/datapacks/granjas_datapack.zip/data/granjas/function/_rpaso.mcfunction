scoreboard players set #modo rieles 0
scoreboard players operation #lim rieles = #ady rieles
scoreboard players add #lim rieles 2
scoreboard players operation #m rieles = #i rieles
scoreboard players operation #m rieles %= #8 rieles
scoreboard players operation #m6 rieles = #i rieles
scoreboard players operation #m6 rieles %= #6 rieles
execute if score #ult rieles matches 1 if score #corner rieles matches 0 unless score #dy rieles matches 0 if score #rem rieles <= #lim rieles run scoreboard players set #modo rieles 1
execute if score #modo rieles matches 1 if score #dy rieles matches 1.. run function granjas:_rsube with storage granjas:riel p
execute if score #modo rieles matches 1 if score #dy rieles matches ..-1 run function granjas:_rbaja with storage granjas:riel p
execute if score #modo rieles matches 0 run function granjas:_rplano with storage granjas:riel p
