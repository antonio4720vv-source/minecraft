tellraw @s {"text":"Construyendo PORTAL DEL END decorado...","color":"yellow"}
fill ~-8 ~-1 ~-8 ~8 ~11 ~8 air
fill ~-8 ~-1 ~-8 ~8 ~-1 ~8 end_stone_bricks
fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 purpur_block
fill ~-4 ~-1 ~-4 ~4 ~-1 ~4 obsidian
setblock ~-3 ~-1 ~-3 crying_obsidian
setblock ~3 ~-1 ~-3 crying_obsidian
setblock ~-3 ~-1 ~3 crying_obsidian
setblock ~3 ~-1 ~3 crying_obsidian
setblock ~-1 ~ ~-2 end_portal_frame[eye=true,facing=south]
setblock ~-1 ~ ~2 end_portal_frame[eye=true,facing=north]
setblock ~-2 ~ ~-1 end_portal_frame[eye=true,facing=east]
setblock ~2 ~ ~-1 end_portal_frame[eye=true,facing=west]
setblock ~ ~ ~-2 end_portal_frame[eye=true,facing=south]
setblock ~ ~ ~2 end_portal_frame[eye=true,facing=north]
setblock ~-2 ~ ~ end_portal_frame[eye=true,facing=east]
setblock ~2 ~ ~ end_portal_frame[eye=true,facing=west]
setblock ~1 ~ ~-2 end_portal_frame[eye=true,facing=south]
setblock ~1 ~ ~2 end_portal_frame[eye=true,facing=north]
setblock ~-2 ~ ~1 end_portal_frame[eye=true,facing=east]
setblock ~2 ~ ~1 end_portal_frame[eye=true,facing=west]
fill ~-1 ~ ~-1 ~1 ~ ~1 end_portal
fill ~-6 ~ ~-6 ~-6 ~4 ~-6 purpur_pillar
setblock ~-6 ~5 ~-6 purpur_block
setblock ~-6 ~6 ~-6 end_rod[facing=up]
fill ~6 ~ ~-6 ~6 ~4 ~-6 purpur_pillar
setblock ~6 ~5 ~-6 purpur_block
setblock ~6 ~6 ~-6 end_rod[facing=up]
fill ~-6 ~ ~6 ~-6 ~4 ~6 purpur_pillar
setblock ~-6 ~5 ~6 purpur_block
setblock ~-6 ~6 ~6 end_rod[facing=up]
fill ~6 ~ ~6 ~6 ~4 ~6 purpur_pillar
setblock ~6 ~5 ~6 purpur_block
setblock ~6 ~6 ~6 end_rod[facing=up]
fill ~-6 ~ ~ ~-6 ~1 ~ end_stone_brick_wall
setblock ~-6 ~2 ~ soul_lantern
fill ~6 ~ ~ ~6 ~1 ~ end_stone_brick_wall
setblock ~6 ~2 ~ soul_lantern
fill ~ ~ ~-6 ~ ~1 ~-6 end_stone_brick_wall
setblock ~ ~2 ~-6 soul_lantern
fill ~ ~ ~6 ~ ~1 ~6 end_stone_brick_wall
setblock ~ ~2 ~6 soul_lantern
setblock ~-4 ~ ~-4 obsidian
setblock ~-4 ~1 ~-4 dragon_head[rotation=0]
setblock ~4 ~ ~-4 obsidian
setblock ~4 ~1 ~-4 dragon_head[rotation=0]
setblock ~-4 ~ ~4 obsidian
setblock ~-4 ~1 ~4 dragon_head[rotation=8]
setblock ~4 ~ ~4 obsidian
setblock ~4 ~1 ~4 dragon_head[rotation=8]
fill ~-8 ~ ~-8 ~8 ~ ~-8 end_stone_brick_wall
fill ~-8 ~ ~8 ~-1 ~ ~8 end_stone_brick_wall
fill ~1 ~ ~8 ~8 ~ ~8 end_stone_brick_wall
fill ~-8 ~ ~-8 ~-8 ~ ~8 end_stone_brick_wall
fill ~8 ~ ~-8 ~8 ~ ~8 end_stone_brick_wall
summon minecraft:text_display ~ ~4 ~ {billboard:"center",text:{text:"PORTAL AL END",color:"light_purple",bold:1b},background:1073741824}
tellraw @s {"text":"Portal del End listo. Cuidado: al pisar el centro viajas al End. Lleva buena armadura, comida y bloques.","color":"green"}
