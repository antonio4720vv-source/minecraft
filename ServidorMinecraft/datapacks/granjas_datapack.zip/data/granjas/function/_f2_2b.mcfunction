tellraw @a {"text":"[Fase 2] Establo con 10 granjas de animales...","color":"yellow"}
fill ~3 ~-1 ~3 ~54 ~-1 ~17 stone_bricks
fill ~4 ~ ~4 ~53 ~4 ~16 air
fill ~3 ~ ~3 ~54 ~4 ~3 glass
fill ~3 ~ ~17 ~54 ~4 ~17 glass
fill ~3 ~ ~3 ~3 ~4 ~17 glass
fill ~54 ~ ~3 ~54 ~4 ~17 glass
fill ~3 ~ ~3 ~3 ~4 ~3 stripped_spruce_log
fill ~3 ~ ~17 ~3 ~4 ~17 stripped_spruce_log
fill ~13 ~ ~3 ~13 ~4 ~3 stripped_spruce_log
fill ~13 ~ ~17 ~13 ~4 ~17 stripped_spruce_log
fill ~23 ~ ~3 ~23 ~4 ~3 stripped_spruce_log
fill ~23 ~ ~17 ~23 ~4 ~17 stripped_spruce_log
fill ~33 ~ ~3 ~33 ~4 ~3 stripped_spruce_log
fill ~33 ~ ~17 ~33 ~4 ~17 stripped_spruce_log
fill ~43 ~ ~3 ~43 ~4 ~3 stripped_spruce_log
fill ~43 ~ ~17 ~43 ~4 ~17 stripped_spruce_log
fill ~53 ~ ~3 ~53 ~4 ~3 stripped_spruce_log
fill ~53 ~ ~17 ~53 ~4 ~17 stripped_spruce_log
fill ~4 ~-1 ~14 ~53 ~-1 ~16 spruce_planks
setblock ~8 ~3 ~15 light[level=15]
setblock ~16 ~3 ~15 light[level=15]
setblock ~24 ~3 ~15 light[level=15]
setblock ~32 ~3 ~15 light[level=15]
setblock ~40 ~3 ~15 light[level=15]
setblock ~48 ~3 ~15 light[level=15]
fill ~3 ~5 ~3 ~54 ~5 ~17 stone_bricks
fill ~4 ~6 ~4 ~53 ~10 ~16 air
fill ~3 ~6 ~3 ~54 ~10 ~3 glass
fill ~3 ~6 ~17 ~54 ~10 ~17 glass
fill ~3 ~6 ~3 ~3 ~10 ~17 glass
fill ~54 ~6 ~3 ~54 ~10 ~17 glass
fill ~3 ~6 ~3 ~3 ~10 ~3 stripped_spruce_log
fill ~3 ~6 ~17 ~3 ~10 ~17 stripped_spruce_log
fill ~13 ~6 ~3 ~13 ~10 ~3 stripped_spruce_log
fill ~13 ~6 ~17 ~13 ~10 ~17 stripped_spruce_log
fill ~23 ~6 ~3 ~23 ~10 ~3 stripped_spruce_log
fill ~23 ~6 ~17 ~23 ~10 ~17 stripped_spruce_log
fill ~33 ~6 ~3 ~33 ~10 ~3 stripped_spruce_log
fill ~33 ~6 ~17 ~33 ~10 ~17 stripped_spruce_log
fill ~43 ~6 ~3 ~43 ~10 ~3 stripped_spruce_log
fill ~43 ~6 ~17 ~43 ~10 ~17 stripped_spruce_log
fill ~53 ~6 ~3 ~53 ~10 ~3 stripped_spruce_log
fill ~53 ~6 ~17 ~53 ~10 ~17 stripped_spruce_log
fill ~4 ~5 ~14 ~53 ~5 ~16 spruce_planks
setblock ~8 ~9 ~15 light[level=15]
setblock ~16 ~9 ~15 light[level=15]
setblock ~24 ~9 ~15 light[level=15]
setblock ~32 ~9 ~15 light[level=15]
setblock ~40 ~9 ~15 light[level=15]
setblock ~48 ~9 ~15 light[level=15]
fill ~3 ~11 ~3 ~54 ~11 ~17 spruce_planks
setblock ~3 ~12 ~3 lantern
setblock ~3 ~12 ~17 lantern
setblock ~8 ~12 ~3 lantern
setblock ~8 ~12 ~17 lantern
setblock ~13 ~12 ~3 lantern
setblock ~13 ~12 ~17 lantern
setblock ~18 ~12 ~3 lantern
setblock ~18 ~12 ~17 lantern
setblock ~23 ~12 ~3 lantern
setblock ~23 ~12 ~17 lantern
setblock ~28 ~12 ~3 lantern
setblock ~28 ~12 ~17 lantern
setblock ~33 ~12 ~3 lantern
setblock ~33 ~12 ~17 lantern
setblock ~38 ~12 ~3 lantern
setblock ~38 ~12 ~17 lantern
setblock ~43 ~12 ~3 lantern
setblock ~43 ~12 ~17 lantern
setblock ~48 ~12 ~3 lantern
setblock ~48 ~12 ~17 lantern
setblock ~53 ~12 ~3 lantern
setblock ~53 ~12 ~17 lantern
fill ~54 ~ ~15 ~54 ~1 ~15 air
setblock ~55 ~ ~14 lantern
setblock ~55 ~ ~16 lantern
fill ~4 ~ ~16 ~4 ~10 ~16 ladder[facing=east]
summon minecraft:text_display ~56 ~3 ~15 {billboard:"center",text:{text:"ESTABLO\n10 granjas de animales\nescalera adentro (oeste)",color:"gold",bold:1b},background:1073741824}
fill ~4 ~-1 ~4 ~12 ~-1 ~12 grass_block
fill ~13 ~ ~4 ~13 ~ ~13 oak_fence
fill ~4 ~ ~13 ~12 ~ ~13 oak_fence
setblock ~8 ~ ~13 oak_fence_gate[facing=south]
setblock ~4 ~ ~4 hay_block
setblock ~12 ~ ~4 water_cauldron[level=3]
setblock ~6 ~3 ~6 light[level=15]
setblock ~10 ~3 ~10 light[level=15]
setblock ~6 ~3 ~10 light[level=15]
setblock ~10 ~3 ~6 light[level=15]
summon minecraft:cow ~6 ~ ~7 {PersistenceRequired:1b}
summon minecraft:cow ~8 ~ ~7 {PersistenceRequired:1b}
summon minecraft:cow ~10 ~ ~7 {PersistenceRequired:1b}
summon minecraft:cow ~6 ~ ~9 {PersistenceRequired:1b}
setblock ~9 ~ ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:bucket",count:4}]}
summon minecraft:text_display ~8 ~3 ~9 {billboard:"center",text:{text:"VACAS",color:"yellow",bold:1b},background:1073741824}
fill ~14 ~-1 ~4 ~22 ~-1 ~12 grass_block
fill ~23 ~ ~4 ~23 ~ ~13 oak_fence
fill ~14 ~ ~13 ~22 ~ ~13 oak_fence
setblock ~18 ~ ~13 oak_fence_gate[facing=south]
setblock ~14 ~ ~4 hay_block
setblock ~22 ~ ~4 water_cauldron[level=3]
setblock ~16 ~3 ~6 light[level=15]
setblock ~20 ~3 ~10 light[level=15]
setblock ~16 ~3 ~10 light[level=15]
setblock ~20 ~3 ~6 light[level=15]
summon minecraft:sheep ~16 ~ ~7 {PersistenceRequired:1b}
summon minecraft:sheep ~18 ~ ~7 {PersistenceRequired:1b}
summon minecraft:sheep ~20 ~ ~7 {PersistenceRequired:1b}
summon minecraft:sheep ~16 ~ ~9 {PersistenceRequired:1b}
setblock ~19 ~ ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:shears",count:1}]}
summon minecraft:text_display ~18 ~3 ~9 {billboard:"center",text:{text:"OVEJAS",color:"yellow",bold:1b},background:1073741824}
fill ~24 ~-1 ~4 ~32 ~-1 ~12 grass_block
fill ~33 ~ ~4 ~33 ~ ~13 oak_fence
fill ~24 ~ ~13 ~32 ~ ~13 oak_fence
setblock ~28 ~ ~13 oak_fence_gate[facing=south]
setblock ~24 ~ ~4 hay_block
setblock ~32 ~ ~4 water_cauldron[level=3]
setblock ~26 ~3 ~6 light[level=15]
setblock ~30 ~3 ~10 light[level=15]
setblock ~26 ~3 ~10 light[level=15]
setblock ~30 ~3 ~6 light[level=15]
summon minecraft:pig ~26 ~ ~7 {PersistenceRequired:1b}
summon minecraft:pig ~28 ~ ~7 {PersistenceRequired:1b}
summon minecraft:pig ~30 ~ ~7 {PersistenceRequired:1b}
summon minecraft:pig ~26 ~ ~9 {PersistenceRequired:1b}
setblock ~29 ~ ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:carrot",count:64}]}
summon minecraft:text_display ~28 ~3 ~9 {billboard:"center",text:{text:"CERDOS",color:"yellow",bold:1b},background:1073741824}
fill ~34 ~-1 ~4 ~42 ~-1 ~12 grass_block
fill ~43 ~ ~4 ~43 ~ ~13 oak_fence
fill ~34 ~ ~13 ~42 ~ ~13 oak_fence
setblock ~38 ~ ~13 oak_fence_gate[facing=south]
setblock ~34 ~ ~4 hay_block
setblock ~42 ~ ~4 water_cauldron[level=3]
setblock ~36 ~3 ~6 light[level=15]
setblock ~40 ~3 ~10 light[level=15]
setblock ~36 ~3 ~10 light[level=15]
setblock ~40 ~3 ~6 light[level=15]
summon minecraft:chicken ~36 ~ ~7 {PersistenceRequired:1b}
summon minecraft:chicken ~38 ~ ~7 {PersistenceRequired:1b}
summon minecraft:chicken ~40 ~ ~7 {PersistenceRequired:1b}
summon minecraft:chicken ~36 ~ ~9 {PersistenceRequired:1b}
summon minecraft:chicken ~38 ~ ~9 {PersistenceRequired:1b}
summon minecraft:chicken ~40 ~ ~9 {PersistenceRequired:1b}
setblock ~39 ~ ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat_seeds",count:64}]}
summon minecraft:text_display ~38 ~3 ~9 {billboard:"center",text:{text:"GALLINAS",color:"yellow",bold:1b},background:1073741824}
fill ~44 ~-1 ~4 ~52 ~-1 ~12 grass_block
fill ~53 ~ ~4 ~53 ~ ~13 oak_fence
fill ~44 ~ ~13 ~52 ~ ~13 oak_fence
setblock ~48 ~ ~13 oak_fence_gate[facing=south]
setblock ~44 ~ ~4 hay_block
setblock ~52 ~ ~4 water_cauldron[level=3]
setblock ~46 ~3 ~6 light[level=15]
setblock ~50 ~3 ~10 light[level=15]
setblock ~46 ~3 ~10 light[level=15]
setblock ~50 ~3 ~6 light[level=15]
summon minecraft:rabbit ~46 ~ ~7 {PersistenceRequired:1b}
summon minecraft:rabbit ~48 ~ ~7 {PersistenceRequired:1b}
summon minecraft:rabbit ~50 ~ ~7 {PersistenceRequired:1b}
summon minecraft:rabbit ~46 ~ ~9 {PersistenceRequired:1b}
setblock ~49 ~ ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:carrot",count:64},{Slot:1b,id:"minecraft:dandelion",count:32}]}
summon minecraft:text_display ~48 ~3 ~9 {billboard:"center",text:{text:"CONEJOS",color:"yellow",bold:1b},background:1073741824}
fill ~4 ~5 ~4 ~12 ~5 ~12 grass_block
fill ~13 ~6 ~4 ~13 ~6 ~13 oak_fence
fill ~4 ~6 ~13 ~12 ~6 ~13 oak_fence
setblock ~8 ~6 ~13 oak_fence_gate[facing=south]
setblock ~4 ~6 ~4 hay_block
setblock ~12 ~6 ~4 water_cauldron[level=3]
setblock ~6 ~9 ~6 light[level=15]
setblock ~10 ~9 ~10 light[level=15]
setblock ~6 ~9 ~10 light[level=15]
setblock ~10 ~9 ~6 light[level=15]
summon minecraft:goat ~6 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:goat ~8 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:goat ~10 ~6 ~7 {PersistenceRequired:1b}
setblock ~9 ~6 ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:bucket",count:2}]}
summon minecraft:text_display ~8 ~9 ~9 {billboard:"center",text:{text:"CABRAS",color:"yellow",bold:1b},background:1073741824}
fill ~14 ~5 ~4 ~22 ~5 ~12 grass_block
fill ~23 ~6 ~4 ~23 ~6 ~13 oak_fence
fill ~14 ~6 ~13 ~22 ~6 ~13 oak_fence
setblock ~18 ~6 ~13 oak_fence_gate[facing=south]
setblock ~14 ~6 ~4 hay_block
setblock ~22 ~6 ~4 water_cauldron[level=3]
setblock ~16 ~9 ~6 light[level=15]
setblock ~20 ~9 ~10 light[level=15]
setblock ~16 ~9 ~10 light[level=15]
setblock ~20 ~9 ~6 light[level=15]
fill ~14 ~5 ~4 ~22 ~5 ~12 mycelium
summon minecraft:mooshroom ~16 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:mooshroom ~18 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:mooshroom ~20 ~6 ~7 {PersistenceRequired:1b}
setblock ~19 ~6 ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:bowl",count:16}]}
summon minecraft:text_display ~18 ~9 ~9 {billboard:"center",text:{text:"CHAMPINACAS",color:"yellow",bold:1b},background:1073741824}
fill ~24 ~5 ~4 ~32 ~5 ~12 grass_block
fill ~33 ~6 ~4 ~33 ~6 ~13 oak_fence
fill ~24 ~6 ~13 ~32 ~6 ~13 oak_fence
setblock ~28 ~6 ~13 oak_fence_gate[facing=south]
setblock ~24 ~6 ~4 hay_block
setblock ~32 ~6 ~4 water_cauldron[level=3]
setblock ~26 ~9 ~6 light[level=15]
setblock ~30 ~9 ~10 light[level=15]
setblock ~26 ~9 ~10 light[level=15]
setblock ~30 ~9 ~6 light[level=15]
summon minecraft:llama ~26 ~6 ~7 {PersistenceRequired:1b,Tame:1b}
summon minecraft:llama ~28 ~6 ~7 {PersistenceRequired:1b,Tame:1b}
summon minecraft:llama ~30 ~6 ~7 {PersistenceRequired:1b,Tame:1b}
setblock ~29 ~6 ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:hay_block",count:32},{Slot:1b,id:"minecraft:lead",count:4}]}
summon minecraft:text_display ~28 ~9 ~9 {billboard:"center",text:{text:"LLAMAS",color:"yellow",bold:1b},background:1073741824}
fill ~34 ~5 ~4 ~42 ~5 ~12 grass_block
fill ~43 ~6 ~4 ~43 ~6 ~13 oak_fence
fill ~34 ~6 ~13 ~42 ~6 ~13 oak_fence
setblock ~38 ~6 ~13 oak_fence_gate[facing=south]
setblock ~34 ~6 ~4 hay_block
setblock ~42 ~6 ~4 water_cauldron[level=3]
setblock ~36 ~9 ~6 light[level=15]
setblock ~40 ~9 ~10 light[level=15]
setblock ~36 ~9 ~10 light[level=15]
setblock ~40 ~9 ~6 light[level=15]
summon minecraft:armadillo ~36 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:armadillo ~38 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:armadillo ~40 ~6 ~7 {PersistenceRequired:1b}
setblock ~39 ~6 ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:spider_eye",count:32},{Slot:1b,id:"minecraft:brush",count:1}]}
summon minecraft:text_display ~38 ~9 ~9 {billboard:"center",text:{text:"ARMADILLOS",color:"yellow",bold:1b},background:1073741824}
fill ~44 ~5 ~4 ~52 ~5 ~12 grass_block
fill ~53 ~6 ~4 ~53 ~6 ~13 oak_fence
fill ~44 ~6 ~13 ~52 ~6 ~13 oak_fence
setblock ~48 ~6 ~13 oak_fence_gate[facing=south]
setblock ~44 ~6 ~4 hay_block
setblock ~52 ~6 ~4 water_cauldron[level=3]
setblock ~46 ~9 ~6 light[level=15]
setblock ~50 ~9 ~10 light[level=15]
setblock ~46 ~9 ~10 light[level=15]
setblock ~50 ~9 ~6 light[level=15]
setblock ~46 ~6 ~4 beehive[facing=south,honey_level=5]
setblock ~50 ~6 ~4 beehive[facing=south,honey_level=5]
setblock ~45 ~6 ~7 poppy
setblock ~45 ~6 ~9 cornflower
setblock ~45 ~6 ~11 poppy
setblock ~47 ~6 ~7 cornflower
setblock ~47 ~6 ~9 poppy
setblock ~47 ~6 ~11 cornflower
setblock ~49 ~6 ~7 poppy
setblock ~49 ~6 ~9 cornflower
setblock ~49 ~6 ~11 poppy
setblock ~51 ~6 ~7 cornflower
setblock ~51 ~6 ~9 poppy
setblock ~51 ~6 ~11 cornflower
summon minecraft:bee ~46 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:bee ~48 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:bee ~50 ~6 ~7 {PersistenceRequired:1b}
summon minecraft:bee ~46 ~6 ~9 {PersistenceRequired:1b}
setblock ~49 ~6 ~14 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:glass_bottle",count:32},{Slot:1b,id:"minecraft:shears",count:1}]}
summon minecraft:text_display ~48 ~9 ~9 {billboard:"center",text:{text:"ABEJAS",color:"yellow",bold:1b},background:1073741824}
