scoreboard players set #corner rieles 0
data modify storage granjas:riel p.shape set value "north_south"
