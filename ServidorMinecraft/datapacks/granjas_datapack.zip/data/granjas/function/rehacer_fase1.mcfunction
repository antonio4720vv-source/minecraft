execute unless entity @e[type=minecraft:marker,tag=granjas_f1,limit=1] run tellraw @s {"text":"No encuentro la Fase 1. Usa /function granjas:fase1 donde la quieras.","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_f1,limit=1] run function granjas:_f1_0
