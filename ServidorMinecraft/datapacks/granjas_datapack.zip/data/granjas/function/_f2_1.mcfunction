execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run function granjas:_f2_1b
schedule function granjas:_f2_2 3s replace
