data modify storage granjas:riel l set value {tag:"granjas_f2",y:7,sep:9,bed:"mossy_stone_bricks",fence:"oak_fence",lamp:"lantern",name:"LINEA VERDE"}
function granjas:_rl_ini with storage granjas:riel l
