function granjas:_rl_ejez
scoreboard players set #corner rieles 1
execute if score #sx rieles matches 1 if score #sz rieles matches 1 run data modify storage granjas:riel p.shape set value "south_west"
execute if score #sx rieles matches 1 if score #sz rieles matches -1 run data modify storage granjas:riel p.shape set value "north_west"
execute if score #sx rieles matches -1 if score #sz rieles matches 1 run data modify storage granjas:riel p.shape set value "south_east"
execute if score #sx rieles matches -1 if score #sz rieles matches -1 run data modify storage granjas:riel p.shape set value "north_east"
