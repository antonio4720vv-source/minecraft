scoreboard players set #on granjas 1
schedule function granjas:producir 30s replace
tellraw @a {"text":"Produccion asegurada ACTIVADA: cada 30 segundos las granjas llenan sus barriles aunque el mecanismo falle.","color":"green"}
