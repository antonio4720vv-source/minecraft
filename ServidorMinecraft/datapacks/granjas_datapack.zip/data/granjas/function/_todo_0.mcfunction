kill @e[type=minecraft:marker,tag=granjas_todo]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_todo"]}
forceload add ~ ~
tellraw @a {"text":"[TODO] Se construye todo el megaproyecto en unos 4 minutos: fase 1, 2, 3 y al final la 4 con las vias. No te alejes ni apagues el servidor.","color":"gold"}
function granjas:_todo_1
schedule function granjas:_todo_2 35s replace
schedule function granjas:_todo_3 75s replace
schedule function granjas:_todo_4 125s replace
