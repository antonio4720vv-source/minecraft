$execute unless entity @e[type=minecraft:marker,tag=$(tag)] run function granjas:_rl_salta with storage granjas:riel l
$execute if entity @e[type=minecraft:marker,tag=$(tag)] run function granjas:_rl_prep with storage granjas:riel l
