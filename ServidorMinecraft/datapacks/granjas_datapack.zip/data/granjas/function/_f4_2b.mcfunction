tellraw @a {"text":"[Fase 4] Estacion central, plaza y estatua...","color":"yellow"}
fill ~-1 ~-1 ~-13 ~7 ~18 ~-7 stone_bricks
fill ~ ~ ~-12 ~6 ~17 ~-8 air
fill ~-1 ~1 ~-13 ~7 ~17 ~-13 glass
fill ~-1 ~1 ~-7 ~7 ~17 ~-7 glass
fill ~-1 ~1 ~-13 ~-1 ~17 ~-7 glass
fill ~7 ~1 ~-13 ~7 ~17 ~-7 glass
fill ~-1 ~ ~-13 ~-1 ~18 ~-13 stripped_oak_log
fill ~7 ~ ~-13 ~7 ~18 ~-13 stripped_oak_log
fill ~-1 ~ ~-7 ~-1 ~18 ~-7 stripped_oak_log
fill ~7 ~ ~-7 ~7 ~18 ~-7 stripped_oak_log
fill ~-1 ~18 ~-13 ~7 ~18 ~-7 oak_planks
fill ~ ~3 ~-12 ~6 ~3 ~-8 red_nether_bricks
fill ~-1 ~4 ~-10 ~-1 ~5 ~-10 air
fill ~7 ~4 ~-10 ~7 ~5 ~-10 air
fill ~3 ~4 ~-13 ~3 ~5 ~-13 air
fill ~3 ~4 ~-7 ~3 ~5 ~-7 air
summon minecraft:text_display ~3 ~6 ~-12 {billboard:"center",text:{text:"LINEA ROJA - FASE 1 (hierro y aldeanos)",color:"red",bold:1b},background:1073741824}
setblock ~5 ~6 ~-12 lantern[hanging=true]
fill ~ ~7 ~-12 ~6 ~7 ~-8 mossy_stone_bricks
fill ~-1 ~8 ~-10 ~-1 ~9 ~-10 air
fill ~7 ~8 ~-10 ~7 ~9 ~-10 air
fill ~3 ~8 ~-13 ~3 ~9 ~-13 air
fill ~3 ~8 ~-7 ~3 ~9 ~-7 air
summon minecraft:text_display ~3 ~10 ~-12 {billboard:"center",text:{text:"LINEA VERDE - FASE 2 (animales y cultivos)",color:"green",bold:1b},background:1073741824}
setblock ~5 ~10 ~-12 lantern[hanging=true]
fill ~ ~11 ~-12 ~6 ~11 ~-8 polished_deepslate
fill ~-1 ~12 ~-10 ~-1 ~13 ~-10 air
fill ~7 ~12 ~-10 ~7 ~13 ~-10 air
fill ~3 ~12 ~-13 ~3 ~13 ~-13 air
fill ~3 ~12 ~-7 ~3 ~13 ~-7 air
summon minecraft:text_display ~3 ~14 ~-12 {billboard:"center",text:{text:"LINEA AZUL - FASE 3 (casas y portales)",color:"aqua",bold:1b},background:1073741824}
setblock ~5 ~14 ~-12 lantern[hanging=true]
fill ~ ~15 ~-12 ~6 ~15 ~-8 smooth_sandstone
fill ~-1 ~16 ~-10 ~-1 ~17 ~-10 air
fill ~7 ~16 ~-10 ~7 ~17 ~-10 air
fill ~3 ~16 ~-13 ~3 ~17 ~-13 air
fill ~3 ~16 ~-7 ~3 ~17 ~-7 air
summon minecraft:text_display ~3 ~18 ~-12 {billboard:"center",text:{text:"LINEA DORADA - MEGABASE",color:"gold",bold:1b},background:1073741824}
setblock ~5 ~18 ~-12 lantern[hanging=true]
fill ~1 ~ ~-12 ~1 ~17 ~-12 ladder[facing=south]
fill ~2 ~ ~-7 ~4 ~1 ~-7 air
summon minecraft:text_display ~3 ~3 ~-5 {billboard:"center",text:{text:"ESTACION CENTRAL\nsube por la escalera: 1 piso por linea",color:"gold",bold:1b},background:1073741824}
fill ~26 ~-1 ~5 ~26 ~-1 ~5 grass_block
fill ~21 ~-1 ~6 ~31 ~-1 ~6 grass_block
fill ~18 ~-1 ~7 ~34 ~-1 ~7 grass_block
fill ~17 ~-1 ~8 ~35 ~-1 ~8 grass_block
fill ~21 ~-1 ~8 ~31 ~-1 ~8 polished_andesite
fill ~16 ~-1 ~9 ~36 ~-1 ~9 grass_block
fill ~19 ~-1 ~9 ~33 ~-1 ~9 polished_andesite
fill ~14 ~-1 ~10 ~38 ~-1 ~10 grass_block
fill ~17 ~-1 ~10 ~35 ~-1 ~10 polished_andesite
fill ~14 ~-1 ~11 ~38 ~-1 ~11 grass_block
fill ~16 ~-1 ~11 ~36 ~-1 ~11 polished_andesite
fill ~13 ~-1 ~12 ~39 ~-1 ~12 grass_block
fill ~15 ~-1 ~12 ~37 ~-1 ~12 polished_andesite
fill ~12 ~-1 ~13 ~40 ~-1 ~13 grass_block
fill ~14 ~-1 ~13 ~38 ~-1 ~13 polished_andesite
fill ~11 ~-1 ~14 ~41 ~-1 ~14 grass_block
fill ~14 ~-1 ~14 ~38 ~-1 ~14 polished_andesite
fill ~11 ~-1 ~15 ~41 ~-1 ~15 grass_block
fill ~13 ~-1 ~15 ~39 ~-1 ~15 polished_andesite
fill ~11 ~-1 ~16 ~41 ~-1 ~16 grass_block
fill ~13 ~-1 ~16 ~39 ~-1 ~16 polished_andesite
fill ~10 ~-1 ~17 ~42 ~-1 ~17 grass_block
fill ~12 ~-1 ~17 ~40 ~-1 ~17 polished_andesite
fill ~10 ~-1 ~18 ~42 ~-1 ~18 grass_block
fill ~12 ~-1 ~18 ~40 ~-1 ~18 polished_andesite
fill ~10 ~-1 ~19 ~42 ~-1 ~19 grass_block
fill ~12 ~-1 ~19 ~40 ~-1 ~19 polished_andesite
fill ~10 ~-1 ~20 ~42 ~-1 ~20 grass_block
fill ~12 ~-1 ~20 ~40 ~-1 ~20 polished_andesite
fill ~10 ~-1 ~21 ~42 ~-1 ~21 grass_block
fill ~12 ~-1 ~21 ~40 ~-1 ~21 polished_andesite
fill ~9 ~-1 ~22 ~43 ~-1 ~22 grass_block
fill ~11 ~-1 ~22 ~41 ~-1 ~22 polished_andesite
fill ~10 ~-1 ~23 ~42 ~-1 ~23 grass_block
fill ~12 ~-1 ~23 ~40 ~-1 ~23 polished_andesite
fill ~10 ~-1 ~24 ~42 ~-1 ~24 grass_block
fill ~12 ~-1 ~24 ~40 ~-1 ~24 polished_andesite
fill ~10 ~-1 ~25 ~42 ~-1 ~25 grass_block
fill ~12 ~-1 ~25 ~40 ~-1 ~25 polished_andesite
fill ~10 ~-1 ~26 ~42 ~-1 ~26 grass_block
fill ~12 ~-1 ~26 ~40 ~-1 ~26 polished_andesite
fill ~10 ~-1 ~27 ~42 ~-1 ~27 grass_block
fill ~12 ~-1 ~27 ~40 ~-1 ~27 polished_andesite
fill ~11 ~-1 ~28 ~41 ~-1 ~28 grass_block
fill ~13 ~-1 ~28 ~39 ~-1 ~28 polished_andesite
fill ~11 ~-1 ~29 ~41 ~-1 ~29 grass_block
fill ~13 ~-1 ~29 ~39 ~-1 ~29 polished_andesite
fill ~11 ~-1 ~30 ~41 ~-1 ~30 grass_block
fill ~14 ~-1 ~30 ~38 ~-1 ~30 polished_andesite
fill ~12 ~-1 ~31 ~40 ~-1 ~31 grass_block
fill ~14 ~-1 ~31 ~38 ~-1 ~31 polished_andesite
fill ~13 ~-1 ~32 ~39 ~-1 ~32 grass_block
fill ~15 ~-1 ~32 ~37 ~-1 ~32 polished_andesite
fill ~14 ~-1 ~33 ~38 ~-1 ~33 grass_block
fill ~16 ~-1 ~33 ~36 ~-1 ~33 polished_andesite
fill ~14 ~-1 ~34 ~38 ~-1 ~34 grass_block
fill ~17 ~-1 ~34 ~35 ~-1 ~34 polished_andesite
fill ~16 ~-1 ~35 ~36 ~-1 ~35 grass_block
fill ~19 ~-1 ~35 ~33 ~-1 ~35 polished_andesite
fill ~17 ~-1 ~36 ~35 ~-1 ~36 grass_block
fill ~21 ~-1 ~36 ~31 ~-1 ~36 polished_andesite
fill ~18 ~-1 ~37 ~34 ~-1 ~37 grass_block
fill ~21 ~-1 ~38 ~31 ~-1 ~38 grass_block
fill ~26 ~-1 ~39 ~26 ~-1 ~39 grass_block
fill ~26 ~-1 ~11 ~26 ~-1 ~11 smooth_stone
fill ~22 ~-1 ~12 ~30 ~-1 ~12 smooth_stone
fill ~20 ~-1 ~13 ~32 ~-1 ~13 smooth_stone
fill ~19 ~-1 ~14 ~33 ~-1 ~14 smooth_stone
fill ~18 ~-1 ~15 ~34 ~-1 ~15 smooth_stone
fill ~17 ~-1 ~16 ~35 ~-1 ~16 smooth_stone
fill ~17 ~-1 ~17 ~35 ~-1 ~17 smooth_stone
fill ~16 ~-1 ~18 ~36 ~-1 ~18 smooth_stone
fill ~16 ~-1 ~19 ~36 ~-1 ~19 smooth_stone
fill ~16 ~-1 ~20 ~36 ~-1 ~20 smooth_stone
fill ~16 ~-1 ~21 ~36 ~-1 ~21 smooth_stone
fill ~15 ~-1 ~22 ~37 ~-1 ~22 smooth_stone
fill ~16 ~-1 ~23 ~36 ~-1 ~23 smooth_stone
fill ~16 ~-1 ~24 ~36 ~-1 ~24 smooth_stone
fill ~16 ~-1 ~25 ~36 ~-1 ~25 smooth_stone
fill ~16 ~-1 ~26 ~36 ~-1 ~26 smooth_stone
fill ~17 ~-1 ~27 ~35 ~-1 ~27 smooth_stone
fill ~17 ~-1 ~28 ~35 ~-1 ~28 smooth_stone
fill ~18 ~-1 ~29 ~34 ~-1 ~29 smooth_stone
fill ~19 ~-1 ~30 ~33 ~-1 ~30 smooth_stone
fill ~20 ~-1 ~31 ~32 ~-1 ~31 smooth_stone
fill ~22 ~-1 ~32 ~30 ~-1 ~32 smooth_stone
fill ~26 ~-1 ~33 ~26 ~-1 ~33 smooth_stone
setblock ~42 ~ ~22 azalea
setblock ~41 ~ ~26 flowering_azalea
setblock ~40 ~ ~30 allium
setblock ~37 ~ ~33 oxeye_daisy
setblock ~34 ~ ~36 azalea
setblock ~30 ~ ~37 flowering_azalea
setblock ~26 ~ ~38 allium
setblock ~22 ~ ~37 oxeye_daisy
setblock ~18 ~ ~36 azalea
setblock ~15 ~ ~33 flowering_azalea
setblock ~12 ~ ~30 allium
setblock ~11 ~ ~26 oxeye_daisy
setblock ~10 ~ ~22 azalea
setblock ~11 ~ ~18 flowering_azalea
setblock ~12 ~ ~14 allium
setblock ~15 ~ ~11 oxeye_daisy
setblock ~18 ~ ~8 azalea
setblock ~22 ~ ~7 flowering_azalea
setblock ~26 ~ ~6 allium
setblock ~30 ~ ~7 oxeye_daisy
setblock ~34 ~ ~8 azalea
setblock ~37 ~ ~11 flowering_azalea
setblock ~40 ~ ~14 allium
setblock ~41 ~ ~18 oxeye_daisy
fill ~39 ~ ~22 ~39 ~1 ~22 dark_oak_fence
setblock ~39 ~2 ~22 lantern
fill ~35 ~ ~31 ~35 ~1 ~31 dark_oak_fence
setblock ~35 ~2 ~31 lantern
fill ~26 ~ ~35 ~26 ~1 ~35 dark_oak_fence
setblock ~26 ~2 ~35 lantern
fill ~17 ~ ~31 ~17 ~1 ~31 dark_oak_fence
setblock ~17 ~2 ~31 lantern
fill ~13 ~ ~22 ~13 ~1 ~22 dark_oak_fence
setblock ~13 ~2 ~22 lantern
fill ~17 ~ ~13 ~17 ~1 ~13 dark_oak_fence
setblock ~17 ~2 ~13 lantern
fill ~26 ~ ~9 ~26 ~1 ~9 dark_oak_fence
setblock ~26 ~2 ~9 lantern
fill ~35 ~ ~13 ~35 ~1 ~13 dark_oak_fence
setblock ~35 ~2 ~13 lantern
fill ~16 ~ ~19 ~35 ~1 ~26 smooth_quartz
fill ~16 ~2 ~19 ~35 ~2 ~26 quartz_bricks
setblock ~16 ~ ~27 quartz_stairs[facing=north]
setblock ~17 ~ ~27 quartz_stairs[facing=north]
setblock ~18 ~ ~27 quartz_stairs[facing=north]
setblock ~19 ~ ~27 quartz_stairs[facing=north]
setblock ~20 ~ ~27 quartz_stairs[facing=north]
setblock ~21 ~ ~27 quartz_stairs[facing=north]
setblock ~22 ~ ~27 quartz_stairs[facing=north]
setblock ~23 ~ ~27 quartz_stairs[facing=north]
setblock ~24 ~ ~27 quartz_stairs[facing=north]
setblock ~25 ~ ~27 quartz_stairs[facing=north]
setblock ~26 ~ ~27 quartz_stairs[facing=north]
setblock ~27 ~ ~27 quartz_stairs[facing=north]
setblock ~28 ~ ~27 quartz_stairs[facing=north]
setblock ~29 ~ ~27 quartz_stairs[facing=north]
setblock ~30 ~ ~27 quartz_stairs[facing=north]
setblock ~31 ~ ~27 quartz_stairs[facing=north]
setblock ~32 ~ ~27 quartz_stairs[facing=north]
setblock ~33 ~ ~27 quartz_stairs[facing=north]
setblock ~34 ~ ~27 quartz_stairs[facing=north]
setblock ~35 ~ ~27 quartz_stairs[facing=north]
fill ~15 ~ ~19 ~15 ~ ~26 quartz_stairs[facing=east]
fill ~36 ~ ~19 ~36 ~ ~26 quartz_stairs[facing=west]
fill ~20 ~3 ~22 ~23 ~8 ~23 blue_concrete
fill ~20 ~3 ~22 ~23 ~3 ~23 gray_concrete
fill ~21 ~4 ~22 ~22 ~7 ~23 blue_concrete
fill ~20 ~9 ~22 ~23 ~14 ~23 cyan_concrete
fill ~18 ~9 ~22 ~19 ~14 ~23 smooth_sandstone
fill ~18 ~12 ~22 ~19 ~14 ~23 cyan_concrete
fill ~24 ~9 ~22 ~25 ~14 ~23 smooth_sandstone
fill ~24 ~12 ~22 ~25 ~14 ~23 cyan_concrete
fill ~20 ~15 ~21 ~23 ~18 ~24 smooth_sandstone
fill ~20 ~18 ~21 ~23 ~18 ~24 brown_concrete
fill ~20 ~15 ~21 ~23 ~18 ~21 brown_concrete
fill ~20 ~16 ~21 ~20 ~18 ~23 brown_concrete
fill ~23 ~16 ~21 ~23 ~18 ~23 brown_concrete
setblock ~20 ~16 ~24 white_concrete
setblock ~21 ~16 ~24 blue_concrete
setblock ~22 ~16 ~24 blue_concrete
setblock ~23 ~16 ~24 white_concrete
fill ~21 ~15 ~24 ~22 ~15 ~24 brown_terracotta
fill ~28 ~3 ~22 ~31 ~8 ~23 white_concrete
fill ~28 ~3 ~22 ~31 ~3 ~23 white_concrete
fill ~29 ~4 ~22 ~30 ~7 ~23 pink_concrete
fill ~28 ~9 ~22 ~31 ~14 ~23 pink_concrete
fill ~26 ~9 ~22 ~27 ~14 ~23 smooth_sandstone
fill ~26 ~12 ~22 ~27 ~14 ~23 pink_concrete
fill ~32 ~9 ~22 ~33 ~14 ~23 smooth_sandstone
fill ~32 ~12 ~22 ~33 ~14 ~23 pink_concrete
fill ~28 ~15 ~21 ~31 ~18 ~24 smooth_sandstone
fill ~28 ~18 ~21 ~31 ~18 ~24 yellow_concrete
fill ~28 ~15 ~21 ~31 ~18 ~21 yellow_concrete
fill ~28 ~16 ~21 ~28 ~18 ~23 yellow_concrete
fill ~31 ~16 ~21 ~31 ~18 ~23 yellow_concrete
fill ~28 ~12 ~21 ~31 ~15 ~21 yellow_concrete
setblock ~28 ~16 ~24 white_concrete
setblock ~29 ~16 ~24 green_concrete
setblock ~30 ~16 ~24 green_concrete
setblock ~31 ~16 ~24 white_concrete
fill ~29 ~15 ~24 ~30 ~15 ~24 red_terracotta
summon minecraft:text_display ~26 ~2 ~28 {billboard:"center",text:{text:"LOS FUNDADORES",color:"gold",bold:1b},background:1073741824}
fill ~2 ~-1 ~-6 ~4 ~-1 ~5 stone_bricks
fill ~41 ~-1 ~20 ~48 ~-1 ~21 stone_bricks
fill ~31 ~-1 ~37 ~33 ~-1 ~65 stone_bricks
fill ~31 ~-1 ~63 ~39 ~-1 ~65 stone_bricks
fill ~3 ~-1 ~21 ~11 ~-1 ~23 stone_bricks
fill ~3 ~-1 ~5 ~3 ~-1 ~22 stone_bricks
