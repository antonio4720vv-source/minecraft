tellraw @a {"text":"[Fase 2] 10 granjas de sandia y calabaza...","color":"yellow"}
execute positioned ~72 ~ ~24 run function granjas:_sandia
execute positioned ~89 ~ ~24 run function granjas:_sandia
execute positioned ~106 ~ ~24 run function granjas:_sandia
execute positioned ~123 ~ ~24 run function granjas:_sandia
execute positioned ~140 ~ ~24 run function granjas:_sandia
execute positioned ~72 ~ ~33 run function granjas:_calabaza
execute positioned ~89 ~ ~33 run function granjas:_calabaza
execute positioned ~106 ~ ~33 run function granjas:_calabaza
execute positioned ~123 ~ ~33 run function granjas:_calabaza
execute positioned ~140 ~ ~33 run function granjas:_calabaza
setblock ~70 ~ ~2 light[level=15] keep
setblock ~70 ~ ~6 light[level=15] keep
setblock ~70 ~ ~10 light[level=15] keep
setblock ~70 ~ ~14 light[level=15] keep
setblock ~70 ~ ~18 light[level=15] keep
setblock ~70 ~ ~22 light[level=15] keep
setblock ~70 ~ ~26 light[level=15] keep
setblock ~70 ~ ~30 light[level=15] keep
setblock ~70 ~ ~34 light[level=15] keep
setblock ~70 ~ ~38 light[level=15] keep
setblock ~87 ~ ~2 light[level=15] keep
setblock ~87 ~ ~6 light[level=15] keep
setblock ~87 ~ ~10 light[level=15] keep
setblock ~87 ~ ~14 light[level=15] keep
setblock ~87 ~ ~18 light[level=15] keep
setblock ~87 ~ ~22 light[level=15] keep
setblock ~87 ~ ~26 light[level=15] keep
setblock ~87 ~ ~30 light[level=15] keep
setblock ~87 ~ ~34 light[level=15] keep
setblock ~87 ~ ~38 light[level=15] keep
setblock ~104 ~ ~2 light[level=15] keep
setblock ~104 ~ ~6 light[level=15] keep
setblock ~104 ~ ~10 light[level=15] keep
setblock ~104 ~ ~14 light[level=15] keep
setblock ~104 ~ ~18 light[level=15] keep
setblock ~104 ~ ~22 light[level=15] keep
setblock ~104 ~ ~26 light[level=15] keep
setblock ~104 ~ ~30 light[level=15] keep
setblock ~104 ~ ~34 light[level=15] keep
setblock ~104 ~ ~38 light[level=15] keep
setblock ~121 ~ ~2 light[level=15] keep
setblock ~121 ~ ~6 light[level=15] keep
setblock ~121 ~ ~10 light[level=15] keep
setblock ~121 ~ ~14 light[level=15] keep
setblock ~121 ~ ~18 light[level=15] keep
setblock ~121 ~ ~22 light[level=15] keep
setblock ~121 ~ ~26 light[level=15] keep
setblock ~121 ~ ~30 light[level=15] keep
setblock ~121 ~ ~34 light[level=15] keep
setblock ~121 ~ ~38 light[level=15] keep
setblock ~138 ~ ~2 light[level=15] keep
setblock ~138 ~ ~6 light[level=15] keep
setblock ~138 ~ ~10 light[level=15] keep
setblock ~138 ~ ~14 light[level=15] keep
setblock ~138 ~ ~18 light[level=15] keep
setblock ~138 ~ ~22 light[level=15] keep
setblock ~138 ~ ~26 light[level=15] keep
setblock ~138 ~ ~30 light[level=15] keep
setblock ~138 ~ ~34 light[level=15] keep
setblock ~138 ~ ~38 light[level=15] keep
setblock ~155 ~ ~2 light[level=15] keep
setblock ~155 ~ ~6 light[level=15] keep
setblock ~155 ~ ~10 light[level=15] keep
setblock ~155 ~ ~14 light[level=15] keep
setblock ~155 ~ ~18 light[level=15] keep
setblock ~155 ~ ~22 light[level=15] keep
setblock ~155 ~ ~26 light[level=15] keep
setblock ~155 ~ ~30 light[level=15] keep
setblock ~155 ~ ~34 light[level=15] keep
setblock ~155 ~ ~38 light[level=15] keep
kill @e[type=minecraft:item,distance=..200]
function granjas:respaldo_on
tellraw @a {"text":"[Fase 2] LISTA! Establo (10 animales, 2 pisos), invernadero (10 cultivos) y pabellon (10 bambu + 5 sandia + 5 calabaza, barriles al oeste de cada granja).","color":"green"}
