kill @e[type=minecraft:marker,tag=granjas_f2]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_f2"]}
function granjas:_f2_0
