tellraw @a {"text":"Borrando todo lo construido en la plaza y reconstruyendo en 5 segundos...","color":"yellow"}
forceload add ~-58 ~-40 ~64 ~22
execute positioned ~-58 ~-7 ~-40 run kill @e[type=!minecraft:player,tag=!granjas_hub,dx=122,dy=60,dz=62]
schedule function granjas:_reconstruir2 5s replace
