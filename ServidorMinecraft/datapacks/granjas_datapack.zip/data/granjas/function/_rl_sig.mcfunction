execute if score #linea rieles matches 1 run function granjas:_rl_l1
execute if score #linea rieles matches 2 run function granjas:_rl_l2
execute if score #linea rieles matches 3 run function granjas:_rl_l3
execute if score #linea rieles matches 4 run function granjas:_rl_l4
execute if score #linea rieles matches 5.. run function granjas:_rl_fin
