kill @e[type=minecraft:hopper_minecart,distance=..90]
data remove storage granjas:tmp items
data modify storage granjas:tmp items set from block ~-11 ~ ~13 Items
setblock ~-11 ~ ~13 barrel[facing=west]
data modify block ~-11 ~ ~13 Items set from storage granjas:tmp items
setblock ~-11 ~1 ~13 stone_bricks
summon minecraft:hopper_minecart ~-10 ~1 ~13
summon minecraft:hopper_minecart ~-9 ~1 ~13
summon minecraft:hopper_minecart ~-8 ~1 ~13
summon minecraft:hopper_minecart ~-7 ~1 ~13
summon minecraft:hopper_minecart ~-6 ~1 ~13
summon minecraft:hopper_minecart ~-5 ~1 ~13
summon minecraft:hopper_minecart ~-4 ~1 ~13
summon minecraft:hopper_minecart ~-3 ~1 ~13
summon minecraft:hopper_minecart ~-2 ~1 ~13
summon minecraft:hopper_minecart ~-1 ~1 ~13
summon minecraft:hopper_minecart ~ ~1 ~13
summon minecraft:hopper_minecart ~1 ~1 ~13
data remove storage granjas:tmp items
data modify storage granjas:tmp items set from block ~9 ~ ~13 Items
setblock ~9 ~ ~13 barrel[facing=west]
data modify block ~9 ~ ~13 Items set from storage granjas:tmp items
setblock ~9 ~1 ~13 stone_bricks
setblock ~9 ~1 ~12 stone_bricks
summon minecraft:hopper_minecart ~10 ~1 ~12
summon minecraft:hopper_minecart ~10 ~1 ~13
summon minecraft:hopper_minecart ~11 ~1 ~12
summon minecraft:hopper_minecart ~11 ~1 ~13
summon minecraft:hopper_minecart ~12 ~1 ~12
summon minecraft:hopper_minecart ~12 ~1 ~13
summon minecraft:hopper_minecart ~13 ~1 ~12
summon minecraft:hopper_minecart ~13 ~1 ~13
summon minecraft:hopper_minecart ~14 ~1 ~12
summon minecraft:hopper_minecart ~14 ~1 ~13
summon minecraft:hopper_minecart ~15 ~1 ~12
summon minecraft:hopper_minecart ~15 ~1 ~13
summon minecraft:hopper_minecart ~16 ~1 ~12
summon minecraft:hopper_minecart ~16 ~1 ~13
summon minecraft:hopper_minecart ~17 ~1 ~12
summon minecraft:hopper_minecart ~17 ~1 ~13
summon minecraft:hopper_minecart ~18 ~1 ~12
summon minecraft:hopper_minecart ~18 ~1 ~13
summon minecraft:hopper_minecart ~19 ~1 ~12
summon minecraft:hopper_minecart ~19 ~1 ~13
summon minecraft:hopper_minecart ~20 ~1 ~12
summon minecraft:hopper_minecart ~20 ~1 ~13
summon minecraft:hopper_minecart ~21 ~1 ~12
summon minecraft:hopper_minecart ~21 ~1 ~13
data remove storage granjas:tmp items
data modify storage granjas:tmp items set from block ~29 ~ ~12 Items
setblock ~29 ~ ~12 barrel[facing=west]
data modify block ~29 ~ ~12 Items set from storage granjas:tmp items
setblock ~29 ~1 ~12 stone_bricks
data remove storage granjas:tmp items
data modify storage granjas:tmp items set from block ~32 ~ ~-24 Items
setblock ~32 ~ ~-24 barrel[facing=south]
data modify block ~32 ~ ~-24 Items set from storage granjas:tmp items
data remove storage granjas:tmp items
data modify storage granjas:tmp items set from block ~33 ~ ~-24 Items
setblock ~33 ~ ~-24 barrel[facing=south]
data modify block ~33 ~ ~-24 Items set from storage granjas:tmp items
tellraw @a {"text":"Arreglado: vagones de vuelta en su lugar y los cofres cambiados por barriles (se abren aunque tengan un bloque encima). Las cosas que tenian se conservaron.","color":"green"}
