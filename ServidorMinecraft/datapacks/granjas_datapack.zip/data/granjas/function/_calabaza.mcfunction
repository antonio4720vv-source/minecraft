tellraw @s {"text":"Construyendo granja de CALABAZAS...","color":"yellow"}
fill ~-3 ~-1 ~-3 ~13 ~7 ~4 air
fill ~-3 ~-1 ~-3 ~13 ~-1 ~4 stone_bricks
fill ~-1 ~ ~-2 ~12 ~2 ~3 stone_bricks
fill ~ ~ ~ ~11 ~ ~ hopper[facing=south]
fill ~ ~ ~1 ~11 ~ ~1 hopper[facing=west]
setblock ~-1 ~ ~1 barrel[facing=west]
fill ~ ~1 ~ ~11 ~1 ~1 rail[shape=east_west]
fill ~ ~2 ~ ~11 ~2 ~ farmland[moisture=7]
fill ~ ~2 ~1 ~11 ~2 ~1 dirt
fill ~ ~2 ~-1 ~11 ~2 ~-1 water
fill ~-1 ~3 ~-1 ~12 ~5 ~-1 glass
fill ~-1 ~3 ~ ~-1 ~5 ~3 glass
fill ~12 ~3 ~ ~12 ~5 ~3 glass
setblock ~ ~3 ~ pumpkin_stem[age=7]
setblock ~1 ~3 ~ pumpkin_stem[age=7]
setblock ~2 ~3 ~ pumpkin_stem[age=7]
setblock ~3 ~3 ~ pumpkin_stem[age=7]
setblock ~4 ~3 ~ pumpkin_stem[age=7]
setblock ~5 ~3 ~ pumpkin_stem[age=7]
setblock ~6 ~3 ~ pumpkin_stem[age=7]
setblock ~7 ~3 ~ pumpkin_stem[age=7]
setblock ~8 ~3 ~ pumpkin_stem[age=7]
setblock ~9 ~3 ~ pumpkin_stem[age=7]
setblock ~10 ~3 ~ pumpkin_stem[age=7]
setblock ~11 ~3 ~ pumpkin_stem[age=7]
fill ~ ~3 ~1 ~11 ~3 ~1 air
fill ~ ~4 ~ ~11 ~5 ~ air
fill ~ ~3 ~2 ~11 ~3 ~2 piston[facing=north]
fill ~ ~3 ~3 ~11 ~3 ~3 stone_bricks
fill ~ ~4 ~1 ~11 ~4 ~1 observer[facing=down]
fill ~ ~5 ~1 ~11 ~5 ~1 stone_bricks
fill ~ ~4 ~2 ~11 ~4 ~3 stone_bricks
fill ~ ~5 ~2 ~11 ~5 ~2 redstone_wire
fill ~-1 ~6 ~-1 ~12 ~6 ~3 glass
setblock ~ ~6 ~ glowstone
setblock ~3 ~6 ~ glowstone
setblock ~6 ~6 ~ glowstone
setblock ~9 ~6 ~ glowstone
summon minecraft:hopper_minecart ~ ~1 ~
summon minecraft:hopper_minecart ~ ~1 ~1
summon minecraft:hopper_minecart ~1 ~1 ~
summon minecraft:hopper_minecart ~1 ~1 ~1
summon minecraft:hopper_minecart ~2 ~1 ~
summon minecraft:hopper_minecart ~2 ~1 ~1
summon minecraft:hopper_minecart ~3 ~1 ~
summon minecraft:hopper_minecart ~3 ~1 ~1
summon minecraft:hopper_minecart ~4 ~1 ~
summon minecraft:hopper_minecart ~4 ~1 ~1
summon minecraft:hopper_minecart ~5 ~1 ~
summon minecraft:hopper_minecart ~5 ~1 ~1
summon minecraft:hopper_minecart ~6 ~1 ~
summon minecraft:hopper_minecart ~6 ~1 ~1
summon minecraft:hopper_minecart ~7 ~1 ~
summon minecraft:hopper_minecart ~7 ~1 ~1
summon minecraft:hopper_minecart ~8 ~1 ~
summon minecraft:hopper_minecart ~8 ~1 ~1
summon minecraft:hopper_minecart ~9 ~1 ~
summon minecraft:hopper_minecart ~9 ~1 ~1
summon minecraft:hopper_minecart ~10 ~1 ~
summon minecraft:hopper_minecart ~10 ~1 ~1
summon minecraft:hopper_minecart ~11 ~1 ~
summon minecraft:hopper_minecart ~11 ~1 ~1
summon minecraft:text_display ~-2 ~2 ~1 {billboard:"center",text:{text:"CALABAZAS\ncofre aqui abajo",color:"gold",bold:1b},background:1073741824}
summon minecraft:marker ~-1 ~ ~1 {Tags:["go_calabaza"]}
tellraw @s {"text":"Granja de melones y calabazas lista. Cada vez que crece una, el piston la rompe y cae al cofre del lado oeste. Los melones se comen y al granjero le puedes vender ambos por esmeraldas.","color":"green"}
