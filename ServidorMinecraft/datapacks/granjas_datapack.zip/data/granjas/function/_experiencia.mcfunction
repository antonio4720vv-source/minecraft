tellraw @s {"text":"Construyendo granja de EXPERIENCIA v2...","color":"yellow"}
fill ~-3 ~-1 ~-2 ~11 ~19 ~12 air
fill ~-3 ~-1 ~-2 ~11 ~-1 ~12 cobblestone
fill ~-1 ~12 ~-1 ~9 ~17 ~9 cobblestone hollow
fill ~ ~13 ~ ~8 ~13 ~ water
setblock ~4 ~14 ~4 spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
fill ~-2 ~ ~9 ~10 ~2 ~12 cobblestone
fill ~-1 ~ ~7 ~9 ~11 ~9 cobblestone
fill ~ ~1 ~8 ~8 ~12 ~8 air
setblock ~ ~13 ~8 oak_wall_sign[facing=north]
setblock ~1 ~13 ~8 oak_wall_sign[facing=north]
setblock ~2 ~13 ~8 oak_wall_sign[facing=north]
setblock ~3 ~13 ~8 oak_wall_sign[facing=north]
setblock ~4 ~13 ~8 oak_wall_sign[facing=north]
setblock ~5 ~13 ~8 oak_wall_sign[facing=north]
setblock ~6 ~13 ~8 oak_wall_sign[facing=north]
setblock ~7 ~13 ~8 oak_wall_sign[facing=north]
setblock ~8 ~13 ~8 oak_wall_sign[facing=north]
fill ~ ~ ~8 ~8 ~ ~8 hopper[facing=south]
fill ~ ~ ~9 ~8 ~ ~9 barrel[facing=up]
fill ~ ~1 ~9 ~8 ~1 ~9 cobblestone_slab[type=bottom]
fill ~-1 ~ ~10 ~9 ~1 ~11 air
setblock ~ ~2 ~11 glowstone
setblock ~4 ~2 ~11 glowstone
setblock ~8 ~2 ~11 glowstone
setblock ~1 ~18 ~1 torch
setblock ~4 ~18 ~4 torch
setblock ~7 ~18 ~7 torch
setblock ~1 ~18 ~7 torch
setblock ~7 ~18 ~1 torch
setblock ~-2 ~ ~ torch
setblock ~10 ~ ~ torch
setblock ~4 ~ ~-2 torch
setblock ~-2 ~ ~5 torch
setblock ~10 ~ ~5 torch
setblock ~-2 ~ ~10 iron_door[half=lower,facing=east,hinge=left]
setblock ~-2 ~1 ~10 iron_door[half=upper,facing=east,hinge=left]
setblock ~-3 ~1 ~11 stone_button[face=wall,facing=west]
setblock ~-1 ~1 ~11 stone_button[face=wall,facing=east]
summon minecraft:text_display ~-3 ~3 ~10 {billboard:"center",text:{text:"GRANJA DE EXPERIENCIA\nparate en la mitad del pasillo",color:"gold",bold:1b},background:1073741824}
summon minecraft:marker ~4 ~ ~9 {Tags:["go_xpbarril"]}
summon minecraft:marker ~4 ~ ~10 {Tags:["go_xp"]}
tellraw @s {"text":"Granja de experiencia lista. Entra por la puerta, parate en la MITAD del pasillo mirando a la rendija y pegales a los zombis. El botin cae en los barriles del piso.","color":"green"}
