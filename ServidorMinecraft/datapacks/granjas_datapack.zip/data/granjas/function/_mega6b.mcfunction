tellraw @a {"text":"Construyendo el edificio de granjas (pisos)...","color":"yellow"}
execute positioned ~-26 ~ ~-70 run function granjas:_edif_a
