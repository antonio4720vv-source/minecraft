tellraw @s {"text":"Construyendo CRIADERO de aldeanos v2...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~17 ~4 ~11 air
fill ~-1 ~-1 ~-1 ~17 ~-1 ~11 grass_block
fill ~-1 ~ ~-1 ~11 ~2 ~11 glass hollow
fill ~-1 ~3 ~-1 ~11 ~3 ~11 glass
setblock ~2 ~-1 ~4 glowstone
setblock ~8 ~-1 ~4 glowstone
setblock ~2 ~-1 ~6 glowstone
setblock ~8 ~-1 ~6 glowstone
setblock ~5 ~-1 ~5 glowstone
setblock ~ ~ ~ white_bed[facing=south,part=foot]
setblock ~ ~ ~1 white_bed[facing=south,part=head]
setblock ~ ~ ~10 white_bed[facing=north,part=foot]
setblock ~ ~ ~9 white_bed[facing=north,part=head]
setblock ~1 ~ ~ white_bed[facing=south,part=foot]
setblock ~1 ~ ~1 white_bed[facing=south,part=head]
setblock ~1 ~ ~10 white_bed[facing=north,part=foot]
setblock ~1 ~ ~9 white_bed[facing=north,part=head]
setblock ~2 ~ ~ white_bed[facing=south,part=foot]
setblock ~2 ~ ~1 white_bed[facing=south,part=head]
setblock ~2 ~ ~10 white_bed[facing=north,part=foot]
setblock ~2 ~ ~9 white_bed[facing=north,part=head]
setblock ~3 ~ ~ white_bed[facing=south,part=foot]
setblock ~3 ~ ~1 white_bed[facing=south,part=head]
setblock ~3 ~ ~10 white_bed[facing=north,part=foot]
setblock ~3 ~ ~9 white_bed[facing=north,part=head]
setblock ~4 ~ ~ white_bed[facing=south,part=foot]
setblock ~4 ~ ~1 white_bed[facing=south,part=head]
setblock ~4 ~ ~10 white_bed[facing=north,part=foot]
setblock ~4 ~ ~9 white_bed[facing=north,part=head]
setblock ~5 ~ ~ white_bed[facing=south,part=foot]
setblock ~5 ~ ~1 white_bed[facing=south,part=head]
setblock ~5 ~ ~10 white_bed[facing=north,part=foot]
setblock ~5 ~ ~9 white_bed[facing=north,part=head]
setblock ~6 ~ ~ white_bed[facing=south,part=foot]
setblock ~6 ~ ~1 white_bed[facing=south,part=head]
setblock ~6 ~ ~10 white_bed[facing=north,part=foot]
setblock ~6 ~ ~9 white_bed[facing=north,part=head]
setblock ~7 ~ ~ white_bed[facing=south,part=foot]
setblock ~7 ~ ~1 white_bed[facing=south,part=head]
setblock ~7 ~ ~10 white_bed[facing=north,part=foot]
setblock ~7 ~ ~9 white_bed[facing=north,part=head]
setblock ~8 ~ ~ white_bed[facing=south,part=foot]
setblock ~8 ~ ~1 white_bed[facing=south,part=head]
setblock ~8 ~ ~10 white_bed[facing=north,part=foot]
setblock ~8 ~ ~9 white_bed[facing=north,part=head]
setblock ~9 ~ ~ white_bed[facing=south,part=foot]
setblock ~9 ~ ~1 white_bed[facing=south,part=head]
setblock ~9 ~ ~10 white_bed[facing=north,part=foot]
setblock ~9 ~ ~9 white_bed[facing=north,part=head]
setblock ~10 ~ ~ white_bed[facing=south,part=foot]
setblock ~10 ~ ~1 white_bed[facing=south,part=head]
setblock ~10 ~ ~10 white_bed[facing=north,part=foot]
setblock ~10 ~ ~9 white_bed[facing=north,part=head]
setblock ~11 ~ ~5 air
fill ~11 ~-1 ~2 ~17 ~3 ~8 glass hollow
fill ~12 ~-1 ~3 ~16 ~-1 ~7 grass_block
fill ~12 ~ ~3 ~16 ~2 ~7 air
setblock ~11 ~ ~5 air
setblock ~11 ~1 ~5 glass
setblock ~14 ~-1 ~5 glowstone
fill ~17 ~ ~4 ~17 ~2 ~6 stone_bricks
setblock ~17 ~ ~5 iron_door[half=lower,facing=west,hinge=left]
setblock ~17 ~1 ~5 iron_door[half=upper,facing=west,hinge=left]
setblock ~18 ~1 ~6 stone_button[face=wall,facing=east]
setblock ~16 ~1 ~6 stone_button[face=wall,facing=west]
summon minecraft:villager ~3 ~ ~4 {PersistenceRequired:1b,CustomName:"Padre 1",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~5 ~ ~4 {PersistenceRequired:1b,CustomName:"Padre 2",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~3 ~ ~6 {PersistenceRequired:1b,CustomName:"Padre 3",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~5 ~ ~6 {PersistenceRequired:1b,CustomName:"Padre 4",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:text_display ~18 ~3 ~5 {billboard:"center",text:{text:"CRIADERO\nlos bebes salen a este corral",color:"gold",bold:1b},background:1073741824}
summon minecraft:text_display ~5 ~5 ~5 {billboard:"center",text:{text:"CRIADERO DE ALDEANOS",color:"gold",bold:1b},background:1073741824}
summon minecraft:marker ~14 ~ ~5 {Tags:["go_bebes"]}
tellraw @s {"text":"Criadero listo: 4 adultos con pan y 22 camas. Los bebes pasan solos por el hueco al corral de la derecha; sacalos por la puerta de hierro y llevalos a la sala de comercio.","color":"green"}
