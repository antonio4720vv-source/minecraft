execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run forceload add ~-4 ~-16 ~94 ~66
tellraw @a {"text":"[Fase 4] Preparando terreno de 98 x 82 bloques al ESTE y SUR (y el bunker abajo). Tarda como 1 minuto y despues se tienden las vias.","color":"gold"}
schedule function granjas:_f4_1 5s replace
