execute if score #seg rieles matches 1 at @s run function granjas:_rl_llegada
execute if score #seg rieles matches 0 if score #remz rieles matches 0 at @s run function granjas:_rl_llegada
execute if score #seg rieles matches 0 if score #remz rieles matches 1.. run function granjas:_rl_esquina
