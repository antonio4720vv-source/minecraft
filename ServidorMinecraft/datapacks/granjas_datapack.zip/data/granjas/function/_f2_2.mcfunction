execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run function granjas:_f2_2b
schedule function granjas:_f2_3 3s replace
