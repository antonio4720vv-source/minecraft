tellraw @a {"text":"[Fase 1] Torre de hierro: pisos 3-5 y azotea...","color":"yellow"}
fill ~7 ~23 ~3 ~26 ~23 ~22 stone_bricks
fill ~16 ~23 ~12 ~17 ~23 ~13 air
fill ~8 ~24 ~4 ~25 ~32 ~21 air
fill ~7 ~24 ~3 ~26 ~24 ~3 stone_bricks
fill ~7 ~24 ~22 ~26 ~24 ~22 stone_bricks
fill ~7 ~24 ~3 ~7 ~24 ~22 stone_bricks
fill ~26 ~24 ~3 ~26 ~24 ~22 stone_bricks
fill ~7 ~25 ~3 ~26 ~32 ~3 glass
fill ~7 ~25 ~22 ~26 ~32 ~22 glass
fill ~7 ~25 ~3 ~7 ~32 ~22 glass
fill ~26 ~25 ~3 ~26 ~32 ~22 glass
fill ~7 ~24 ~3 ~7 ~32 ~3 chiseled_stone_bricks
fill ~7 ~24 ~22 ~7 ~32 ~22 chiseled_stone_bricks
fill ~13 ~24 ~3 ~13 ~32 ~3 chiseled_stone_bricks
fill ~13 ~24 ~22 ~13 ~32 ~22 chiseled_stone_bricks
fill ~19 ~24 ~3 ~19 ~32 ~3 chiseled_stone_bricks
fill ~19 ~24 ~22 ~19 ~32 ~22 chiseled_stone_bricks
fill ~25 ~24 ~3 ~25 ~32 ~3 chiseled_stone_bricks
fill ~25 ~24 ~22 ~25 ~32 ~22 chiseled_stone_bricks
fill ~8 ~24 ~4 ~25 ~24 ~21 smooth_stone
fill ~16 ~24 ~4 ~17 ~24 ~21 air
fill ~8 ~25 ~4 ~8 ~25 ~21 water
fill ~25 ~25 ~4 ~25 ~25 ~21 water
fill ~16 ~24 ~4 ~17 ~24 ~4 water
fill ~16 ~24 ~21 ~17 ~24 ~21 water
setblock ~10 ~27 ~6 light[level=15]
setblock ~10 ~27 ~10 light[level=15]
setblock ~10 ~27 ~15 light[level=15]
setblock ~10 ~27 ~19 light[level=15]
setblock ~13 ~27 ~6 light[level=15]
setblock ~13 ~27 ~10 light[level=15]
setblock ~13 ~27 ~15 light[level=15]
setblock ~13 ~27 ~19 light[level=15]
setblock ~21 ~27 ~6 light[level=15]
setblock ~21 ~27 ~10 light[level=15]
setblock ~21 ~27 ~15 light[level=15]
setblock ~21 ~27 ~19 light[level=15]
setblock ~24 ~27 ~6 light[level=15]
setblock ~24 ~27 ~10 light[level=15]
setblock ~24 ~27 ~15 light[level=15]
setblock ~24 ~27 ~19 light[level=15]
fill ~19 ~29 ~9 ~24 ~29 ~18 smooth_stone
fill ~19 ~30 ~9 ~24 ~31 ~18 glass
fill ~20 ~30 ~10 ~23 ~31 ~15 air
fill ~20 ~30 ~17 ~23 ~31 ~17 air
fill ~19 ~32 ~9 ~24 ~32 ~18 glass
fill ~20 ~31 ~16 ~23 ~31 ~16 air
setblock ~20 ~30 ~14 red_bed[facing=south,part=foot]
setblock ~20 ~30 ~15 red_bed[facing=south,part=head]
setblock ~21 ~30 ~14 red_bed[facing=south,part=foot]
setblock ~21 ~30 ~15 red_bed[facing=south,part=head]
setblock ~22 ~30 ~14 red_bed[facing=south,part=foot]
setblock ~22 ~30 ~15 red_bed[facing=south,part=head]
summon minecraft:villager ~20 ~30 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~22 ~30 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~23 ~30 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:zombie ~21 ~30 ~17 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
fill ~7 ~33 ~3 ~26 ~33 ~22 stone_bricks
fill ~16 ~33 ~12 ~17 ~33 ~13 air
fill ~8 ~34 ~4 ~25 ~42 ~21 air
fill ~7 ~34 ~3 ~26 ~34 ~3 stone_bricks
fill ~7 ~34 ~22 ~26 ~34 ~22 stone_bricks
fill ~7 ~34 ~3 ~7 ~34 ~22 stone_bricks
fill ~26 ~34 ~3 ~26 ~34 ~22 stone_bricks
fill ~7 ~35 ~3 ~26 ~42 ~3 glass
fill ~7 ~35 ~22 ~26 ~42 ~22 glass
fill ~7 ~35 ~3 ~7 ~42 ~22 glass
fill ~26 ~35 ~3 ~26 ~42 ~22 glass
fill ~7 ~34 ~3 ~7 ~42 ~3 chiseled_stone_bricks
fill ~7 ~34 ~22 ~7 ~42 ~22 chiseled_stone_bricks
fill ~13 ~34 ~3 ~13 ~42 ~3 chiseled_stone_bricks
fill ~13 ~34 ~22 ~13 ~42 ~22 chiseled_stone_bricks
fill ~19 ~34 ~3 ~19 ~42 ~3 chiseled_stone_bricks
fill ~19 ~34 ~22 ~19 ~42 ~22 chiseled_stone_bricks
fill ~25 ~34 ~3 ~25 ~42 ~3 chiseled_stone_bricks
fill ~25 ~34 ~22 ~25 ~42 ~22 chiseled_stone_bricks
fill ~8 ~34 ~4 ~25 ~34 ~21 smooth_stone
fill ~16 ~34 ~4 ~17 ~34 ~21 air
fill ~8 ~35 ~4 ~8 ~35 ~21 water
fill ~25 ~35 ~4 ~25 ~35 ~21 water
fill ~16 ~34 ~4 ~17 ~34 ~4 water
fill ~16 ~34 ~21 ~17 ~34 ~21 water
setblock ~10 ~37 ~6 light[level=15]
setblock ~10 ~37 ~10 light[level=15]
setblock ~10 ~37 ~15 light[level=15]
setblock ~10 ~37 ~19 light[level=15]
setblock ~13 ~37 ~6 light[level=15]
setblock ~13 ~37 ~10 light[level=15]
setblock ~13 ~37 ~15 light[level=15]
setblock ~13 ~37 ~19 light[level=15]
setblock ~21 ~37 ~6 light[level=15]
setblock ~21 ~37 ~10 light[level=15]
setblock ~21 ~37 ~15 light[level=15]
setblock ~21 ~37 ~19 light[level=15]
setblock ~24 ~37 ~6 light[level=15]
setblock ~24 ~37 ~10 light[level=15]
setblock ~24 ~37 ~15 light[level=15]
setblock ~24 ~37 ~19 light[level=15]
fill ~19 ~39 ~9 ~24 ~39 ~18 smooth_stone
fill ~19 ~40 ~9 ~24 ~41 ~18 glass
fill ~20 ~40 ~10 ~23 ~41 ~15 air
fill ~20 ~40 ~17 ~23 ~41 ~17 air
fill ~19 ~42 ~9 ~24 ~42 ~18 glass
fill ~20 ~41 ~16 ~23 ~41 ~16 air
setblock ~20 ~40 ~14 red_bed[facing=south,part=foot]
setblock ~20 ~40 ~15 red_bed[facing=south,part=head]
setblock ~21 ~40 ~14 red_bed[facing=south,part=foot]
setblock ~21 ~40 ~15 red_bed[facing=south,part=head]
setblock ~22 ~40 ~14 red_bed[facing=south,part=foot]
setblock ~22 ~40 ~15 red_bed[facing=south,part=head]
summon minecraft:villager ~20 ~40 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~22 ~40 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~23 ~40 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:zombie ~21 ~40 ~17 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
fill ~7 ~43 ~3 ~26 ~43 ~22 stone_bricks
fill ~16 ~43 ~12 ~17 ~43 ~13 air
fill ~8 ~44 ~4 ~25 ~52 ~21 air
fill ~7 ~44 ~3 ~26 ~44 ~3 stone_bricks
fill ~7 ~44 ~22 ~26 ~44 ~22 stone_bricks
fill ~7 ~44 ~3 ~7 ~44 ~22 stone_bricks
fill ~26 ~44 ~3 ~26 ~44 ~22 stone_bricks
fill ~7 ~45 ~3 ~26 ~52 ~3 glass
fill ~7 ~45 ~22 ~26 ~52 ~22 glass
fill ~7 ~45 ~3 ~7 ~52 ~22 glass
fill ~26 ~45 ~3 ~26 ~52 ~22 glass
fill ~7 ~44 ~3 ~7 ~52 ~3 chiseled_stone_bricks
fill ~7 ~44 ~22 ~7 ~52 ~22 chiseled_stone_bricks
fill ~13 ~44 ~3 ~13 ~52 ~3 chiseled_stone_bricks
fill ~13 ~44 ~22 ~13 ~52 ~22 chiseled_stone_bricks
fill ~19 ~44 ~3 ~19 ~52 ~3 chiseled_stone_bricks
fill ~19 ~44 ~22 ~19 ~52 ~22 chiseled_stone_bricks
fill ~25 ~44 ~3 ~25 ~52 ~3 chiseled_stone_bricks
fill ~25 ~44 ~22 ~25 ~52 ~22 chiseled_stone_bricks
fill ~8 ~44 ~4 ~25 ~44 ~21 smooth_stone
fill ~16 ~44 ~4 ~17 ~44 ~21 air
fill ~8 ~45 ~4 ~8 ~45 ~21 water
fill ~25 ~45 ~4 ~25 ~45 ~21 water
fill ~16 ~44 ~4 ~17 ~44 ~4 water
fill ~16 ~44 ~21 ~17 ~44 ~21 water
setblock ~10 ~47 ~6 light[level=15]
setblock ~10 ~47 ~10 light[level=15]
setblock ~10 ~47 ~15 light[level=15]
setblock ~10 ~47 ~19 light[level=15]
setblock ~13 ~47 ~6 light[level=15]
setblock ~13 ~47 ~10 light[level=15]
setblock ~13 ~47 ~15 light[level=15]
setblock ~13 ~47 ~19 light[level=15]
setblock ~21 ~47 ~6 light[level=15]
setblock ~21 ~47 ~10 light[level=15]
setblock ~21 ~47 ~15 light[level=15]
setblock ~21 ~47 ~19 light[level=15]
setblock ~24 ~47 ~6 light[level=15]
setblock ~24 ~47 ~10 light[level=15]
setblock ~24 ~47 ~15 light[level=15]
setblock ~24 ~47 ~19 light[level=15]
fill ~19 ~49 ~9 ~24 ~49 ~18 smooth_stone
fill ~19 ~50 ~9 ~24 ~51 ~18 glass
fill ~20 ~50 ~10 ~23 ~51 ~15 air
fill ~20 ~50 ~17 ~23 ~51 ~17 air
fill ~19 ~52 ~9 ~24 ~52 ~18 glass
fill ~20 ~51 ~16 ~23 ~51 ~16 air
setblock ~20 ~50 ~14 red_bed[facing=south,part=foot]
setblock ~20 ~50 ~15 red_bed[facing=south,part=head]
setblock ~21 ~50 ~14 red_bed[facing=south,part=foot]
setblock ~21 ~50 ~15 red_bed[facing=south,part=head]
setblock ~22 ~50 ~14 red_bed[facing=south,part=foot]
setblock ~22 ~50 ~15 red_bed[facing=south,part=head]
summon minecraft:villager ~20 ~50 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~22 ~50 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~23 ~50 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:zombie ~21 ~50 ~17 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
fill ~7 ~53 ~3 ~26 ~53 ~22 glass
setblock ~7 ~54 ~3 lantern
setblock ~26 ~54 ~3 lantern
setblock ~7 ~54 ~22 lantern
setblock ~26 ~54 ~22 lantern
fill ~3 ~-1 ~14 ~6 ~56 ~18 stone_bricks
fill ~4 ~ ~16 ~5 ~55 ~16 air
fill ~5 ~ ~16 ~5 ~53 ~16 ladder[facing=west]
fill ~3 ~ ~16 ~3 ~1 ~16 air
fill ~6 ~54 ~16 ~6 ~55 ~16 air
fill ~6 ~6 ~16 ~6 ~7 ~16 glass
fill ~6 ~16 ~16 ~6 ~17 ~16 glass
fill ~6 ~26 ~16 ~6 ~27 ~16 glass
fill ~6 ~36 ~16 ~6 ~37 ~16 glass
fill ~6 ~46 ~16 ~6 ~47 ~16 glass
setblock ~4 ~3 ~16 light[level=15]
setblock ~4 ~9 ~16 light[level=15]
setblock ~4 ~15 ~16 light[level=15]
setblock ~4 ~21 ~16 light[level=15]
setblock ~4 ~27 ~16 light[level=15]
setblock ~4 ~33 ~16 light[level=15]
setblock ~4 ~39 ~16 light[level=15]
setblock ~4 ~45 ~16 light[level=15]
setblock ~4 ~51 ~16 light[level=15]
summon minecraft:text_display ~2 ~3 ~16 {billboard:"center",text:{text:"ESCALERA\na la azotea",color:"aqua",bold:1b},background:1073741824}
