execute unless entity @e[type=minecraft:marker,tag=granjas_hub,limit=1] run tellraw @s {"text":"No encuentro la plaza de granjas (usaste granjas:construir?)","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] run function granjas:_arreglar
