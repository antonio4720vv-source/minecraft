execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run function granjas:_f4_4b
schedule function granjas:_f4_5 3s replace
