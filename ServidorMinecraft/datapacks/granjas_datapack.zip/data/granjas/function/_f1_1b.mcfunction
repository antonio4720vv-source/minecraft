tellraw @a {"text":"[Fase 1] Limpiando (1/2)...","color":"yellow"}
execute positioned ~-2 ~-7 ~-4 run kill @e[type=!minecraft:player,tag=!granjas_f1,tag=!granjas_mega,tag=!granjas_hub,dx=72,dy=80,dz=30]
fill ~-2 ~ ~-4 ~33 ~14 ~26 air
fill ~34 ~ ~-4 ~69 ~14 ~26 air
fill ~70 ~ ~-4 ~70 ~14 ~26 air
fill ~-2 ~15 ~-4 ~33 ~29 ~26 air
fill ~34 ~15 ~-4 ~69 ~29 ~26 air
fill ~70 ~15 ~-4 ~70 ~29 ~26 air
