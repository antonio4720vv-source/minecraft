scoreboard objectives add rieles dummy
scoreboard players set #8 rieles 8
scoreboard players set #6 rieles 6
scoreboard players set #-1 rieles -1
scoreboard players set #linea rieles 1
tellraw @a {"text":"[Ferrocarriles] Tendiendo las vias hacia cada fase. Puede trabarse un poco el servidor.","color":"gold"}
schedule function granjas:_rl_sig 1t replace
