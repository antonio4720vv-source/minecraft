tellraw @a {"text":"[Fase 3] Portales del End y del Nether y caminos...","color":"yellow"}
execute positioned ~113 ~ ~52 run function granjas:_portal_end
execute positioned ~138 ~ ~52 run function granjas:_portal_nether
fill ~-2 ~-1 ~ ~150 ~-1 ~2 dirt_path
setblock ~ ~ ~-1 lantern
setblock ~10 ~ ~-1 lantern
setblock ~20 ~ ~-1 lantern
setblock ~30 ~ ~-1 lantern
setblock ~40 ~ ~-1 lantern
setblock ~50 ~ ~-1 lantern
setblock ~60 ~ ~-1 lantern
setblock ~70 ~ ~-1 lantern
setblock ~80 ~ ~-1 lantern
setblock ~90 ~ ~-1 lantern
setblock ~100 ~ ~-1 lantern
setblock ~110 ~ ~-1 lantern
setblock ~120 ~ ~-1 lantern
setblock ~130 ~ ~-1 lantern
setblock ~140 ~ ~-1 lantern
fill ~34 ~-1 ~3 ~36 ~-1 ~9 dirt_path
fill ~73 ~-1 ~3 ~74 ~-1 ~24 dirt_path
fill ~73 ~-1 ~24 ~82 ~-1 ~25 dirt_path
fill ~100 ~-1 ~3 ~102 ~-1 ~48 dirt_path
fill ~115 ~-1 ~3 ~117 ~-1 ~9 dirt_path
fill ~112 ~-1 ~3 ~114 ~-1 ~43 dirt_path
fill ~137 ~-1 ~3 ~139 ~-1 ~43 dirt_path
fill ~112 ~ ~44 ~114 ~ ~44 air
fill ~137 ~ ~44 ~139 ~ ~44 air
fill ~101 ~-1 ~3 ~102 ~-1 ~48 dirt_path
setblock ~1 ~ ~-1 light[level=15] keep
setblock ~1 ~ ~7 light[level=15] keep
setblock ~1 ~ ~15 light[level=15] keep
setblock ~1 ~ ~23 light[level=15] keep
setblock ~1 ~ ~31 light[level=15] keep
setblock ~1 ~ ~39 light[level=15] keep
setblock ~1 ~ ~47 light[level=15] keep
setblock ~1 ~ ~55 light[level=15] keep
setblock ~1 ~ ~63 light[level=15] keep
setblock ~1 ~ ~71 light[level=15] keep
setblock ~9 ~ ~-1 light[level=15] keep
setblock ~9 ~ ~7 light[level=15] keep
setblock ~9 ~ ~15 light[level=15] keep
setblock ~9 ~ ~23 light[level=15] keep
setblock ~9 ~ ~31 light[level=15] keep
setblock ~9 ~ ~39 light[level=15] keep
setblock ~9 ~ ~47 light[level=15] keep
setblock ~9 ~ ~55 light[level=15] keep
setblock ~9 ~ ~63 light[level=15] keep
setblock ~9 ~ ~71 light[level=15] keep
setblock ~17 ~ ~-1 light[level=15] keep
setblock ~17 ~ ~7 light[level=15] keep
setblock ~17 ~ ~15 light[level=15] keep
setblock ~17 ~ ~23 light[level=15] keep
setblock ~17 ~ ~31 light[level=15] keep
setblock ~17 ~ ~39 light[level=15] keep
setblock ~17 ~ ~47 light[level=15] keep
setblock ~17 ~ ~55 light[level=15] keep
setblock ~17 ~ ~63 light[level=15] keep
setblock ~17 ~ ~71 light[level=15] keep
setblock ~25 ~ ~-1 light[level=15] keep
setblock ~25 ~ ~7 light[level=15] keep
setblock ~25 ~ ~15 light[level=15] keep
setblock ~25 ~ ~23 light[level=15] keep
setblock ~25 ~ ~31 light[level=15] keep
setblock ~25 ~ ~39 light[level=15] keep
setblock ~25 ~ ~47 light[level=15] keep
setblock ~25 ~ ~55 light[level=15] keep
setblock ~25 ~ ~63 light[level=15] keep
setblock ~25 ~ ~71 light[level=15] keep
setblock ~33 ~ ~-1 light[level=15] keep
setblock ~33 ~ ~7 light[level=15] keep
setblock ~33 ~ ~15 light[level=15] keep
setblock ~33 ~ ~23 light[level=15] keep
setblock ~33 ~ ~31 light[level=15] keep
setblock ~33 ~ ~39 light[level=15] keep
setblock ~33 ~ ~47 light[level=15] keep
setblock ~33 ~ ~55 light[level=15] keep
setblock ~33 ~ ~63 light[level=15] keep
setblock ~33 ~ ~71 light[level=15] keep
setblock ~41 ~ ~-1 light[level=15] keep
setblock ~41 ~ ~7 light[level=15] keep
setblock ~41 ~ ~15 light[level=15] keep
setblock ~41 ~ ~23 light[level=15] keep
setblock ~41 ~ ~31 light[level=15] keep
setblock ~41 ~ ~39 light[level=15] keep
setblock ~41 ~ ~47 light[level=15] keep
setblock ~41 ~ ~55 light[level=15] keep
setblock ~41 ~ ~63 light[level=15] keep
setblock ~41 ~ ~71 light[level=15] keep
setblock ~49 ~ ~-1 light[level=15] keep
setblock ~49 ~ ~7 light[level=15] keep
setblock ~49 ~ ~15 light[level=15] keep
setblock ~49 ~ ~23 light[level=15] keep
setblock ~49 ~ ~31 light[level=15] keep
setblock ~49 ~ ~39 light[level=15] keep
setblock ~49 ~ ~47 light[level=15] keep
setblock ~49 ~ ~55 light[level=15] keep
setblock ~49 ~ ~63 light[level=15] keep
setblock ~49 ~ ~71 light[level=15] keep
setblock ~57 ~ ~-1 light[level=15] keep
setblock ~57 ~ ~7 light[level=15] keep
setblock ~57 ~ ~15 light[level=15] keep
setblock ~57 ~ ~23 light[level=15] keep
setblock ~57 ~ ~31 light[level=15] keep
setblock ~57 ~ ~39 light[level=15] keep
setblock ~57 ~ ~47 light[level=15] keep
setblock ~57 ~ ~55 light[level=15] keep
setblock ~57 ~ ~63 light[level=15] keep
setblock ~57 ~ ~71 light[level=15] keep
setblock ~65 ~ ~-1 light[level=15] keep
setblock ~65 ~ ~7 light[level=15] keep
setblock ~65 ~ ~15 light[level=15] keep
setblock ~65 ~ ~23 light[level=15] keep
setblock ~65 ~ ~31 light[level=15] keep
setblock ~65 ~ ~39 light[level=15] keep
setblock ~65 ~ ~47 light[level=15] keep
setblock ~65 ~ ~55 light[level=15] keep
setblock ~65 ~ ~63 light[level=15] keep
setblock ~65 ~ ~71 light[level=15] keep
setblock ~73 ~ ~-1 light[level=15] keep
setblock ~73 ~ ~7 light[level=15] keep
setblock ~73 ~ ~15 light[level=15] keep
setblock ~73 ~ ~23 light[level=15] keep
setblock ~73 ~ ~31 light[level=15] keep
setblock ~73 ~ ~39 light[level=15] keep
setblock ~73 ~ ~47 light[level=15] keep
setblock ~73 ~ ~55 light[level=15] keep
setblock ~73 ~ ~63 light[level=15] keep
setblock ~73 ~ ~71 light[level=15] keep
setblock ~81 ~ ~-1 light[level=15] keep
setblock ~81 ~ ~7 light[level=15] keep
setblock ~81 ~ ~15 light[level=15] keep
setblock ~81 ~ ~23 light[level=15] keep
setblock ~81 ~ ~31 light[level=15] keep
setblock ~81 ~ ~39 light[level=15] keep
setblock ~81 ~ ~47 light[level=15] keep
setblock ~81 ~ ~55 light[level=15] keep
setblock ~81 ~ ~63 light[level=15] keep
setblock ~81 ~ ~71 light[level=15] keep
setblock ~89 ~ ~-1 light[level=15] keep
setblock ~89 ~ ~7 light[level=15] keep
setblock ~89 ~ ~15 light[level=15] keep
setblock ~89 ~ ~23 light[level=15] keep
setblock ~89 ~ ~31 light[level=15] keep
setblock ~89 ~ ~39 light[level=15] keep
setblock ~89 ~ ~47 light[level=15] keep
setblock ~89 ~ ~55 light[level=15] keep
setblock ~89 ~ ~63 light[level=15] keep
setblock ~89 ~ ~71 light[level=15] keep
setblock ~97 ~ ~-1 light[level=15] keep
setblock ~97 ~ ~7 light[level=15] keep
setblock ~97 ~ ~15 light[level=15] keep
setblock ~97 ~ ~23 light[level=15] keep
setblock ~97 ~ ~31 light[level=15] keep
setblock ~97 ~ ~39 light[level=15] keep
setblock ~97 ~ ~47 light[level=15] keep
setblock ~97 ~ ~55 light[level=15] keep
setblock ~97 ~ ~63 light[level=15] keep
setblock ~97 ~ ~71 light[level=15] keep
setblock ~105 ~ ~-1 light[level=15] keep
setblock ~105 ~ ~7 light[level=15] keep
setblock ~105 ~ ~15 light[level=15] keep
setblock ~105 ~ ~23 light[level=15] keep
setblock ~105 ~ ~31 light[level=15] keep
setblock ~105 ~ ~39 light[level=15] keep
setblock ~105 ~ ~47 light[level=15] keep
setblock ~105 ~ ~55 light[level=15] keep
setblock ~105 ~ ~63 light[level=15] keep
setblock ~105 ~ ~71 light[level=15] keep
setblock ~113 ~ ~-1 light[level=15] keep
setblock ~113 ~ ~7 light[level=15] keep
setblock ~113 ~ ~15 light[level=15] keep
setblock ~113 ~ ~23 light[level=15] keep
setblock ~113 ~ ~31 light[level=15] keep
setblock ~113 ~ ~39 light[level=15] keep
setblock ~113 ~ ~47 light[level=15] keep
setblock ~113 ~ ~55 light[level=15] keep
setblock ~113 ~ ~63 light[level=15] keep
setblock ~113 ~ ~71 light[level=15] keep
setblock ~121 ~ ~-1 light[level=15] keep
setblock ~121 ~ ~7 light[level=15] keep
setblock ~121 ~ ~15 light[level=15] keep
setblock ~121 ~ ~23 light[level=15] keep
setblock ~121 ~ ~31 light[level=15] keep
setblock ~121 ~ ~39 light[level=15] keep
setblock ~121 ~ ~47 light[level=15] keep
setblock ~121 ~ ~55 light[level=15] keep
setblock ~121 ~ ~63 light[level=15] keep
setblock ~121 ~ ~71 light[level=15] keep
setblock ~129 ~ ~-1 light[level=15] keep
setblock ~129 ~ ~7 light[level=15] keep
setblock ~129 ~ ~15 light[level=15] keep
setblock ~129 ~ ~23 light[level=15] keep
setblock ~129 ~ ~31 light[level=15] keep
setblock ~129 ~ ~39 light[level=15] keep
setblock ~129 ~ ~47 light[level=15] keep
setblock ~129 ~ ~55 light[level=15] keep
setblock ~129 ~ ~63 light[level=15] keep
setblock ~129 ~ ~71 light[level=15] keep
setblock ~137 ~ ~-1 light[level=15] keep
setblock ~137 ~ ~7 light[level=15] keep
setblock ~137 ~ ~15 light[level=15] keep
setblock ~137 ~ ~23 light[level=15] keep
setblock ~137 ~ ~31 light[level=15] keep
setblock ~137 ~ ~39 light[level=15] keep
setblock ~137 ~ ~47 light[level=15] keep
setblock ~137 ~ ~55 light[level=15] keep
setblock ~137 ~ ~63 light[level=15] keep
setblock ~137 ~ ~71 light[level=15] keep
setblock ~145 ~ ~-1 light[level=15] keep
setblock ~145 ~ ~7 light[level=15] keep
setblock ~145 ~ ~15 light[level=15] keep
setblock ~145 ~ ~23 light[level=15] keep
setblock ~145 ~ ~31 light[level=15] keep
setblock ~145 ~ ~39 light[level=15] keep
setblock ~145 ~ ~47 light[level=15] keep
setblock ~145 ~ ~55 light[level=15] keep
setblock ~145 ~ ~63 light[level=15] keep
setblock ~145 ~ ~71 light[level=15] keep
kill @e[type=minecraft:item,distance=..200]
tellraw @a {"text":"[Fase 3] LISTA! Sigue el camino de tierra del norte: montana con la casa (oeste), casa en el arbol, caballeriza, torre de elitros y los portales del End y del Nether (este).","color":"green"}
