scoreboard players set #pasos rieles 0
execute as @e[type=minecraft:marker,tag=riel_w,limit=1] at @s run function granjas:_rl_bucle
execute if score #hecho rieles matches 0 if entity @e[type=minecraft:marker,tag=riel_w] run schedule function granjas:_rl_tick 1t replace
