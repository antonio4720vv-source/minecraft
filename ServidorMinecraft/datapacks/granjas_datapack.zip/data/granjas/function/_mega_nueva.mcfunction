kill @e[type=minecraft:marker,tag=granjas_mega]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_mega"]}
function granjas:_mega0
