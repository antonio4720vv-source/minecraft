execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~-180 ~ ~100 run forceload add ~ ~
tellraw @a {"text":"[TODO] Empezando la fase 3...","color":"yellow"}
execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~-180 ~ ~100 run function granjas:fase3
