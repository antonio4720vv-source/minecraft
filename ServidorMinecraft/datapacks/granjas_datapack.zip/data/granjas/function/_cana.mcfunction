tellraw @s {"text":"Construyendo granja de CANA DE AZUCAR...","color":"yellow"}
fill ~-3 ~-1 ~-4 ~13 ~7 ~3 air
fill ~-3 ~-1 ~-4 ~13 ~-1 ~3 stone_bricks
fill ~-1 ~ ~-3 ~12 ~6 ~2 stone_bricks
fill ~ ~ ~ ~11 ~ ~ hopper[facing=west]
setblock ~-1 ~ ~ barrel[facing=west]
fill ~ ~1 ~ ~11 ~1 ~ rail[shape=east_west]
fill ~ ~2 ~ ~11 ~2 ~ sand
fill ~ ~2 ~1 ~11 ~2 ~1 water
fill ~ ~3 ~ ~11 ~5 ~ air
fill ~-1 ~3 ~1 ~12 ~6 ~1 glass
fill ~-1 ~3 ~ ~-1 ~6 ~ glass
fill ~12 ~3 ~ ~12 ~6 ~ glass
fill ~ ~3 ~ ~11 ~3 ~ sugar_cane
fill ~ ~4 ~-1 ~11 ~4 ~-1 piston[facing=south]
fill ~ ~5 ~-1 ~11 ~5 ~-1 observer[facing=south]
fill ~ ~5 ~-2 ~11 ~5 ~-2 redstone_wire
fill ~-1 ~5 ~-3 ~12 ~6 ~-3 stone_bricks
fill ~-1 ~6 ~-2 ~12 ~6 ~ glass
summon minecraft:hopper_minecart ~ ~1 ~
summon minecraft:hopper_minecart ~1 ~1 ~
summon minecraft:hopper_minecart ~2 ~1 ~
summon minecraft:hopper_minecart ~3 ~1 ~
summon minecraft:hopper_minecart ~4 ~1 ~
summon minecraft:hopper_minecart ~5 ~1 ~
summon minecraft:hopper_minecart ~6 ~1 ~
summon minecraft:hopper_minecart ~7 ~1 ~
summon minecraft:hopper_minecart ~8 ~1 ~
summon minecraft:hopper_minecart ~9 ~1 ~
summon minecraft:hopper_minecart ~10 ~1 ~
summon minecraft:hopper_minecart ~11 ~1 ~
summon minecraft:text_display ~-2 ~2 ~ {billboard:"center",text:{text:"CANA DE AZUCAR\ncofre aqui abajo",color:"gold",bold:1b},background:1073741824}
summon minecraft:marker ~-1 ~ ~ {Tags:["go_cana"]}
tellraw @s {"text":"Granja de cana lista. Es automatica: cuando la cana crece 3 bloques, los pistones la cortan y llega sola al cofre del lado oeste.","color":"green"}
