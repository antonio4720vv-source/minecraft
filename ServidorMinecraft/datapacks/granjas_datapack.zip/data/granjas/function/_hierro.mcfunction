tellraw @s {"text":"Construyendo granja de HIERRO v2...","color":"yellow"}
fill ~-4 ~-1 ~-3 ~19 ~15 ~19 air
fill ~-1 ~-1 ~-1 ~18 ~3 ~18 stone_bricks
fill ~-1 ~4 ~-1 ~18 ~4 ~18 smooth_stone
fill ~-1 ~5 ~-1 ~18 ~6 ~18 glass hollow
fill ~ ~5 ~ ~17 ~6 ~17 air
fill ~8 ~4 ~ ~9 ~4 ~17 air
fill ~ ~5 ~ ~ ~5 ~17 water
fill ~17 ~5 ~ ~17 ~5 ~17 water
fill ~8 ~4 ~ ~9 ~4 ~ water
fill ~8 ~4 ~17 ~9 ~4 ~17 water
fill ~8 ~3 ~8 ~9 ~3 ~9 soul_campfire[lit=true]
fill ~5 ~ ~5 ~12 ~2 ~12 air
fill ~ ~ ~8 ~4 ~1 ~9 air
fill ~8 ~2 ~8 ~9 ~1 ~9 hopper[facing=down]
fill ~8 ~ ~8 ~9 ~ ~9 barrel[facing=up]
setblock ~6 ~-1 ~6 glowstone
setblock ~11 ~-1 ~11 glowstone
setblock ~6 ~-1 ~11 glowstone
setblock ~11 ~-1 ~6 glowstone
setblock ~2 ~-1 ~8 glowstone
setblock ~-1 ~ ~8 iron_door[half=lower,facing=east,hinge=left]
setblock ~-1 ~1 ~8 iron_door[half=upper,facing=east,hinge=left]
setblock ~-2 ~1 ~9 stone_button[face=wall,facing=west]
setblock ~ ~1 ~9 stone_button[face=wall,facing=east]
summon minecraft:text_display ~-2 ~3 ~8 {billboard:"center",text:{text:"GRANJA DE HIERRO\nlos barriles estan adentro",color:"gold",bold:1b},background:1073741824}
fill ~5 ~9 ~5 ~12 ~9 ~12 smooth_stone
fill ~5 ~10 ~5 ~12 ~11 ~12 glass
fill ~6 ~10 ~6 ~11 ~11 ~11 air
fill ~5 ~12 ~5 ~12 ~12 ~12 glass
setblock ~6 ~10 ~10 red_bed[facing=south,part=foot]
setblock ~6 ~10 ~11 red_bed[facing=south,part=head]
setblock ~8 ~10 ~10 red_bed[facing=south,part=foot]
setblock ~8 ~10 ~11 red_bed[facing=south,part=head]
setblock ~10 ~10 ~10 red_bed[facing=south,part=foot]
setblock ~10 ~10 ~11 red_bed[facing=south,part=head]
fill ~6 ~9 ~13 ~11 ~9 ~14 smooth_stone
fill ~6 ~10 ~13 ~11 ~11 ~14 glass
fill ~7 ~10 ~13 ~10 ~11 ~13 air
fill ~6 ~12 ~13 ~11 ~12 ~14 glass
fill ~7 ~11 ~12 ~10 ~11 ~12 air
summon minecraft:zombie ~8 ~10 ~13 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
summon minecraft:villager ~7 ~10 ~9 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~9 ~10 ~9 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~10 ~10 ~9 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:marker ~8 ~ ~8 {Tags:["go_hierro"]}
tellraw @s {"text":"Granja de hierro lista. Entra por la puerta de hierro (boton al lado): los 4 barriles del centro se llenan solos. Empieza despues de la primera noche.","color":"green"}
