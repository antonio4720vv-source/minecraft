execute align xyz positioned ~0.5 ~ ~0.5 run function granjas:_f3_nueva
