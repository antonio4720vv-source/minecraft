tellraw @a {"text":"[Fase 1] Edificio de aldeanos: 4 criaderos...","color":"yellow"}
fill ~52 ~-1 ~7 ~54 ~15 ~11 stone_bricks
fill ~53 ~ ~9 ~53 ~16 ~9 ladder[facing=west]
setblock ~54 ~16 ~9 stone_bricks
fill ~53 ~ ~7 ~53 ~1 ~8 air
setblock ~53 ~-1 ~6 stone_bricks
setblock ~52 ~ ~6 lantern
setblock ~54 ~ ~6 lantern
summon minecraft:text_display ~53 ~3 ~5 {billboard:"center",text:{text:"CRIADEROS (4 pisos)\ny SALA DE COMERCIO arriba\nentra y sube por la escalera",color:"gold",bold:1b},background:1073741824}
fill ~33 ~-1 ~3 ~51 ~-1 ~15 stone_bricks
fill ~33 ~ ~3 ~51 ~2 ~15 air
fill ~33 ~ ~3 ~45 ~2 ~3 glass
fill ~33 ~ ~15 ~45 ~2 ~15 glass
fill ~33 ~ ~3 ~33 ~2 ~15 glass
fill ~45 ~ ~3 ~45 ~2 ~15 glass
fill ~33 ~ ~3 ~33 ~2 ~3 stripped_spruce_log
fill ~45 ~ ~3 ~45 ~2 ~3 stripped_spruce_log
fill ~33 ~ ~15 ~33 ~2 ~15 stripped_spruce_log
fill ~45 ~ ~15 ~45 ~2 ~15 stripped_spruce_log
setblock ~34 ~ ~4 white_bed[facing=south,part=foot]
setblock ~34 ~ ~5 white_bed[facing=south,part=head]
setblock ~34 ~ ~14 white_bed[facing=north,part=foot]
setblock ~34 ~ ~13 white_bed[facing=north,part=head]
setblock ~35 ~ ~4 white_bed[facing=south,part=foot]
setblock ~35 ~ ~5 white_bed[facing=south,part=head]
setblock ~35 ~ ~14 white_bed[facing=north,part=foot]
setblock ~35 ~ ~13 white_bed[facing=north,part=head]
setblock ~36 ~ ~4 white_bed[facing=south,part=foot]
setblock ~36 ~ ~5 white_bed[facing=south,part=head]
setblock ~36 ~ ~14 white_bed[facing=north,part=foot]
setblock ~36 ~ ~13 white_bed[facing=north,part=head]
setblock ~37 ~ ~4 white_bed[facing=south,part=foot]
setblock ~37 ~ ~5 white_bed[facing=south,part=head]
setblock ~37 ~ ~14 white_bed[facing=north,part=foot]
setblock ~37 ~ ~13 white_bed[facing=north,part=head]
setblock ~38 ~ ~4 white_bed[facing=south,part=foot]
setblock ~38 ~ ~5 white_bed[facing=south,part=head]
setblock ~38 ~ ~14 white_bed[facing=north,part=foot]
setblock ~38 ~ ~13 white_bed[facing=north,part=head]
setblock ~39 ~ ~4 white_bed[facing=south,part=foot]
setblock ~39 ~ ~5 white_bed[facing=south,part=head]
setblock ~39 ~ ~14 white_bed[facing=north,part=foot]
setblock ~39 ~ ~13 white_bed[facing=north,part=head]
setblock ~40 ~ ~4 white_bed[facing=south,part=foot]
setblock ~40 ~ ~5 white_bed[facing=south,part=head]
setblock ~40 ~ ~14 white_bed[facing=north,part=foot]
setblock ~40 ~ ~13 white_bed[facing=north,part=head]
setblock ~41 ~ ~4 white_bed[facing=south,part=foot]
setblock ~41 ~ ~5 white_bed[facing=south,part=head]
setblock ~41 ~ ~14 white_bed[facing=north,part=foot]
setblock ~41 ~ ~13 white_bed[facing=north,part=head]
setblock ~42 ~ ~4 white_bed[facing=south,part=foot]
setblock ~42 ~ ~5 white_bed[facing=south,part=head]
setblock ~42 ~ ~14 white_bed[facing=north,part=foot]
setblock ~42 ~ ~13 white_bed[facing=north,part=head]
setblock ~43 ~ ~4 white_bed[facing=south,part=foot]
setblock ~43 ~ ~5 white_bed[facing=south,part=head]
setblock ~43 ~ ~14 white_bed[facing=north,part=foot]
setblock ~43 ~ ~13 white_bed[facing=north,part=head]
setblock ~44 ~ ~4 white_bed[facing=south,part=foot]
setblock ~44 ~ ~5 white_bed[facing=south,part=head]
setblock ~44 ~ ~14 white_bed[facing=north,part=foot]
setblock ~44 ~ ~13 white_bed[facing=north,part=head]
setblock ~45 ~ ~9 air
fill ~45 ~ ~6 ~51 ~2 ~6 glass
fill ~45 ~ ~12 ~51 ~2 ~12 glass
fill ~45 ~ ~6 ~45 ~2 ~12 glass
fill ~51 ~ ~6 ~51 ~2 ~12 glass
setblock ~45 ~ ~9 air
setblock ~45 ~1 ~9 glass
setblock ~51 ~ ~9 iron_door[half=lower,facing=west,hinge=left]
setblock ~51 ~1 ~9 iron_door[half=upper,facing=west,hinge=left]
setblock ~50 ~1 ~10 stone_button[face=wall,facing=west]
setblock ~36 ~2 ~9 light[level=15]
setblock ~42 ~2 ~9 light[level=15]
setblock ~39 ~2 ~7 light[level=15]
setblock ~39 ~2 ~11 light[level=15]
setblock ~48 ~2 ~9 light[level=15]
summon minecraft:villager ~37 ~ ~8 {PersistenceRequired:1b,CustomName:"Padre 1",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~ ~8 {PersistenceRequired:1b,CustomName:"Padre 2",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~37 ~ ~10 {PersistenceRequired:1b,CustomName:"Padre 3",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~ ~10 {PersistenceRequired:1b,CustomName:"Padre 4",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:marker ~48 ~ ~9 {Tags:["go_bebes","f1"]}
fill ~52 ~ ~8 ~52 ~1 ~10 air
setblock ~52 ~1 ~10 stone_button[face=wall,facing=east]
fill ~33 ~3 ~3 ~51 ~3 ~15 stone_bricks
fill ~33 ~4 ~3 ~51 ~6 ~15 air
fill ~33 ~4 ~3 ~45 ~6 ~3 glass
fill ~33 ~4 ~15 ~45 ~6 ~15 glass
fill ~33 ~4 ~3 ~33 ~6 ~15 glass
fill ~45 ~4 ~3 ~45 ~6 ~15 glass
fill ~33 ~4 ~3 ~33 ~6 ~3 stripped_spruce_log
fill ~45 ~4 ~3 ~45 ~6 ~3 stripped_spruce_log
fill ~33 ~4 ~15 ~33 ~6 ~15 stripped_spruce_log
fill ~45 ~4 ~15 ~45 ~6 ~15 stripped_spruce_log
setblock ~34 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~34 ~4 ~5 white_bed[facing=south,part=head]
setblock ~34 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~34 ~4 ~13 white_bed[facing=north,part=head]
setblock ~35 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~35 ~4 ~5 white_bed[facing=south,part=head]
setblock ~35 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~35 ~4 ~13 white_bed[facing=north,part=head]
setblock ~36 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~36 ~4 ~5 white_bed[facing=south,part=head]
setblock ~36 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~36 ~4 ~13 white_bed[facing=north,part=head]
setblock ~37 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~37 ~4 ~5 white_bed[facing=south,part=head]
setblock ~37 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~37 ~4 ~13 white_bed[facing=north,part=head]
setblock ~38 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~38 ~4 ~5 white_bed[facing=south,part=head]
setblock ~38 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~38 ~4 ~13 white_bed[facing=north,part=head]
setblock ~39 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~39 ~4 ~5 white_bed[facing=south,part=head]
setblock ~39 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~39 ~4 ~13 white_bed[facing=north,part=head]
setblock ~40 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~40 ~4 ~5 white_bed[facing=south,part=head]
setblock ~40 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~40 ~4 ~13 white_bed[facing=north,part=head]
setblock ~41 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~41 ~4 ~5 white_bed[facing=south,part=head]
setblock ~41 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~41 ~4 ~13 white_bed[facing=north,part=head]
setblock ~42 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~42 ~4 ~5 white_bed[facing=south,part=head]
setblock ~42 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~42 ~4 ~13 white_bed[facing=north,part=head]
setblock ~43 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~43 ~4 ~5 white_bed[facing=south,part=head]
setblock ~43 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~43 ~4 ~13 white_bed[facing=north,part=head]
setblock ~44 ~4 ~4 white_bed[facing=south,part=foot]
setblock ~44 ~4 ~5 white_bed[facing=south,part=head]
setblock ~44 ~4 ~14 white_bed[facing=north,part=foot]
setblock ~44 ~4 ~13 white_bed[facing=north,part=head]
setblock ~45 ~4 ~9 air
fill ~45 ~4 ~6 ~51 ~6 ~6 glass
fill ~45 ~4 ~12 ~51 ~6 ~12 glass
fill ~45 ~4 ~6 ~45 ~6 ~12 glass
fill ~51 ~4 ~6 ~51 ~6 ~12 glass
setblock ~45 ~4 ~9 air
setblock ~45 ~5 ~9 glass
setblock ~51 ~4 ~9 iron_door[half=lower,facing=west,hinge=left]
setblock ~51 ~5 ~9 iron_door[half=upper,facing=west,hinge=left]
setblock ~50 ~5 ~10 stone_button[face=wall,facing=west]
setblock ~36 ~6 ~9 light[level=15]
setblock ~42 ~6 ~9 light[level=15]
setblock ~39 ~6 ~7 light[level=15]
setblock ~39 ~6 ~11 light[level=15]
setblock ~48 ~6 ~9 light[level=15]
summon minecraft:villager ~37 ~4 ~8 {PersistenceRequired:1b,CustomName:"Padre 5",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~4 ~8 {PersistenceRequired:1b,CustomName:"Padre 6",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~37 ~4 ~10 {PersistenceRequired:1b,CustomName:"Padre 7",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~4 ~10 {PersistenceRequired:1b,CustomName:"Padre 8",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:marker ~48 ~4 ~9 {Tags:["go_bebes","f1"]}
fill ~52 ~4 ~8 ~52 ~5 ~10 air
setblock ~52 ~5 ~10 stone_button[face=wall,facing=east]
fill ~33 ~7 ~3 ~51 ~7 ~15 stone_bricks
fill ~33 ~8 ~3 ~51 ~10 ~15 air
fill ~33 ~8 ~3 ~45 ~10 ~3 glass
fill ~33 ~8 ~15 ~45 ~10 ~15 glass
fill ~33 ~8 ~3 ~33 ~10 ~15 glass
fill ~45 ~8 ~3 ~45 ~10 ~15 glass
fill ~33 ~8 ~3 ~33 ~10 ~3 stripped_spruce_log
fill ~45 ~8 ~3 ~45 ~10 ~3 stripped_spruce_log
fill ~33 ~8 ~15 ~33 ~10 ~15 stripped_spruce_log
fill ~45 ~8 ~15 ~45 ~10 ~15 stripped_spruce_log
setblock ~34 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~34 ~8 ~5 white_bed[facing=south,part=head]
setblock ~34 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~34 ~8 ~13 white_bed[facing=north,part=head]
setblock ~35 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~35 ~8 ~5 white_bed[facing=south,part=head]
setblock ~35 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~35 ~8 ~13 white_bed[facing=north,part=head]
setblock ~36 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~36 ~8 ~5 white_bed[facing=south,part=head]
setblock ~36 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~36 ~8 ~13 white_bed[facing=north,part=head]
setblock ~37 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~37 ~8 ~5 white_bed[facing=south,part=head]
setblock ~37 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~37 ~8 ~13 white_bed[facing=north,part=head]
setblock ~38 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~38 ~8 ~5 white_bed[facing=south,part=head]
setblock ~38 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~38 ~8 ~13 white_bed[facing=north,part=head]
setblock ~39 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~39 ~8 ~5 white_bed[facing=south,part=head]
setblock ~39 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~39 ~8 ~13 white_bed[facing=north,part=head]
setblock ~40 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~40 ~8 ~5 white_bed[facing=south,part=head]
setblock ~40 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~40 ~8 ~13 white_bed[facing=north,part=head]
setblock ~41 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~41 ~8 ~5 white_bed[facing=south,part=head]
setblock ~41 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~41 ~8 ~13 white_bed[facing=north,part=head]
setblock ~42 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~42 ~8 ~5 white_bed[facing=south,part=head]
setblock ~42 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~42 ~8 ~13 white_bed[facing=north,part=head]
setblock ~43 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~43 ~8 ~5 white_bed[facing=south,part=head]
setblock ~43 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~43 ~8 ~13 white_bed[facing=north,part=head]
setblock ~44 ~8 ~4 white_bed[facing=south,part=foot]
setblock ~44 ~8 ~5 white_bed[facing=south,part=head]
setblock ~44 ~8 ~14 white_bed[facing=north,part=foot]
setblock ~44 ~8 ~13 white_bed[facing=north,part=head]
setblock ~45 ~8 ~9 air
fill ~45 ~8 ~6 ~51 ~10 ~6 glass
fill ~45 ~8 ~12 ~51 ~10 ~12 glass
fill ~45 ~8 ~6 ~45 ~10 ~12 glass
fill ~51 ~8 ~6 ~51 ~10 ~12 glass
setblock ~45 ~8 ~9 air
setblock ~45 ~9 ~9 glass
setblock ~51 ~8 ~9 iron_door[half=lower,facing=west,hinge=left]
setblock ~51 ~9 ~9 iron_door[half=upper,facing=west,hinge=left]
setblock ~50 ~9 ~10 stone_button[face=wall,facing=west]
setblock ~36 ~10 ~9 light[level=15]
setblock ~42 ~10 ~9 light[level=15]
setblock ~39 ~10 ~7 light[level=15]
setblock ~39 ~10 ~11 light[level=15]
setblock ~48 ~10 ~9 light[level=15]
summon minecraft:villager ~37 ~8 ~8 {PersistenceRequired:1b,CustomName:"Padre 9",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~8 ~8 {PersistenceRequired:1b,CustomName:"Padre 10",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~37 ~8 ~10 {PersistenceRequired:1b,CustomName:"Padre 11",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~8 ~10 {PersistenceRequired:1b,CustomName:"Padre 12",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:marker ~48 ~8 ~9 {Tags:["go_bebes","f1"]}
fill ~52 ~8 ~8 ~52 ~9 ~10 air
setblock ~52 ~9 ~10 stone_button[face=wall,facing=east]
fill ~33 ~11 ~3 ~51 ~11 ~15 stone_bricks
fill ~33 ~12 ~3 ~51 ~14 ~15 air
fill ~33 ~12 ~3 ~45 ~14 ~3 glass
fill ~33 ~12 ~15 ~45 ~14 ~15 glass
fill ~33 ~12 ~3 ~33 ~14 ~15 glass
fill ~45 ~12 ~3 ~45 ~14 ~15 glass
fill ~33 ~12 ~3 ~33 ~14 ~3 stripped_spruce_log
fill ~45 ~12 ~3 ~45 ~14 ~3 stripped_spruce_log
fill ~33 ~12 ~15 ~33 ~14 ~15 stripped_spruce_log
fill ~45 ~12 ~15 ~45 ~14 ~15 stripped_spruce_log
setblock ~34 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~34 ~12 ~5 white_bed[facing=south,part=head]
setblock ~34 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~34 ~12 ~13 white_bed[facing=north,part=head]
setblock ~35 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~35 ~12 ~5 white_bed[facing=south,part=head]
setblock ~35 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~35 ~12 ~13 white_bed[facing=north,part=head]
setblock ~36 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~36 ~12 ~5 white_bed[facing=south,part=head]
setblock ~36 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~36 ~12 ~13 white_bed[facing=north,part=head]
setblock ~37 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~37 ~12 ~5 white_bed[facing=south,part=head]
setblock ~37 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~37 ~12 ~13 white_bed[facing=north,part=head]
setblock ~38 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~38 ~12 ~5 white_bed[facing=south,part=head]
setblock ~38 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~38 ~12 ~13 white_bed[facing=north,part=head]
setblock ~39 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~39 ~12 ~5 white_bed[facing=south,part=head]
setblock ~39 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~39 ~12 ~13 white_bed[facing=north,part=head]
setblock ~40 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~40 ~12 ~5 white_bed[facing=south,part=head]
setblock ~40 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~40 ~12 ~13 white_bed[facing=north,part=head]
setblock ~41 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~41 ~12 ~5 white_bed[facing=south,part=head]
setblock ~41 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~41 ~12 ~13 white_bed[facing=north,part=head]
setblock ~42 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~42 ~12 ~5 white_bed[facing=south,part=head]
setblock ~42 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~42 ~12 ~13 white_bed[facing=north,part=head]
setblock ~43 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~43 ~12 ~5 white_bed[facing=south,part=head]
setblock ~43 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~43 ~12 ~13 white_bed[facing=north,part=head]
setblock ~44 ~12 ~4 white_bed[facing=south,part=foot]
setblock ~44 ~12 ~5 white_bed[facing=south,part=head]
setblock ~44 ~12 ~14 white_bed[facing=north,part=foot]
setblock ~44 ~12 ~13 white_bed[facing=north,part=head]
setblock ~45 ~12 ~9 air
fill ~45 ~12 ~6 ~51 ~14 ~6 glass
fill ~45 ~12 ~12 ~51 ~14 ~12 glass
fill ~45 ~12 ~6 ~45 ~14 ~12 glass
fill ~51 ~12 ~6 ~51 ~14 ~12 glass
setblock ~45 ~12 ~9 air
setblock ~45 ~13 ~9 glass
setblock ~51 ~12 ~9 iron_door[half=lower,facing=west,hinge=left]
setblock ~51 ~13 ~9 iron_door[half=upper,facing=west,hinge=left]
setblock ~50 ~13 ~10 stone_button[face=wall,facing=west]
setblock ~36 ~14 ~9 light[level=15]
setblock ~42 ~14 ~9 light[level=15]
setblock ~39 ~14 ~7 light[level=15]
setblock ~39 ~14 ~11 light[level=15]
setblock ~48 ~14 ~9 light[level=15]
summon minecraft:villager ~37 ~12 ~8 {PersistenceRequired:1b,CustomName:"Padre 13",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~12 ~8 {PersistenceRequired:1b,CustomName:"Padre 14",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~37 ~12 ~10 {PersistenceRequired:1b,CustomName:"Padre 15",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:villager ~39 ~12 ~10 {PersistenceRequired:1b,CustomName:"Padre 16",Inventory:[{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64},{id:"minecraft:bread",count:64}]}
summon minecraft:marker ~48 ~12 ~9 {Tags:["go_bebes","f1"]}
fill ~52 ~12 ~8 ~52 ~13 ~10 air
setblock ~52 ~13 ~10 stone_button[face=wall,facing=east]
