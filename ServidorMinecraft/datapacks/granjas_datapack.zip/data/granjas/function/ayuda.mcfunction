scoreboard objectives add granjas dummy
execute unless score #on granjas matches 0..1 run scoreboard players set #on granjas 0
schedule function granjas:producir 30s replace
tellraw @a {"text":"[Granjas v7] /function granjas:lista  para ver todos los comandos","color":"gold"}
