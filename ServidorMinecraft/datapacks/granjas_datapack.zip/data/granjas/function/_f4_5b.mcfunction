tellraw @a {"text":"[Fase 4] Bunker: granja interna y tradeo...","color":"yellow"}
fill ~9 ~-27 ~16 ~13 ~-27 ~20 farmland[moisture=7]
setblock ~11 ~-27 ~18 water
fill ~9 ~-26 ~16 ~13 ~-26 ~20 wheat[age=7]
setblock ~11 ~-26 ~18 air
fill ~15 ~-27 ~16 ~19 ~-27 ~20 farmland[moisture=7]
setblock ~17 ~-27 ~18 water
fill ~15 ~-26 ~16 ~19 ~-26 ~20 carrots[age=7]
setblock ~17 ~-26 ~18 air
fill ~21 ~-27 ~16 ~25 ~-27 ~20 farmland[moisture=7]
setblock ~23 ~-27 ~18 water
fill ~21 ~-26 ~16 ~25 ~-26 ~20 potatoes[age=7]
setblock ~23 ~-26 ~18 air
fill ~9 ~-27 ~22 ~13 ~-27 ~26 farmland[moisture=7]
setblock ~11 ~-27 ~24 water
fill ~9 ~-26 ~22 ~13 ~-26 ~26 beetroots[age=3]
setblock ~11 ~-26 ~24 air
fill ~15 ~-27 ~22 ~19 ~-27 ~22 sand
fill ~15 ~-27 ~23 ~19 ~-27 ~23 water
fill ~15 ~-27 ~24 ~19 ~-27 ~24 sand
fill ~15 ~-26 ~22 ~19 ~-25 ~22 sugar_cane
fill ~15 ~-26 ~24 ~19 ~-25 ~24 sugar_cane
fill ~21 ~-27 ~22 ~25 ~-27 ~24 grass_block
fill ~21 ~-26 ~23 ~25 ~-24 ~23 bamboo
fill ~21 ~-26 ~22 ~25 ~-26 ~22 sweet_berry_bush[age=3]
fill ~21 ~-27 ~26 ~25 ~-27 ~26 mycelium
setblock ~21 ~-26 ~26 red_mushroom
setblock ~23 ~-26 ~26 brown_mushroom
setblock ~25 ~-26 ~26 red_mushroom
setblock ~17 ~-23 ~20 light[level=15]
setblock ~23 ~-23 ~20 light[level=15]
setblock ~17 ~-23 ~25 light[level=15]
setblock ~23 ~-23 ~25 light[level=15]
setblock ~11 ~-23 ~28 light[level=15]
setblock ~21 ~-23 ~28 light[level=15]
fill ~9 ~-27 ~28 ~12 ~-27 ~32 grass_block
fill ~8 ~-26 ~27 ~13 ~-26 ~27 oak_fence
fill ~8 ~-26 ~33 ~13 ~-26 ~33 oak_fence
fill ~8 ~-26 ~27 ~8 ~-26 ~33 oak_fence
fill ~13 ~-26 ~27 ~13 ~-26 ~33 oak_fence
setblock ~10 ~-26 ~27 oak_fence_gate[facing=north]
summon minecraft:cow ~10 ~-26 ~29 {PersistenceRequired:1b}
summon minecraft:cow ~11 ~-26 ~29 {PersistenceRequired:1b}
fill ~14 ~-27 ~28 ~17 ~-27 ~32 grass_block
fill ~13 ~-26 ~27 ~18 ~-26 ~27 oak_fence
fill ~13 ~-26 ~33 ~18 ~-26 ~33 oak_fence
fill ~13 ~-26 ~27 ~13 ~-26 ~33 oak_fence
fill ~18 ~-26 ~27 ~18 ~-26 ~33 oak_fence
setblock ~15 ~-26 ~27 oak_fence_gate[facing=north]
summon minecraft:sheep ~15 ~-26 ~29 {PersistenceRequired:1b}
summon minecraft:sheep ~16 ~-26 ~29 {PersistenceRequired:1b}
fill ~19 ~-27 ~28 ~22 ~-27 ~32 grass_block
fill ~18 ~-26 ~27 ~23 ~-26 ~27 oak_fence
fill ~18 ~-26 ~33 ~23 ~-26 ~33 oak_fence
fill ~18 ~-26 ~27 ~18 ~-26 ~33 oak_fence
fill ~23 ~-26 ~27 ~23 ~-26 ~33 oak_fence
setblock ~20 ~-26 ~27 oak_fence_gate[facing=north]
summon minecraft:pig ~20 ~-26 ~29 {PersistenceRequired:1b}
summon minecraft:pig ~21 ~-26 ~29 {PersistenceRequired:1b}
fill ~24 ~-27 ~28 ~27 ~-27 ~32 grass_block
fill ~23 ~-26 ~27 ~28 ~-26 ~27 oak_fence
fill ~23 ~-26 ~33 ~28 ~-26 ~33 oak_fence
fill ~23 ~-26 ~27 ~23 ~-26 ~33 oak_fence
fill ~28 ~-26 ~27 ~28 ~-26 ~33 oak_fence
setblock ~25 ~-26 ~27 oak_fence_gate[facing=north]
summon minecraft:chicken ~25 ~-26 ~29 {PersistenceRequired:1b}
summon minecraft:chicken ~26 ~-26 ~29 {PersistenceRequired:1b}
summon minecraft:chicken ~25 ~-26 ~30 {PersistenceRequired:1b}
setblock ~27 ~-26 ~16 barrel[facing=west]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:carrot",count:64},{Slot:2b,id:"minecraft:wheat_seeds",count:64},{Slot:3b,id:"minecraft:bone_meal",count:64}]}
setblock ~27 ~-26 ~20 barrel[facing=west]
summon minecraft:marker ~27 ~-26 ~20 {Tags:["go_hierro","f4"]}
summon minecraft:text_display ~27 ~-24 ~20 {billboard:"center",text:{text:"BOVEDA DE HIERRO\n(produccion asegurada)",color:"white",bold:1b},background:1073741824}
summon minecraft:text_display ~18 ~-22 ~18 {billboard:"center",text:{text:"GRANJA INTERNA",color:"yellow",bold:1b},background:1073741824}
fill ~44 ~-26 ~15 ~47 ~-24 ~32 deepslate_bricks
fill ~46 ~-26 ~16 ~46 ~-25 ~16 air
setblock ~45 ~-25 ~16 air
setblock ~47 ~-26 ~16 lectern
setblock ~45 ~-24 ~16 glowstone
summon minecraft:villager ~46 ~-26 ~16 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 1",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~18 ~46 ~-25 ~18 air
setblock ~45 ~-25 ~18 air
setblock ~47 ~-26 ~18 lectern
setblock ~45 ~-24 ~18 glowstone
summon minecraft:villager ~46 ~-26 ~18 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 2",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~20 ~46 ~-25 ~20 air
setblock ~45 ~-25 ~20 air
setblock ~47 ~-26 ~20 lectern
setblock ~45 ~-24 ~20 glowstone
summon minecraft:villager ~46 ~-26 ~20 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 3",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~22 ~46 ~-25 ~22 air
setblock ~45 ~-25 ~22 air
setblock ~47 ~-26 ~22 blast_furnace
setblock ~45 ~-24 ~22 glowstone
summon minecraft:villager ~46 ~-26 ~22 {PersistenceRequired:1b,Xp:1,CustomName:"Armero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:armorer",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~24 ~46 ~-25 ~24 air
setblock ~45 ~-25 ~24 air
setblock ~47 ~-26 ~24 smithing_table
setblock ~45 ~-24 ~24 glowstone
summon minecraft:villager ~46 ~-26 ~24 {PersistenceRequired:1b,Xp:1,CustomName:"Herrero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:toolsmith",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~26 ~46 ~-25 ~26 air
setblock ~45 ~-25 ~26 air
setblock ~47 ~-26 ~26 grindstone
setblock ~45 ~-24 ~26 glowstone
summon minecraft:villager ~46 ~-26 ~26 {PersistenceRequired:1b,Xp:1,CustomName:"Armas",CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~28 ~46 ~-25 ~28 air
setblock ~45 ~-25 ~28 air
setblock ~47 ~-26 ~28 brewing_stand
setblock ~45 ~-24 ~28 glowstone
summon minecraft:villager ~46 ~-26 ~28 {PersistenceRequired:1b,Xp:1,CustomName:"Clerigo",CustomNameVisible:1b,VillagerData:{profession:"minecraft:cleric",level:1,type:"minecraft:plains"}}
fill ~46 ~-26 ~30 ~46 ~-25 ~30 air
setblock ~45 ~-25 ~30 air
setblock ~47 ~-26 ~30 composter
setblock ~45 ~-24 ~30 glowstone
summon minecraft:villager ~46 ~-26 ~30 {PersistenceRequired:1b,Xp:1,CustomName:"Granjero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:farmer",level:1,type:"minecraft:plains"}}
fill ~32 ~-27 ~22 ~40 ~-27 ~28 polished_blackstone_bricks
summon minecraft:text_display ~38 ~-22 ~24 {billboard:"center",text:{text:"SALA DE TRADEO",color:"yellow",bold:1b},background:1073741824}
setblock ~-1 ~ ~-13 light[level=15] keep
setblock ~-1 ~ ~-5 light[level=15] keep
setblock ~-1 ~ ~3 light[level=15] keep
setblock ~-1 ~ ~11 light[level=15] keep
setblock ~-1 ~ ~19 light[level=15] keep
setblock ~-1 ~ ~27 light[level=15] keep
setblock ~-1 ~ ~35 light[level=15] keep
setblock ~-1 ~ ~43 light[level=15] keep
setblock ~-1 ~ ~51 light[level=15] keep
setblock ~-1 ~ ~59 light[level=15] keep
setblock ~7 ~ ~-13 light[level=15] keep
setblock ~7 ~ ~-5 light[level=15] keep
setblock ~7 ~ ~3 light[level=15] keep
setblock ~7 ~ ~11 light[level=15] keep
setblock ~7 ~ ~19 light[level=15] keep
setblock ~7 ~ ~27 light[level=15] keep
setblock ~7 ~ ~35 light[level=15] keep
setblock ~7 ~ ~43 light[level=15] keep
setblock ~7 ~ ~51 light[level=15] keep
setblock ~7 ~ ~59 light[level=15] keep
setblock ~15 ~ ~-13 light[level=15] keep
setblock ~15 ~ ~-5 light[level=15] keep
setblock ~15 ~ ~3 light[level=15] keep
setblock ~15 ~ ~11 light[level=15] keep
setblock ~15 ~ ~19 light[level=15] keep
setblock ~15 ~ ~27 light[level=15] keep
setblock ~15 ~ ~35 light[level=15] keep
setblock ~15 ~ ~43 light[level=15] keep
setblock ~15 ~ ~51 light[level=15] keep
setblock ~15 ~ ~59 light[level=15] keep
setblock ~23 ~ ~-13 light[level=15] keep
setblock ~23 ~ ~-5 light[level=15] keep
setblock ~23 ~ ~3 light[level=15] keep
setblock ~23 ~ ~11 light[level=15] keep
setblock ~23 ~ ~19 light[level=15] keep
setblock ~23 ~ ~27 light[level=15] keep
setblock ~23 ~ ~35 light[level=15] keep
setblock ~23 ~ ~43 light[level=15] keep
setblock ~23 ~ ~51 light[level=15] keep
setblock ~23 ~ ~59 light[level=15] keep
setblock ~31 ~ ~-13 light[level=15] keep
setblock ~31 ~ ~-5 light[level=15] keep
setblock ~31 ~ ~3 light[level=15] keep
setblock ~31 ~ ~11 light[level=15] keep
setblock ~31 ~ ~19 light[level=15] keep
setblock ~31 ~ ~27 light[level=15] keep
setblock ~31 ~ ~35 light[level=15] keep
setblock ~31 ~ ~43 light[level=15] keep
setblock ~31 ~ ~51 light[level=15] keep
setblock ~31 ~ ~59 light[level=15] keep
setblock ~39 ~ ~-13 light[level=15] keep
setblock ~39 ~ ~-5 light[level=15] keep
setblock ~39 ~ ~3 light[level=15] keep
setblock ~39 ~ ~11 light[level=15] keep
setblock ~39 ~ ~19 light[level=15] keep
setblock ~39 ~ ~27 light[level=15] keep
setblock ~39 ~ ~35 light[level=15] keep
setblock ~39 ~ ~43 light[level=15] keep
setblock ~39 ~ ~51 light[level=15] keep
setblock ~39 ~ ~59 light[level=15] keep
setblock ~47 ~ ~-13 light[level=15] keep
setblock ~47 ~ ~-5 light[level=15] keep
setblock ~47 ~ ~3 light[level=15] keep
setblock ~47 ~ ~11 light[level=15] keep
setblock ~47 ~ ~19 light[level=15] keep
setblock ~47 ~ ~27 light[level=15] keep
setblock ~47 ~ ~35 light[level=15] keep
setblock ~47 ~ ~43 light[level=15] keep
setblock ~47 ~ ~51 light[level=15] keep
setblock ~47 ~ ~59 light[level=15] keep
setblock ~55 ~ ~-13 light[level=15] keep
setblock ~55 ~ ~-5 light[level=15] keep
setblock ~55 ~ ~3 light[level=15] keep
setblock ~55 ~ ~11 light[level=15] keep
setblock ~55 ~ ~19 light[level=15] keep
setblock ~55 ~ ~27 light[level=15] keep
setblock ~55 ~ ~35 light[level=15] keep
setblock ~55 ~ ~43 light[level=15] keep
setblock ~55 ~ ~51 light[level=15] keep
setblock ~55 ~ ~59 light[level=15] keep
setblock ~63 ~ ~-13 light[level=15] keep
setblock ~63 ~ ~-5 light[level=15] keep
setblock ~63 ~ ~3 light[level=15] keep
setblock ~63 ~ ~11 light[level=15] keep
setblock ~63 ~ ~19 light[level=15] keep
setblock ~63 ~ ~27 light[level=15] keep
setblock ~63 ~ ~35 light[level=15] keep
setblock ~63 ~ ~43 light[level=15] keep
setblock ~63 ~ ~51 light[level=15] keep
setblock ~63 ~ ~59 light[level=15] keep
setblock ~71 ~ ~-13 light[level=15] keep
setblock ~71 ~ ~-5 light[level=15] keep
setblock ~71 ~ ~3 light[level=15] keep
setblock ~71 ~ ~11 light[level=15] keep
setblock ~71 ~ ~19 light[level=15] keep
setblock ~71 ~ ~27 light[level=15] keep
setblock ~71 ~ ~35 light[level=15] keep
setblock ~71 ~ ~43 light[level=15] keep
setblock ~71 ~ ~51 light[level=15] keep
setblock ~71 ~ ~59 light[level=15] keep
setblock ~79 ~ ~-13 light[level=15] keep
setblock ~79 ~ ~-5 light[level=15] keep
setblock ~79 ~ ~3 light[level=15] keep
setblock ~79 ~ ~11 light[level=15] keep
setblock ~79 ~ ~19 light[level=15] keep
setblock ~79 ~ ~27 light[level=15] keep
setblock ~79 ~ ~35 light[level=15] keep
setblock ~79 ~ ~43 light[level=15] keep
setblock ~79 ~ ~51 light[level=15] keep
setblock ~79 ~ ~59 light[level=15] keep
setblock ~87 ~ ~-13 light[level=15] keep
setblock ~87 ~ ~-5 light[level=15] keep
setblock ~87 ~ ~3 light[level=15] keep
setblock ~87 ~ ~11 light[level=15] keep
setblock ~87 ~ ~19 light[level=15] keep
setblock ~87 ~ ~27 light[level=15] keep
setblock ~87 ~ ~35 light[level=15] keep
setblock ~87 ~ ~43 light[level=15] keep
setblock ~87 ~ ~51 light[level=15] keep
setblock ~87 ~ ~59 light[level=15] keep
kill @e[type=minecraft:item,distance=..150]
function granjas:respaldo_on
tellraw @a {"text":"[Fase 4] LISTA! Estacion central (norte), estatua en la plaza, salon de cofres (este) y bunker (escalera al sur de la plaza).","color":"green"}
function granjas:_rl_start
