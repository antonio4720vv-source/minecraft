function granjas:_rpaso
scoreboard players add #i rieles 1
scoreboard players remove #rem rieles 1
scoreboard players add #pasos rieles 1
execute if score #corner rieles matches 1 if score #seg rieles matches 1 run function granjas:_rl_trasesq
execute if score #rem rieles matches ..0 run function granjas:_rl_finseg
execute if score #hecho rieles matches 0 if score #pasos rieles matches ..23 at @s run function granjas:_rl_bucle
