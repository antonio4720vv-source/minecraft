$setblock ~$(fx) ~ ~$(fz) $(bed)
$setblock ~$(fx) ~1 ~$(fz) $(bed)
$setblock ~$(fx) ~2 ~$(fz) $(lamp)
$setblock ~$(r1x) ~1 ~$(r1z) powered_rail[shape=$(shape)]
$setblock ~$(r2x) ~1 ~$(r2z) powered_rail[shape=$(shape)]
$setblock ~$(bx) ~1 ~$(bz) $(bed)
$setblock ~$(bx) ~2 ~$(bz) stone_button[face=floor,facing=north]
$setblock ~$(ax) ~1 ~$(az) barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
$summon minecraft:text_display ~$(fx) ~3.5 ~$(fz) {billboard:"center",text:{text:"ESTACION - $(name)\nboton = salir",color:"gold",bold:1b},background:1073741824}
