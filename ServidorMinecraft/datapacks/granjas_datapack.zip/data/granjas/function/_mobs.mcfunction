tellraw @s {"text":"Construyendo granja de MOBS en el cielo (polvora, huesos, flechas)...","color":"yellow"}
fill ~-2 ~-1 ~-2 ~19 ~32 ~19 air
fill ~-2 ~-1 ~-2 ~19 ~-1 ~19 stone_bricks
fill ~-1 ~24 ~-1 ~18 ~30 ~18 stone_bricks hollow
fill ~ ~27 ~ ~17 ~27 ~17 stone_bricks
fill ~ ~27 ~2 ~17 ~27 ~2 spruce_trapdoor[open=true,facing=north,half=bottom]
fill ~ ~27 ~5 ~17 ~27 ~5 spruce_trapdoor[open=true,facing=north,half=bottom]
fill ~ ~27 ~8 ~17 ~27 ~8 spruce_trapdoor[open=true,facing=north,half=bottom]
fill ~ ~27 ~11 ~17 ~27 ~11 spruce_trapdoor[open=true,facing=north,half=bottom]
fill ~ ~27 ~14 ~17 ~27 ~14 spruce_trapdoor[open=true,facing=north,half=bottom]
fill ~ ~25 ~ ~ ~25 ~17 water
fill ~17 ~25 ~ ~17 ~25 ~17 water
fill ~ ~25 ~ ~17 ~25 ~ water
fill ~ ~25 ~17 ~17 ~25 ~17 water
fill ~7 ~ ~7 ~10 ~23 ~10 stone_bricks
fill ~8 ~1 ~8 ~9 ~24 ~9 air
fill ~8 ~ ~8 ~9 ~ ~8 hopper[facing=south]
fill ~8 ~ ~9 ~9 ~ ~9 hopper[facing=south]
fill ~8 ~ ~10 ~9 ~ ~10 barrel[facing=south]
setblock ~ ~31 ~ torch
setblock ~ ~31 ~4 torch
setblock ~ ~31 ~8 torch
setblock ~ ~31 ~12 torch
setblock ~ ~31 ~16 torch
setblock ~4 ~31 ~ torch
setblock ~4 ~31 ~4 torch
setblock ~4 ~31 ~8 torch
setblock ~4 ~31 ~12 torch
setblock ~4 ~31 ~16 torch
setblock ~8 ~31 ~ torch
setblock ~8 ~31 ~4 torch
setblock ~8 ~31 ~8 torch
setblock ~8 ~31 ~12 torch
setblock ~8 ~31 ~16 torch
setblock ~12 ~31 ~ torch
setblock ~12 ~31 ~4 torch
setblock ~12 ~31 ~8 torch
setblock ~12 ~31 ~12 torch
setblock ~12 ~31 ~16 torch
setblock ~16 ~31 ~ torch
setblock ~16 ~31 ~4 torch
setblock ~16 ~31 ~8 torch
setblock ~16 ~31 ~12 torch
setblock ~16 ~31 ~16 torch
setblock ~5 ~ ~12 torch
setblock ~12 ~ ~12 torch
setblock ~5 ~ ~5 torch
setblock ~12 ~ ~5 torch
setblock ~3 ~ ~9 torch
setblock ~14 ~ ~9 torch
summon minecraft:text_display ~8 ~2 ~12 {billboard:"center",text:{text:"GRANJA DE MOBS\nquedate aqui cerca (AFK)",color:"gold",bold:1b},background:1073741824}
summon minecraft:marker ~8 ~ ~10 {Tags:["go_mobs"]}
tellraw @s {"text":"Granja de mobs lista. Los mobs aparecen arriba en la oscuridad, caen 24 bloques y mueren solos. Quedate cerca de los cofres (lado sur): ahi llega la polvora, huesos, flechas e hilo.","color":"green"}
