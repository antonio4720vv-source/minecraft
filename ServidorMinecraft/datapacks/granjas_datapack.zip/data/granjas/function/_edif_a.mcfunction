tellraw @s {"text":"Construyendo EDIFICIO DE GRANJAS de 6 pisos...","color":"yellow"}
fill ~-8 ~ ~-2 ~22 ~24 ~29 air
fill ~23 ~ ~-2 ~53 ~24 ~29 air
fill ~-8 ~25 ~-2 ~22 ~49 ~29 air
fill ~23 ~25 ~-2 ~53 ~49 ~29 air
fill ~-8 ~50 ~-2 ~22 ~74 ~29 air
fill ~23 ~50 ~-2 ~53 ~74 ~29 air
fill ~-8 ~-1 ~-2 ~53 ~-1 ~29 stone_bricks
execute positioned ~3 ~0 ~4 run function granjas:_hornos
execute positioned ~19 ~0 ~4 run function granjas:_hornos
execute positioned ~35 ~0 ~4 run function granjas:_hornos
fill ~-1 ~-1 ~-1 ~25 ~-1 ~28 stone_bricks replace air
fill ~26 ~-1 ~-1 ~52 ~-1 ~28 stone_bricks replace air
fill ~-1 ~7 ~-1 ~25 ~7 ~28 stone_bricks
fill ~26 ~7 ~-1 ~52 ~7 ~28 stone_bricks
execute positioned ~3 ~8 ~5 run function granjas:_cana
execute positioned ~20 ~8 ~5 run function granjas:_cana
execute positioned ~37 ~8 ~5 run function granjas:_cana
execute positioned ~3 ~8 ~16 run function granjas:_sandia
execute positioned ~20 ~8 ~16 run function granjas:_sandia
execute positioned ~37 ~8 ~16 run function granjas:_comida
fill ~-1 ~7 ~-1 ~25 ~7 ~28 stone_bricks replace air
fill ~26 ~7 ~-1 ~52 ~7 ~28 stone_bricks replace air
fill ~-1 ~17 ~-1 ~25 ~17 ~28 stone_bricks
fill ~26 ~17 ~-1 ~52 ~17 ~28 stone_bricks
execute positioned ~3 ~18 ~1 run function granjas:_aldeanos
execute positioned ~29 ~18 ~1 run function granjas:_aldeanos
fill ~-1 ~17 ~-1 ~25 ~17 ~28 stone_bricks replace air
fill ~26 ~17 ~-1 ~52 ~17 ~28 stone_bricks replace air
fill ~-1 ~24 ~-1 ~25 ~24 ~28 stone_bricks
fill ~26 ~24 ~-1 ~52 ~24 ~28 stone_bricks
execute positioned ~4 ~25 ~4 run function granjas:_comercio
fill ~-1 ~24 ~-1 ~25 ~24 ~28 stone_bricks replace air
fill ~26 ~24 ~-1 ~52 ~24 ~28 stone_bricks replace air
fill ~-1 ~32 ~-1 ~25 ~32 ~28 glass
fill ~26 ~32 ~-1 ~52 ~32 ~28 glass
execute positioned ~4 ~33 ~3 run function granjas:_hierro
execute positioned ~30 ~33 ~3 run function granjas:_hierro
fill ~-1 ~32 ~-1 ~25 ~32 ~28 glass replace air
fill ~26 ~32 ~-1 ~52 ~32 ~28 glass replace air
fill ~-1 ~50 ~-1 ~25 ~50 ~28 stone_bricks
fill ~26 ~50 ~-1 ~52 ~50 ~28 stone_bricks
execute positioned ~3 ~51 ~2 run function granjas:_experiencia
fill ~-1 ~50 ~-1 ~25 ~50 ~28 stone_bricks replace air
fill ~26 ~50 ~-1 ~52 ~50 ~28 stone_bricks replace air
fill ~-1 ~72 ~-1 ~25 ~72 ~28 stone_bricks
fill ~26 ~72 ~-1 ~52 ~72 ~28 stone_bricks
