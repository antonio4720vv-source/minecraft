tellraw @a {"text":"Montanas, arboles, tren y golems guardianes...","color":"yellow"}
function granjas:_paisaje
function granjas:_arboles
function granjas:_tren
summon minecraft:iron_golem ~-10 ~ ~-10 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~10 ~ ~-10 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~-10 ~ ~10 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~10 ~ ~10 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~-38 ~ ~-33 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~38 ~ ~-33 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~-38 ~ ~33 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~38 ~ ~33 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~-55 ~ ~15 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~60 ~ ~15 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~ ~ ~-30 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
summon minecraft:iron_golem ~ ~ ~30 {PlayerCreated:1b,PersistenceRequired:1b,CustomName:"Guardian"}
