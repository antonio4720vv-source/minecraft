execute align xyz positioned ~0.5 ~ ~12.5 run function granjas:_portal_end
