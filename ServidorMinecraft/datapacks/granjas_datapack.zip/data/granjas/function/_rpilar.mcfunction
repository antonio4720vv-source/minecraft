$setblock ~ ~ ~ $(bed)
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:replaceable unless block ~ ~ ~ light run function granjas:_rpilar with storage granjas:riel p
