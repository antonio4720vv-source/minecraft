scoreboard players operation #c rieles = #ady rieles
scoreboard players add #c rieles 2
$execute if score #dy rieles matches ..-1 positioned ~$(dx) ~-$(ady) ~$(dz) run function granjas:_rand
$execute if score #dy rieles matches 1.. positioned ~$(dx) ~1 ~$(dz) run function granjas:_rand
