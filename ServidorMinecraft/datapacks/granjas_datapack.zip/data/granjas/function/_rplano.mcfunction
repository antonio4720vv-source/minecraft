execute if score #m rieles matches 0 run forceload add ~ ~
$execute if score #m rieles matches 0 run forceload remove ~$(fbx) ~$(fbz)
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:base_stone_overworld
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:dirt
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:leaves
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:logs
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:sand
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:terracotta
fill ~ ~1 ~ ~ ~3 ~ air replace gravel
fill ~ ~1 ~ ~ ~3 ~ air replace snow_block
fill ~ ~1 ~ ~ ~3 ~ air replace clay
fill ~ ~1 ~ ~ ~3 ~ air replace sandstone
fill ~ ~1 ~ ~ ~3 ~ air replace red_sandstone
fill ~ ~1 ~ ~ ~3 ~ air replace ice
fill ~ ~1 ~ ~ ~3 ~ air replace packed_ice
fill ~ ~1 ~ ~ ~3 ~ air replace calcite
fill ~ ~1 ~ ~ ~3 ~ air replace short_grass
fill ~ ~1 ~ ~ ~3 ~ air replace tall_grass
fill ~ ~1 ~ ~ ~3 ~ air replace fern
fill ~ ~1 ~ ~ ~3 ~ air replace large_fern
fill ~ ~1 ~ ~ ~3 ~ air replace #minecraft:flowers
fill ~ ~1 ~ ~ ~3 ~ air replace snow
fill ~ ~1 ~ ~ ~3 ~ air replace vine
fill ~ ~1 ~ ~ ~3 ~ air replace sugar_cane
fill ~ ~1 ~ ~ ~3 ~ air replace bamboo
fill ~ ~1 ~ ~ ~3 ~ air replace sweet_berry_bush
fill ~ ~1 ~ ~ ~3 ~ air replace dead_bush
fill ~ ~1 ~ ~ ~3 ~ air replace glow_lichen
$fill ~-$(ox) ~ ~-$(oz) ~$(ox) ~ ~$(oz) $(bed)
execute if score #m rieles matches 4 if score #corner rieles matches 0 run setblock ~ ~ ~ redstone_block
$execute if score #m rieles matches 4 if score #corner rieles matches 0 run setblock ~ ~1 ~ powered_rail[shape=$(pshape),powered=true]
$execute unless score #m rieles matches 4 run setblock ~ ~1 ~ rail[shape=$(shape)]
$execute if score #m rieles matches 4 if score #corner rieles matches 1 run setblock ~ ~1 ~ rail[shape=$(shape)]
execute if block ~ ~2 ~ air run setblock ~ ~2 ~ light[level=15]
$execute if block ~$(ox) ~1 ~$(oz) #minecraft:replaceable unless block ~$(ox) ~1 ~$(oz) light run setblock ~$(ox) ~1 ~$(oz) $(fence)
$execute if block ~-$(ox) ~1 ~-$(oz) #minecraft:replaceable unless block ~-$(ox) ~1 ~-$(oz) light run setblock ~-$(ox) ~1 ~-$(oz) $(fence)
$execute if score #m rieles matches 0 if block ~$(ox) ~1 ~$(oz) $(fence) run setblock ~$(ox) ~2 ~$(oz) $(lamp)
execute if score #m6 rieles matches 0 positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:replaceable unless block ~ ~ ~ light run function granjas:_rpilar with storage granjas:riel p
$tp @s ~$(dx) ~ ~$(dz)
