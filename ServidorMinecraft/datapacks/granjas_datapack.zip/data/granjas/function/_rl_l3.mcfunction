data modify storage granjas:riel l set value {tag:"granjas_f3",y:11,sep:12,bed:"polished_deepslate",fence:"dark_oak_fence",lamp:"soul_lantern",name:"LINEA AZUL"}
function granjas:_rl_ini with storage granjas:riel l
