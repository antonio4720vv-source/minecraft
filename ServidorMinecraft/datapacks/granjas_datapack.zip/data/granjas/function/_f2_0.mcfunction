execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run forceload add ~-2 ~-4 ~160 ~48
tellraw @a {"text":"[Fase 2] Preparando terreno de 160 x 50 bloques al ESTE y SUR. Tarda unos 30 segundos. No te alejes.","color":"gold"}
schedule function granjas:_f2_1 5s replace
