tellraw @s {"text":"Construyendo CABALLERIZA...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~25 ~11 ~23 air
fill ~-1 ~-1 ~-1 ~25 ~-1 ~23 grass_block
fill ~ ~-1 ~ ~23 ~-1 ~10 spruce_planks
fill ~ ~ ~ ~23 ~4 ~10 spruce_planks
fill ~1 ~ ~1 ~22 ~4 ~9 air
fill ~ ~ ~ ~ ~4 ~ stripped_spruce_log
fill ~ ~ ~10 ~ ~4 ~10 stripped_spruce_log
fill ~4 ~ ~ ~4 ~4 ~ stripped_spruce_log
fill ~4 ~ ~10 ~4 ~4 ~10 stripped_spruce_log
fill ~8 ~ ~ ~8 ~4 ~ stripped_spruce_log
fill ~8 ~ ~10 ~8 ~4 ~10 stripped_spruce_log
fill ~12 ~ ~ ~12 ~4 ~ stripped_spruce_log
fill ~12 ~ ~10 ~12 ~4 ~10 stripped_spruce_log
fill ~16 ~ ~ ~16 ~4 ~ stripped_spruce_log
fill ~16 ~ ~10 ~16 ~4 ~10 stripped_spruce_log
fill ~20 ~ ~ ~20 ~4 ~ stripped_spruce_log
fill ~20 ~ ~10 ~20 ~4 ~10 stripped_spruce_log
fill ~-1 ~5 ~-1 ~24 ~5 ~-1 spruce_stairs[facing=south]
fill ~-1 ~5 ~11 ~24 ~5 ~11 spruce_stairs[facing=north]
fill ~-1 ~6 ~ ~24 ~6 ~ spruce_stairs[facing=south]
fill ~-1 ~6 ~10 ~24 ~6 ~10 spruce_stairs[facing=north]
fill ~ ~6 ~1 ~ ~6 ~9 spruce_planks
fill ~23 ~6 ~1 ~23 ~6 ~9 spruce_planks
fill ~-1 ~7 ~1 ~24 ~7 ~1 spruce_stairs[facing=south]
fill ~-1 ~7 ~9 ~24 ~7 ~9 spruce_stairs[facing=north]
fill ~ ~7 ~2 ~ ~7 ~8 spruce_planks
fill ~23 ~7 ~2 ~23 ~7 ~8 spruce_planks
fill ~-1 ~8 ~2 ~24 ~8 ~2 spruce_stairs[facing=south]
fill ~-1 ~8 ~8 ~24 ~8 ~8 spruce_stairs[facing=north]
fill ~ ~8 ~3 ~ ~8 ~7 spruce_planks
fill ~23 ~8 ~3 ~23 ~8 ~7 spruce_planks
fill ~-1 ~9 ~3 ~24 ~9 ~3 spruce_stairs[facing=south]
fill ~-1 ~9 ~7 ~24 ~9 ~7 spruce_stairs[facing=north]
fill ~ ~9 ~4 ~ ~9 ~6 spruce_planks
fill ~23 ~9 ~4 ~23 ~9 ~6 spruce_planks
fill ~-1 ~10 ~4 ~24 ~10 ~4 spruce_stairs[facing=south]
fill ~-1 ~10 ~6 ~24 ~10 ~6 spruce_stairs[facing=north]
fill ~ ~10 ~5 ~ ~10 ~5 spruce_planks
fill ~23 ~10 ~5 ~23 ~10 ~5 spruce_planks
fill ~-1 ~10 ~4 ~24 ~10 ~6 spruce_slab[type=bottom]
fill ~ ~5 ~1 ~23 ~5 ~9 spruce_planks
fill ~1 ~ ~4 ~3 ~ ~4 oak_fence
setblock ~2 ~ ~4 oak_fence_gate[facing=south]
fill ~4 ~ ~1 ~4 ~ ~3 oak_fence
setblock ~1 ~ ~1 hay_block
setblock ~3 ~ ~1 water_cauldron[level=3]
summon minecraft:horse ~2 ~ ~2 {Tame:1b,PersistenceRequired:1b,Variant:5,equipment:{saddle:{id:"minecraft:saddle",count:1}}}
setblock ~2 ~3 ~2 lantern[hanging=true]
fill ~5 ~ ~4 ~7 ~ ~4 oak_fence
setblock ~6 ~ ~4 oak_fence_gate[facing=south]
fill ~8 ~ ~1 ~8 ~ ~3 oak_fence
setblock ~5 ~ ~1 hay_block
setblock ~7 ~ ~1 water_cauldron[level=3]
summon minecraft:horse ~6 ~ ~2 {Tame:1b,PersistenceRequired:1b,Variant:2,equipment:{saddle:{id:"minecraft:saddle",count:1}}}
setblock ~6 ~3 ~2 lantern[hanging=true]
fill ~9 ~ ~4 ~11 ~ ~4 oak_fence
setblock ~10 ~ ~4 oak_fence_gate[facing=south]
fill ~12 ~ ~1 ~12 ~ ~3 oak_fence
setblock ~9 ~ ~1 hay_block
setblock ~11 ~ ~1 water_cauldron[level=3]
summon minecraft:horse ~10 ~ ~2 {Tame:1b,PersistenceRequired:1b,Variant:6,equipment:{saddle:{id:"minecraft:saddle",count:1}}}
setblock ~10 ~3 ~2 lantern[hanging=true]
fill ~13 ~ ~4 ~15 ~ ~4 oak_fence
setblock ~14 ~ ~4 oak_fence_gate[facing=south]
fill ~16 ~ ~1 ~16 ~ ~3 oak_fence
setblock ~13 ~ ~1 hay_block
setblock ~15 ~ ~1 water_cauldron[level=3]
summon minecraft:horse ~14 ~ ~2 {Tame:1b,PersistenceRequired:1b,Variant:0,equipment:{saddle:{id:"minecraft:saddle",count:1}}}
setblock ~14 ~3 ~2 lantern[hanging=true]
fill ~17 ~ ~4 ~19 ~ ~4 oak_fence
setblock ~18 ~ ~4 oak_fence_gate[facing=south]
setblock ~17 ~ ~1 hay_block
setblock ~19 ~ ~1 water_cauldron[level=3]
summon minecraft:horse ~18 ~ ~2 {Tame:1b,PersistenceRequired:1b,Variant:1,equipment:{saddle:{id:"minecraft:saddle",count:1}}}
setblock ~18 ~3 ~2 lantern[hanging=true]
fill ~23 ~ ~5 ~23 ~2 ~8 air
fill ~23 ~ ~5 ~23 ~ ~8 oak_fence_gate[facing=east]
fill ~1 ~ ~9 ~3 ~1 ~9 barrel[facing=north]
setblock ~1 ~ ~9 barrel[facing=north]{Items:[{Slot:0b,id:"minecraft:hay_block",count:64},{Slot:1b,id:"minecraft:golden_carrot",count:64},{Slot:2b,id:"minecraft:lead",count:16},{Slot:3b,id:"minecraft:saddle",count:4}]}
setblock ~6 ~4 ~7 lantern[hanging=true]
setblock ~12 ~4 ~7 lantern[hanging=true]
setblock ~18 ~4 ~7 lantern[hanging=true]
fill ~ ~ ~12 ~23 ~ ~12 oak_fence
fill ~ ~ ~22 ~23 ~ ~22 oak_fence
fill ~ ~ ~12 ~ ~ ~22 oak_fence
fill ~23 ~ ~12 ~23 ~ ~22 oak_fence
setblock ~12 ~ ~12 oak_fence_gate[facing=south]
setblock ~ ~1 ~12 lantern
setblock ~23 ~1 ~12 lantern
setblock ~ ~1 ~22 lantern
setblock ~23 ~1 ~22 lantern
setblock ~12 ~1 ~22 lantern
summon minecraft:horse ~5 ~ ~17 {Tame:1b,PersistenceRequired:1b,Variant:1}
summon minecraft:horse ~11 ~ ~17 {Tame:1b,PersistenceRequired:1b,Variant:257}
summon minecraft:horse ~17 ~ ~17 {Tame:1b,PersistenceRequired:1b,Variant:1}
summon minecraft:donkey ~10 ~ ~19 {Tame:1b,PersistenceRequired:1b}
summon minecraft:text_display ~24 ~3 ~6 {billboard:"center",text:{text:"CABALLERIZA\n5 caballos ensillados",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Caballeriza lista: 5 caballos domados y ensillados, corral con 3 caballos y un burro, y un barril con heno, zanahorias doradas, riendas y sillas.","color":"green"}
