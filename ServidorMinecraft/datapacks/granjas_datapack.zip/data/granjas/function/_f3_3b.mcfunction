tellraw @a {"text":"[Fase 3] Montana natural...","color":"yellow"}
execute positioned ~35 ~ ~40 run function granjas:_montana_n
