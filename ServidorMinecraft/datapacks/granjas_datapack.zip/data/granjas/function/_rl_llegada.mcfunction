scoreboard players set #hecho rieles 1
data modify storage granjas:riel e set value {}
data modify storage granjas:riel e.bed set from storage granjas:riel p.bed
data modify storage granjas:riel e.lamp set from storage granjas:riel p.lamp
data modify storage granjas:riel e.name set from storage granjas:riel p.name
execute if score #seg rieles matches 0 run data modify storage granjas:riel e.shape set value "east_west"
execute if score #seg rieles matches 1 run data modify storage granjas:riel e.shape set value "north_south"
execute store result storage granjas:riel e.fx int 0 run scoreboard players get #edx rieles
execute store result storage granjas:riel e.fz int 0 run scoreboard players get #edz rieles
execute store result storage granjas:riel e.r1x int -1 run scoreboard players get #edx rieles
execute store result storage granjas:riel e.r1z int -1 run scoreboard players get #edz rieles
execute store result storage granjas:riel e.r2x int -2 run scoreboard players get #edx rieles
execute store result storage granjas:riel e.r2z int -2 run scoreboard players get #edz rieles
scoreboard players operation #t rieles = #eox rieles
scoreboard players operation #t rieles -= #edx rieles
execute store result storage granjas:riel e.bx int 1 run scoreboard players get #t rieles
scoreboard players operation #t rieles = #eoz rieles
scoreboard players operation #t rieles -= #edz rieles
execute store result storage granjas:riel e.bz int 1 run scoreboard players get #t rieles
scoreboard players operation #t rieles = #eox rieles
scoreboard players operation #t rieles *= #-1 rieles
scoreboard players operation #t rieles -= #edx rieles
execute store result storage granjas:riel e.ax int 1 run scoreboard players get #t rieles
scoreboard players operation #t rieles = #eoz rieles
scoreboard players operation #t rieles *= #-1 rieles
scoreboard players operation #t rieles -= #edz rieles
execute store result storage granjas:riel e.az int 1 run scoreboard players get #t rieles
function granjas:_rl_est with storage granjas:riel e
execute store result storage granjas:riel p.ady int 1 run scoreboard players get #ady rieles
execute unless score #ady rieles matches 0 run function granjas:_rl_andamio with storage granjas:riel p
scoreboard players operation #t rieles = #fdx rieles
execute if score #fdx rieles matches 0 run scoreboard players set #t rieles 0
execute if score #fdx rieles matches 0 run data modify storage granjas:riel e.shape set value "north_south"
execute unless score #fdx rieles matches 0 run data modify storage granjas:riel e.shape set value "east_west"
execute store result storage granjas:riel e.fx int -1 run scoreboard players get #fdx rieles
execute store result storage granjas:riel e.fz int -1 run scoreboard players get #fdz rieles
execute store result storage granjas:riel e.r1x int 0 run scoreboard players get #fdx rieles
execute store result storage granjas:riel e.r1z int 0 run scoreboard players get #fdz rieles
execute store result storage granjas:riel e.r2x int 1 run scoreboard players get #fdx rieles
execute store result storage granjas:riel e.r2z int 1 run scoreboard players get #fdz rieles
execute store result storage granjas:riel e.bx int 1 run scoreboard players get #fox rieles
execute store result storage granjas:riel e.bz int 1 run scoreboard players get #foz rieles
execute store result storage granjas:riel e.ax int -1 run scoreboard players get #fox rieles
execute store result storage granjas:riel e.az int -1 run scoreboard players get #foz rieles
data modify storage granjas:riel e.name set value "ESTACION CENTRAL"
execute as @e[type=minecraft:marker,tag=riel_s,limit=1] at @s run function granjas:_rl_est with storage granjas:riel e
kill @e[type=minecraft:marker,tag=riel_w]
kill @e[type=minecraft:marker,tag=riel_s]
tellraw @a [{"text":"[Ferrocarriles] Lista: ","color":"green"},{"storage":"granjas:riel","nbt":"p.name","color":"yellow"}]
scoreboard players add #linea rieles 1
schedule function granjas:_rl_sig 2t replace
