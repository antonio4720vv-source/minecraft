tellraw @s {"text":"Construyendo CASA EN EL ARBOL con ascensor...","color":"yellow"}
fill ~-10 ~-1 ~-10 ~10 ~19 ~10 air
fill ~-10 ~20 ~-10 ~10 ~33 ~10 air
fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 grass_block
fill ~-2 ~ ~-2 ~1 ~29 ~1 dark_oak_log
fill ~-3 ~-1 ~-3 ~-3 ~ ~-3 dark_oak_wood
setblock ~-4 ~-1 ~-4 dark_oak_wood
fill ~2 ~-1 ~-3 ~2 ~ ~-3 dark_oak_wood
setblock ~3 ~-1 ~-4 dark_oak_wood
fill ~-3 ~-1 ~2 ~-3 ~ ~2 dark_oak_wood
setblock ~-4 ~-1 ~3 dark_oak_wood
fill ~2 ~-1 ~2 ~2 ~ ~2 dark_oak_wood
setblock ~3 ~-1 ~3 dark_oak_wood
setblock ~-1 ~-1 ~-1 soul_sand
fill ~-1 ~ ~-1 ~-1 ~17 ~-1 bubble_column[drag=false]
fill ~-1 ~18 ~-1 ~-1 ~19 ~-1 air
fill ~-2 ~18 ~-1 ~-2 ~19 ~-1 air
setblock ~-2 ~ ~-1 oak_door[half=lower,facing=east,hinge=left]
setblock ~-2 ~1 ~-1 oak_door[half=upper,facing=east,hinge=left]
fill ~ ~ ~ ~ ~19 ~ ladder[facing=north]
fill ~1 ~ ~ ~1 ~1 ~ air
fill ~1 ~18 ~ ~1 ~19 ~ air
summon minecraft:text_display ~-4 ~3 ~-1 {billboard:"center",text:{text:"ASCENSOR (sube)",color:"aqua",bold:1b},background:1073741824}
summon minecraft:text_display ~3 ~3 ~ {billboard:"center",text:{text:"ESCALERA",color:"aqua",bold:1b},background:1073741824}
fill ~ ~17 ~-8 ~ ~17 ~-8 spruce_planks
fill ~-3 ~17 ~-7 ~3 ~17 ~-7 spruce_planks
fill ~-5 ~17 ~-6 ~5 ~17 ~-6 spruce_planks
fill ~-6 ~17 ~-5 ~6 ~17 ~-5 spruce_planks
fill ~-6 ~17 ~-4 ~6 ~17 ~-4 spruce_planks
fill ~-7 ~17 ~-3 ~7 ~17 ~-3 spruce_planks
fill ~-7 ~17 ~-2 ~7 ~17 ~-2 spruce_planks
fill ~-7 ~17 ~-1 ~7 ~17 ~-1 spruce_planks
fill ~-8 ~17 ~ ~8 ~17 ~ spruce_planks
fill ~-7 ~17 ~1 ~7 ~17 ~1 spruce_planks
fill ~-7 ~17 ~2 ~7 ~17 ~2 spruce_planks
fill ~-7 ~17 ~3 ~7 ~17 ~3 spruce_planks
fill ~-6 ~17 ~4 ~6 ~17 ~4 spruce_planks
fill ~-6 ~17 ~5 ~6 ~17 ~5 spruce_planks
fill ~-5 ~17 ~6 ~5 ~17 ~6 spruce_planks
fill ~-3 ~17 ~7 ~3 ~17 ~7 spruce_planks
fill ~ ~17 ~8 ~ ~17 ~8 spruce_planks
fill ~-2 ~17 ~-2 ~1 ~17 ~1 dark_oak_log
setblock ~-1 ~17 ~-1 bubble_column[drag=false]
setblock ~ ~17 ~ ladder[facing=north]
setblock ~ ~18 ~-8 oak_fence
setblock ~ ~18 ~-8 oak_fence
setblock ~-3 ~18 ~-7 oak_fence
setblock ~3 ~18 ~-7 oak_fence
setblock ~-5 ~18 ~-6 oak_fence
setblock ~5 ~18 ~-6 oak_fence
setblock ~-6 ~18 ~-5 oak_fence
setblock ~6 ~18 ~-5 oak_fence
setblock ~-6 ~18 ~-4 oak_fence
setblock ~6 ~18 ~-4 oak_fence
setblock ~-7 ~18 ~-3 oak_fence
setblock ~7 ~18 ~-3 oak_fence
setblock ~-7 ~18 ~-2 oak_fence
setblock ~7 ~18 ~-2 oak_fence
setblock ~-7 ~18 ~-1 oak_fence
setblock ~7 ~18 ~-1 oak_fence
setblock ~-8 ~18 ~ oak_fence
setblock ~8 ~18 ~ oak_fence
setblock ~-7 ~18 ~1 oak_fence
setblock ~7 ~18 ~1 oak_fence
setblock ~-7 ~18 ~2 oak_fence
setblock ~7 ~18 ~2 oak_fence
setblock ~-7 ~18 ~3 oak_fence
setblock ~7 ~18 ~3 oak_fence
setblock ~-6 ~18 ~4 oak_fence
setblock ~6 ~18 ~4 oak_fence
setblock ~-6 ~18 ~5 oak_fence
setblock ~6 ~18 ~5 oak_fence
setblock ~-5 ~18 ~6 oak_fence
setblock ~5 ~18 ~6 oak_fence
setblock ~-3 ~18 ~7 oak_fence
setblock ~3 ~18 ~7 oak_fence
setblock ~ ~18 ~8 oak_fence
setblock ~ ~18 ~8 oak_fence
fill ~-8 ~18 ~ ~-8 ~18 ~ oak_fence
fill ~-2 ~18 ~8 ~2 ~18 ~8 oak_fence
fill ~-2 ~18 ~-8 ~2 ~18 ~-8 oak_fence
fill ~-6 ~18 ~-6 ~5 ~21 ~5 oak_planks
fill ~-5 ~18 ~-5 ~4 ~21 ~4 air
fill ~-2 ~18 ~-2 ~1 ~21 ~1 dark_oak_log
fill ~-1 ~18 ~-1 ~-1 ~19 ~-1 air
fill ~-2 ~18 ~-1 ~-2 ~19 ~-1 air
fill ~ ~18 ~ ~ ~19 ~ ladder[facing=north]
fill ~1 ~18 ~ ~1 ~19 ~ air
fill ~-6 ~18 ~-6 ~-6 ~21 ~-6 stripped_oak_log
fill ~5 ~18 ~-6 ~5 ~21 ~-6 stripped_oak_log
fill ~-6 ~18 ~5 ~-6 ~21 ~5 stripped_oak_log
fill ~5 ~18 ~5 ~5 ~21 ~5 stripped_oak_log
fill ~-6 ~22 ~-6 ~5 ~22 ~5 spruce_slab[type=bottom]
fill ~-4 ~19 ~-6 ~-4 ~20 ~-6 glass_pane[east=true,west=true]
fill ~-4 ~19 ~5 ~-4 ~20 ~5 glass_pane[east=true,west=true]
fill ~-3 ~19 ~-6 ~-3 ~20 ~-6 glass_pane[east=true,west=true]
fill ~-3 ~19 ~5 ~-3 ~20 ~5 glass_pane[east=true,west=true]
fill ~2 ~19 ~-6 ~2 ~20 ~-6 glass_pane[east=true,west=true]
fill ~2 ~19 ~5 ~2 ~20 ~5 glass_pane[east=true,west=true]
fill ~3 ~19 ~-6 ~3 ~20 ~-6 glass_pane[east=true,west=true]
fill ~3 ~19 ~5 ~3 ~20 ~5 glass_pane[east=true,west=true]
fill ~-6 ~19 ~-4 ~-6 ~20 ~-4 glass_pane[north=true,south=true]
fill ~5 ~19 ~-4 ~5 ~20 ~-4 glass_pane[north=true,south=true]
fill ~-6 ~19 ~-3 ~-6 ~20 ~-3 glass_pane[north=true,south=true]
fill ~5 ~19 ~-3 ~5 ~20 ~-3 glass_pane[north=true,south=true]
fill ~-6 ~19 ~2 ~-6 ~20 ~2 glass_pane[north=true,south=true]
fill ~5 ~19 ~2 ~5 ~20 ~2 glass_pane[north=true,south=true]
fill ~-6 ~19 ~3 ~-6 ~20 ~3 glass_pane[north=true,south=true]
fill ~5 ~19 ~3 ~5 ~20 ~3 glass_pane[north=true,south=true]
setblock ~-1 ~18 ~5 oak_door[half=lower,facing=north,hinge=left]
setblock ~-1 ~19 ~5 oak_door[half=upper,facing=north,hinge=left]
setblock ~-4 ~18 ~-3 lime_bed[facing=north,part=foot]
setblock ~-4 ~18 ~-4 lime_bed[facing=north,part=head]
setblock ~-3 ~18 ~-3 lime_bed[facing=north,part=foot]
setblock ~-3 ~18 ~-4 lime_bed[facing=north,part=head]
fill ~3 ~18 ~-5 ~4 ~19 ~-5 barrel[facing=south]
setblock ~4 ~18 ~-3 crafting_table
setblock ~4 ~18 ~-2 furnace[facing=west]
fill ~-4 ~18 ~1 ~-3 ~18 ~3 green_carpet
setblock ~-4 ~21 ~ lantern[hanging=true]
setblock ~3 ~21 ~2 lantern[hanging=true]
setblock ~3 ~21 ~-3 lantern[hanging=true]
fill ~-7 ~23 ~-4 ~7 ~23 ~3 oak_leaves[persistent=true] replace air
fill ~-4 ~23 ~-7 ~3 ~23 ~7 oak_leaves[persistent=true] replace air
fill ~-5 ~23 ~-5 ~5 ~23 ~5 oak_leaves[persistent=true] replace air
fill ~-8 ~24 ~-4 ~8 ~24 ~4 oak_leaves[persistent=true] replace air
fill ~-4 ~24 ~-8 ~4 ~24 ~8 oak_leaves[persistent=true] replace air
fill ~-6 ~24 ~-6 ~6 ~24 ~6 oak_leaves[persistent=true] replace air
fill ~-8 ~25 ~-4 ~8 ~25 ~4 oak_leaves[persistent=true] replace air
fill ~-4 ~25 ~-8 ~4 ~25 ~8 oak_leaves[persistent=true] replace air
fill ~-6 ~25 ~-6 ~6 ~25 ~6 oak_leaves[persistent=true] replace air
fill ~-8 ~26 ~-4 ~8 ~26 ~4 oak_leaves[persistent=true] replace air
fill ~-4 ~26 ~-8 ~4 ~26 ~8 oak_leaves[persistent=true] replace air
fill ~-6 ~26 ~-6 ~6 ~26 ~6 oak_leaves[persistent=true] replace air
fill ~-7 ~27 ~-4 ~7 ~27 ~3 oak_leaves[persistent=true] replace air
fill ~-4 ~27 ~-7 ~3 ~27 ~7 oak_leaves[persistent=true] replace air
fill ~-5 ~27 ~-5 ~5 ~27 ~5 oak_leaves[persistent=true] replace air
fill ~-6 ~28 ~-3 ~6 ~28 ~3 oak_leaves[persistent=true] replace air
fill ~-3 ~28 ~-6 ~3 ~28 ~6 oak_leaves[persistent=true] replace air
fill ~-4 ~28 ~-4 ~4 ~28 ~4 oak_leaves[persistent=true] replace air
fill ~-5 ~29 ~-3 ~5 ~29 ~2 oak_leaves[persistent=true] replace air
fill ~-3 ~29 ~-5 ~2 ~29 ~5 oak_leaves[persistent=true] replace air
fill ~-3 ~29 ~-3 ~3 ~29 ~3 oak_leaves[persistent=true] replace air
fill ~-4 ~30 ~-2 ~4 ~30 ~2 oak_leaves[persistent=true] replace air
fill ~-2 ~30 ~-4 ~2 ~30 ~4 oak_leaves[persistent=true] replace air
fill ~-3 ~30 ~-3 ~3 ~30 ~3 oak_leaves[persistent=true] replace air
fill ~-2 ~31 ~-1 ~2 ~31 ~1 oak_leaves[persistent=true] replace air
fill ~-1 ~31 ~-2 ~1 ~31 ~2 oak_leaves[persistent=true] replace air
fill ~-1 ~31 ~-1 ~1 ~31 ~1 oak_leaves[persistent=true] replace air
fill ~-6 ~15 ~-1 ~6 ~15 ~ oak_leaves[persistent=true] replace air
fill ~-1 ~15 ~-6 ~ ~15 ~6 oak_leaves[persistent=true] replace air
fill ~-7 ~16 ~-1 ~7 ~16 ~ oak_leaves[persistent=true] replace air
fill ~-1 ~16 ~-7 ~ ~16 ~7 oak_leaves[persistent=true] replace air
fill ~-1 ~ ~-1 ~-1 ~17 ~-1 bubble_column[drag=false]
setblock ~3 ~ ~3 lantern
setblock ~-4 ~ ~-4 lantern
setblock ~3 ~ ~-4 lantern
setblock ~-4 ~ ~3 lantern
summon minecraft:text_display ~ ~2 ~-4 {billboard:"center",text:{text:"CASA EN EL ARBOL",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Casa en el arbol lista: entra por la puerta del lado oeste del tronco y la columna de agua te sube. Para bajar usa la escalera de mano (puerta del lado este).","color":"green"}
