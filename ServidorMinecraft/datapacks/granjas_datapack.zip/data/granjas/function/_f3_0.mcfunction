execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run forceload add ~-2 ~-4 ~150 ~74
tellraw @a {"text":"[Fase 3] Preparando terreno de 150 x 78 bloques al ESTE y SUR. Tarda unos 40 segundos. No te alejes.","color":"gold"}
schedule function granjas:_f3_1 5s replace
