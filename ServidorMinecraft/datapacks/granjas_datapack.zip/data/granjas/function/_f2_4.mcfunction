execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run function granjas:_f2_4b
schedule function granjas:_f2_5 4s replace
