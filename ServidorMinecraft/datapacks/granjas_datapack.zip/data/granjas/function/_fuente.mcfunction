tellraw @s {"text":"Construyendo FUENTE con faro en el centro...","color":"yellow"}
fill ~-10 ~-1 ~-10 ~10 ~11 ~10 air
fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 polished_andesite
fill ~ ~-1 ~-9 ~ ~ ~-9 stone_bricks
fill ~-4 ~-1 ~-8 ~4 ~ ~-8 stone_bricks
fill ~-5 ~-1 ~-7 ~5 ~ ~-7 stone_bricks
fill ~-6 ~-1 ~-6 ~6 ~ ~-6 stone_bricks
fill ~-7 ~-1 ~-5 ~7 ~ ~-5 stone_bricks
fill ~-8 ~-1 ~-4 ~8 ~ ~-4 stone_bricks
fill ~-8 ~-1 ~-3 ~8 ~ ~-3 stone_bricks
fill ~-8 ~-1 ~-2 ~8 ~ ~-2 stone_bricks
fill ~-8 ~-1 ~-1 ~8 ~ ~-1 stone_bricks
fill ~-9 ~-1 ~ ~9 ~ ~ stone_bricks
fill ~-8 ~-1 ~1 ~8 ~ ~1 stone_bricks
fill ~-8 ~-1 ~2 ~8 ~ ~2 stone_bricks
fill ~-8 ~-1 ~3 ~8 ~ ~3 stone_bricks
fill ~-8 ~-1 ~4 ~8 ~ ~4 stone_bricks
fill ~-7 ~-1 ~5 ~7 ~ ~5 stone_bricks
fill ~-6 ~-1 ~6 ~6 ~ ~6 stone_bricks
fill ~-5 ~-1 ~7 ~5 ~ ~7 stone_bricks
fill ~-4 ~-1 ~8 ~4 ~ ~8 stone_bricks
fill ~ ~-1 ~9 ~ ~ ~9 stone_bricks
fill ~ ~ ~-8 ~ ~ ~-8 water
fill ~ ~-1 ~-8 ~ ~-1 ~-8 prismarine_bricks
fill ~-3 ~ ~-7 ~3 ~ ~-7 water
fill ~-3 ~-1 ~-7 ~3 ~-1 ~-7 prismarine_bricks
fill ~-5 ~ ~-6 ~5 ~ ~-6 water
fill ~-5 ~-1 ~-6 ~5 ~-1 ~-6 prismarine_bricks
fill ~-6 ~ ~-5 ~6 ~ ~-5 water
fill ~-6 ~-1 ~-5 ~6 ~-1 ~-5 prismarine_bricks
fill ~-6 ~ ~-4 ~6 ~ ~-4 water
fill ~-6 ~-1 ~-4 ~6 ~-1 ~-4 prismarine_bricks
fill ~-7 ~ ~-3 ~7 ~ ~-3 water
fill ~-7 ~-1 ~-3 ~7 ~-1 ~-3 prismarine_bricks
fill ~-7 ~ ~-2 ~7 ~ ~-2 water
fill ~-7 ~-1 ~-2 ~7 ~-1 ~-2 prismarine_bricks
fill ~-7 ~ ~-1 ~7 ~ ~-1 water
fill ~-7 ~-1 ~-1 ~7 ~-1 ~-1 prismarine_bricks
fill ~-8 ~ ~ ~8 ~ ~ water
fill ~-8 ~-1 ~ ~8 ~-1 ~ prismarine_bricks
fill ~-7 ~ ~1 ~7 ~ ~1 water
fill ~-7 ~-1 ~1 ~7 ~-1 ~1 prismarine_bricks
fill ~-7 ~ ~2 ~7 ~ ~2 water
fill ~-7 ~-1 ~2 ~7 ~-1 ~2 prismarine_bricks
fill ~-7 ~ ~3 ~7 ~ ~3 water
fill ~-7 ~-1 ~3 ~7 ~-1 ~3 prismarine_bricks
fill ~-6 ~ ~4 ~6 ~ ~4 water
fill ~-6 ~-1 ~4 ~6 ~-1 ~4 prismarine_bricks
fill ~-6 ~ ~5 ~6 ~ ~5 water
fill ~-6 ~-1 ~5 ~6 ~-1 ~5 prismarine_bricks
fill ~-5 ~ ~6 ~5 ~ ~6 water
fill ~-5 ~-1 ~6 ~5 ~-1 ~6 prismarine_bricks
fill ~-3 ~ ~7 ~3 ~ ~7 water
fill ~-3 ~-1 ~7 ~3 ~-1 ~7 prismarine_bricks
fill ~ ~ ~8 ~ ~ ~8 water
fill ~ ~-1 ~8 ~ ~-1 ~8 prismarine_bricks
setblock ~-5 ~-1 ~ sea_lantern
setblock ~5 ~-1 ~ sea_lantern
setblock ~ ~-1 ~-5 sea_lantern
setblock ~ ~-1 ~5 sea_lantern
setblock ~-4 ~-1 ~-4 sea_lantern
setblock ~4 ~-1 ~-4 sea_lantern
setblock ~-4 ~-1 ~4 sea_lantern
setblock ~4 ~-1 ~4 sea_lantern
fill ~-1 ~ ~-1 ~1 ~4 ~1 quartz_pillar
fill ~-1 ~5 ~-1 ~1 ~5 ~1 iron_block
setblock ~ ~6 ~ beacon
setblock ~-2 ~4 ~ water
setblock ~2 ~4 ~ water
setblock ~ ~4 ~-2 water
setblock ~ ~4 ~2 water
fill ~-2 ~ ~-2 ~-2 ~1 ~-2 quartz_block
setblock ~-2 ~2 ~-2 end_rod[facing=up]
fill ~2 ~ ~-2 ~2 ~1 ~-2 quartz_block
setblock ~2 ~2 ~-2 end_rod[facing=up]
fill ~-2 ~ ~2 ~-2 ~1 ~2 quartz_block
setblock ~-2 ~2 ~2 end_rod[facing=up]
fill ~2 ~ ~2 ~2 ~1 ~2 quartz_block
setblock ~2 ~2 ~2 end_rod[facing=up]
summon minecraft:text_display ~ ~9 ~ {billboard:"center",text:{text:"PLAZA CENTRAL",color:"aqua",bold:1b},background:1073741824}
tellraw @s {"text":"Fuente con faro lista.","color":"green"}
