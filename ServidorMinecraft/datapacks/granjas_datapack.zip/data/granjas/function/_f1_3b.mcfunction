tellraw @a {"text":"[Fase 1] Torre de hierro: planta baja y pisos 1-2...","color":"yellow"}
fill ~7 ~-1 ~3 ~26 ~2 ~22 stone_bricks
fill ~13 ~ ~9 ~20 ~2 ~16 air
fill ~8 ~ ~12 ~12 ~1 ~13 air
fill ~16 ~2 ~12 ~17 ~1 ~13 hopper[facing=down]
fill ~16 ~ ~12 ~17 ~ ~13 barrel[facing=up]
setblock ~14 ~-1 ~10 glowstone
setblock ~19 ~-1 ~15 glowstone
setblock ~14 ~-1 ~15 glowstone
setblock ~19 ~-1 ~10 glowstone
setblock ~10 ~-1 ~12 glowstone
setblock ~7 ~ ~12 iron_door[half=lower,facing=east,hinge=left]
setblock ~7 ~1 ~12 iron_door[half=upper,facing=east,hinge=left]
setblock ~6 ~1 ~13 stone_button[face=wall,facing=west]
setblock ~8 ~1 ~13 stone_button[face=wall,facing=east]
summon minecraft:marker ~16 ~ ~12 {Tags:["go_hierro","f1"]}
summon minecraft:marker ~17 ~ ~12 {Tags:["go_hierro","f1"]}
summon minecraft:marker ~16 ~ ~13 {Tags:["go_hierro","f1"]}
summon minecraft:marker ~17 ~ ~13 {Tags:["go_hierro","f1"]}
summon minecraft:marker ~16 ~ ~12 {Tags:["go_hierro","f1"]}
summon minecraft:text_display ~5 ~3 ~12 {billboard:"center",text:{text:"TORRE DE HIERRO\n5 granjas - barriles adentro",color:"gold",bold:1b},background:1073741824}
fill ~7 ~3 ~3 ~26 ~3 ~22 stone_bricks
fill ~16 ~3 ~12 ~17 ~3 ~13 soul_campfire[lit=true]
fill ~8 ~4 ~4 ~25 ~12 ~21 air
fill ~7 ~4 ~3 ~26 ~4 ~3 stone_bricks
fill ~7 ~4 ~22 ~26 ~4 ~22 stone_bricks
fill ~7 ~4 ~3 ~7 ~4 ~22 stone_bricks
fill ~26 ~4 ~3 ~26 ~4 ~22 stone_bricks
fill ~7 ~5 ~3 ~26 ~12 ~3 glass
fill ~7 ~5 ~22 ~26 ~12 ~22 glass
fill ~7 ~5 ~3 ~7 ~12 ~22 glass
fill ~26 ~5 ~3 ~26 ~12 ~22 glass
fill ~7 ~4 ~3 ~7 ~12 ~3 chiseled_stone_bricks
fill ~7 ~4 ~22 ~7 ~12 ~22 chiseled_stone_bricks
fill ~13 ~4 ~3 ~13 ~12 ~3 chiseled_stone_bricks
fill ~13 ~4 ~22 ~13 ~12 ~22 chiseled_stone_bricks
fill ~19 ~4 ~3 ~19 ~12 ~3 chiseled_stone_bricks
fill ~19 ~4 ~22 ~19 ~12 ~22 chiseled_stone_bricks
fill ~25 ~4 ~3 ~25 ~12 ~3 chiseled_stone_bricks
fill ~25 ~4 ~22 ~25 ~12 ~22 chiseled_stone_bricks
fill ~8 ~4 ~4 ~25 ~4 ~21 smooth_stone
fill ~16 ~4 ~4 ~17 ~4 ~21 air
fill ~8 ~5 ~4 ~8 ~5 ~21 water
fill ~25 ~5 ~4 ~25 ~5 ~21 water
fill ~16 ~4 ~4 ~17 ~4 ~4 water
fill ~16 ~4 ~21 ~17 ~4 ~21 water
setblock ~10 ~7 ~6 light[level=15]
setblock ~10 ~7 ~10 light[level=15]
setblock ~10 ~7 ~15 light[level=15]
setblock ~10 ~7 ~19 light[level=15]
setblock ~13 ~7 ~6 light[level=15]
setblock ~13 ~7 ~10 light[level=15]
setblock ~13 ~7 ~15 light[level=15]
setblock ~13 ~7 ~19 light[level=15]
setblock ~21 ~7 ~6 light[level=15]
setblock ~21 ~7 ~10 light[level=15]
setblock ~21 ~7 ~15 light[level=15]
setblock ~21 ~7 ~19 light[level=15]
setblock ~24 ~7 ~6 light[level=15]
setblock ~24 ~7 ~10 light[level=15]
setblock ~24 ~7 ~15 light[level=15]
setblock ~24 ~7 ~19 light[level=15]
fill ~19 ~9 ~9 ~24 ~9 ~18 smooth_stone
fill ~19 ~10 ~9 ~24 ~11 ~18 glass
fill ~20 ~10 ~10 ~23 ~11 ~15 air
fill ~20 ~10 ~17 ~23 ~11 ~17 air
fill ~19 ~12 ~9 ~24 ~12 ~18 glass
fill ~20 ~11 ~16 ~23 ~11 ~16 air
setblock ~20 ~10 ~14 red_bed[facing=south,part=foot]
setblock ~20 ~10 ~15 red_bed[facing=south,part=head]
setblock ~21 ~10 ~14 red_bed[facing=south,part=foot]
setblock ~21 ~10 ~15 red_bed[facing=south,part=head]
setblock ~22 ~10 ~14 red_bed[facing=south,part=foot]
setblock ~22 ~10 ~15 red_bed[facing=south,part=head]
summon minecraft:villager ~20 ~10 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~22 ~10 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~23 ~10 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:zombie ~21 ~10 ~17 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
fill ~7 ~13 ~3 ~26 ~13 ~22 stone_bricks
fill ~16 ~13 ~12 ~17 ~13 ~13 air
fill ~8 ~14 ~4 ~25 ~22 ~21 air
fill ~7 ~14 ~3 ~26 ~14 ~3 stone_bricks
fill ~7 ~14 ~22 ~26 ~14 ~22 stone_bricks
fill ~7 ~14 ~3 ~7 ~14 ~22 stone_bricks
fill ~26 ~14 ~3 ~26 ~14 ~22 stone_bricks
fill ~7 ~15 ~3 ~26 ~22 ~3 glass
fill ~7 ~15 ~22 ~26 ~22 ~22 glass
fill ~7 ~15 ~3 ~7 ~22 ~22 glass
fill ~26 ~15 ~3 ~26 ~22 ~22 glass
fill ~7 ~14 ~3 ~7 ~22 ~3 chiseled_stone_bricks
fill ~7 ~14 ~22 ~7 ~22 ~22 chiseled_stone_bricks
fill ~13 ~14 ~3 ~13 ~22 ~3 chiseled_stone_bricks
fill ~13 ~14 ~22 ~13 ~22 ~22 chiseled_stone_bricks
fill ~19 ~14 ~3 ~19 ~22 ~3 chiseled_stone_bricks
fill ~19 ~14 ~22 ~19 ~22 ~22 chiseled_stone_bricks
fill ~25 ~14 ~3 ~25 ~22 ~3 chiseled_stone_bricks
fill ~25 ~14 ~22 ~25 ~22 ~22 chiseled_stone_bricks
fill ~8 ~14 ~4 ~25 ~14 ~21 smooth_stone
fill ~16 ~14 ~4 ~17 ~14 ~21 air
fill ~8 ~15 ~4 ~8 ~15 ~21 water
fill ~25 ~15 ~4 ~25 ~15 ~21 water
fill ~16 ~14 ~4 ~17 ~14 ~4 water
fill ~16 ~14 ~21 ~17 ~14 ~21 water
setblock ~10 ~17 ~6 light[level=15]
setblock ~10 ~17 ~10 light[level=15]
setblock ~10 ~17 ~15 light[level=15]
setblock ~10 ~17 ~19 light[level=15]
setblock ~13 ~17 ~6 light[level=15]
setblock ~13 ~17 ~10 light[level=15]
setblock ~13 ~17 ~15 light[level=15]
setblock ~13 ~17 ~19 light[level=15]
setblock ~21 ~17 ~6 light[level=15]
setblock ~21 ~17 ~10 light[level=15]
setblock ~21 ~17 ~15 light[level=15]
setblock ~21 ~17 ~19 light[level=15]
setblock ~24 ~17 ~6 light[level=15]
setblock ~24 ~17 ~10 light[level=15]
setblock ~24 ~17 ~15 light[level=15]
setblock ~24 ~17 ~19 light[level=15]
fill ~19 ~19 ~9 ~24 ~19 ~18 smooth_stone
fill ~19 ~20 ~9 ~24 ~21 ~18 glass
fill ~20 ~20 ~10 ~23 ~21 ~15 air
fill ~20 ~20 ~17 ~23 ~21 ~17 air
fill ~19 ~22 ~9 ~24 ~22 ~18 glass
fill ~20 ~21 ~16 ~23 ~21 ~16 air
setblock ~20 ~20 ~14 red_bed[facing=south,part=foot]
setblock ~20 ~20 ~15 red_bed[facing=south,part=head]
setblock ~21 ~20 ~14 red_bed[facing=south,part=foot]
setblock ~21 ~20 ~15 red_bed[facing=south,part=head]
setblock ~22 ~20 ~14 red_bed[facing=south,part=foot]
setblock ~22 ~20 ~15 red_bed[facing=south,part=head]
summon minecraft:villager ~20 ~20 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~22 ~20 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:villager ~23 ~20 ~11 {PersistenceRequired:1b,CustomName:"Trabajador del hierro"}
summon minecraft:zombie ~21 ~20 ~17 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
