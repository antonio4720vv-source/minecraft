fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:base_stone_overworld
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:dirt
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:leaves
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:logs
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:sand
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:terracotta
fill ~ ~1 ~ ~ ~4 ~ air replace gravel
fill ~ ~1 ~ ~ ~4 ~ air replace snow_block
fill ~ ~1 ~ ~ ~4 ~ air replace clay
fill ~ ~1 ~ ~ ~4 ~ air replace sandstone
fill ~ ~1 ~ ~ ~4 ~ air replace red_sandstone
fill ~ ~1 ~ ~ ~4 ~ air replace ice
fill ~ ~1 ~ ~ ~4 ~ air replace packed_ice
fill ~ ~1 ~ ~ ~4 ~ air replace calcite
fill ~ ~1 ~ ~ ~4 ~ air replace short_grass
fill ~ ~1 ~ ~ ~4 ~ air replace tall_grass
fill ~ ~1 ~ ~ ~4 ~ air replace fern
fill ~ ~1 ~ ~ ~4 ~ air replace large_fern
fill ~ ~1 ~ ~ ~4 ~ air replace #minecraft:flowers
fill ~ ~1 ~ ~ ~4 ~ air replace snow
fill ~ ~1 ~ ~ ~4 ~ air replace vine
fill ~ ~1 ~ ~ ~4 ~ air replace sugar_cane
fill ~ ~1 ~ ~ ~4 ~ air replace bamboo
fill ~ ~1 ~ ~ ~4 ~ air replace sweet_berry_bush
fill ~ ~1 ~ ~ ~4 ~ air replace dead_bush
fill ~ ~1 ~ ~ ~4 ~ air replace glow_lichen
$fill ~-$(ox) ~ ~-$(oz) ~$(ox) ~ ~$(oz) $(bed)
$setblock ~ ~1 ~ rail[shape=$(up)]
execute if block ~ ~3 ~ air run setblock ~ ~3 ~ light[level=15]
$execute if block ~$(ox) ~1 ~$(oz) #minecraft:replaceable unless block ~$(ox) ~1 ~$(oz) light run setblock ~$(ox) ~1 ~$(oz) $(fence)
$execute if block ~-$(ox) ~1 ~-$(oz) #minecraft:replaceable unless block ~-$(ox) ~1 ~-$(oz) light run setblock ~-$(ox) ~1 ~-$(oz) $(fence)
$tp @s ~$(dx) ~1 ~$(dz)
scoreboard players remove #dy rieles 1
scoreboard players remove #ady rieles 1
