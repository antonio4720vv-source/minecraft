data modify storage granjas:riel l set value {tag:"granjas_f1",y:3,sep:6,bed:"red_nether_bricks",fence:"nether_brick_fence",lamp:"lantern",name:"LINEA ROJA"}
function granjas:_rl_ini with storage granjas:riel l
