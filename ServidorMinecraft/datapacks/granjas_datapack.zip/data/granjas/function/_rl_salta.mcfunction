$tellraw @a {"text":"[Ferrocarriles] No encuentro $(tag) (esa fase no esta construida o esta muy lejos y descargada): se salta.","color":"red"}
scoreboard players add #linea rieles 1
schedule function granjas:_rl_sig 2t replace
