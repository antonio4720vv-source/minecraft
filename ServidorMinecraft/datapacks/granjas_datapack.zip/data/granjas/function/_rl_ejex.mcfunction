scoreboard players set #seg rieles 0
scoreboard players operation #rem rieles = #remx rieles
scoreboard players set #ult rieles 0
execute if score #remz rieles matches 0 run scoreboard players set #ult rieles 1
scoreboard players operation #edx rieles = #sx rieles
scoreboard players set #edz rieles 0
scoreboard players set #eox rieles 0
scoreboard players set #eoz rieles 1
data modify storage granjas:riel p merge value {shape:"east_west",pshape:"east_west"}
execute if score #sx rieles matches 1 run data modify storage granjas:riel p merge value {up:"ascending_east",down:"ascending_west"}
execute if score #sx rieles matches -1 run data modify storage granjas:riel p merge value {up:"ascending_west",down:"ascending_east"}
execute store result storage granjas:riel p.dx int 1 run scoreboard players get #edx rieles
execute store result storage granjas:riel p.dz int 1 run scoreboard players get #edz rieles
execute store result storage granjas:riel p.ox int 1 run scoreboard players get #eox rieles
execute store result storage granjas:riel p.oz int 1 run scoreboard players get #eoz rieles
execute store result storage granjas:riel p.fbx int -32 run scoreboard players get #edx rieles
execute store result storage granjas:riel p.fbz int -32 run scoreboard players get #edz rieles
