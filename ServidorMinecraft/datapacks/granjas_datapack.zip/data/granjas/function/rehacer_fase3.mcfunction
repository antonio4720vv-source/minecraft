execute unless entity @e[type=minecraft:marker,tag=granjas_f3,limit=1] run tellraw @s {"text":"No encuentro la Fase 3. Usa /function granjas:fase3 donde la quieras.","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run function granjas:_f3_0
