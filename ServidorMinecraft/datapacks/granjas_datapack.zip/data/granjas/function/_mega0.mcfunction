forceload add ~-115 ~-150 ~115 ~-18
forceload add ~-115 ~-17 ~115 ~115
tellraw @a {"text":"MEGABASE v7: borrando y preparando el terreno (230 x 265 bloques). Tarda como 1 minuto y el servidor se puede trabar. NO te vayas lejos.","color":"gold"}
schedule function granjas:_mega1 8s replace
