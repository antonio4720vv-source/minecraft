execute align xyz positioned ~1.5 ~ ~-7.5 run function granjas:_hierro_arreglar
