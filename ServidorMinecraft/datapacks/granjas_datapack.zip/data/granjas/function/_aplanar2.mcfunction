execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] run function granjas:_aplanar3
