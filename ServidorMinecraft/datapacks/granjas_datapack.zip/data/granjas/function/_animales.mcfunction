tellraw @s {"text":"Construyendo GRANJA DE ANIMALES...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~21 ~5 ~22 air
fill ~-1 ~-1 ~-1 ~21 ~-1 ~22 grass_block
fill ~10 ~-1 ~-1 ~10 ~-1 ~22 dirt_path
fill ~-1 ~-1 ~10 ~21 ~-1 ~10 dirt_path
fill ~ ~ ~ ~9 ~ ~ oak_fence
fill ~ ~ ~9 ~9 ~ ~9 oak_fence
fill ~ ~ ~ ~ ~ ~9 oak_fence
fill ~9 ~ ~ ~9 ~ ~9 oak_fence
setblock ~9 ~ ~4 oak_fence_gate[facing=east]
setblock ~ ~1 ~ lantern
setblock ~9 ~1 ~ lantern
setblock ~ ~1 ~9 lantern
setblock ~9 ~1 ~9 lantern
setblock ~1 ~ ~1 hay_block
setblock ~8 ~ ~8 water_cauldron[level=3]
summon minecraft:cow ~3 ~ ~3 {PersistenceRequired:1b}
summon minecraft:cow ~4 ~ ~3 {PersistenceRequired:1b}
summon minecraft:cow ~5 ~ ~3 {PersistenceRequired:1b}
summon minecraft:cow ~3 ~ ~4 {PersistenceRequired:1b}
summon minecraft:text_display ~4 ~3 ~4 {billboard:"center",text:{text:"VACAS",color:"gold",bold:1b},background:1073741824}
fill ~11 ~ ~ ~20 ~ ~ oak_fence
fill ~11 ~ ~9 ~20 ~ ~9 oak_fence
fill ~11 ~ ~ ~11 ~ ~9 oak_fence
fill ~20 ~ ~ ~20 ~ ~9 oak_fence
setblock ~11 ~ ~4 oak_fence_gate[facing=west]
setblock ~11 ~1 ~ lantern
setblock ~20 ~1 ~ lantern
setblock ~11 ~1 ~9 lantern
setblock ~20 ~1 ~9 lantern
setblock ~12 ~ ~1 hay_block
setblock ~19 ~ ~8 water_cauldron[level=3]
summon minecraft:sheep ~14 ~ ~3 {PersistenceRequired:1b}
summon minecraft:sheep ~15 ~ ~3 {PersistenceRequired:1b}
summon minecraft:sheep ~16 ~ ~3 {PersistenceRequired:1b}
summon minecraft:sheep ~14 ~ ~4 {PersistenceRequired:1b}
summon minecraft:text_display ~15 ~3 ~4 {billboard:"center",text:{text:"OVEJAS",color:"gold",bold:1b},background:1073741824}
fill ~ ~ ~11 ~9 ~ ~11 oak_fence
fill ~ ~ ~20 ~9 ~ ~20 oak_fence
fill ~ ~ ~11 ~ ~ ~20 oak_fence
fill ~9 ~ ~11 ~9 ~ ~20 oak_fence
setblock ~9 ~ ~15 oak_fence_gate[facing=east]
setblock ~ ~1 ~11 lantern
setblock ~9 ~1 ~11 lantern
setblock ~ ~1 ~20 lantern
setblock ~9 ~1 ~20 lantern
setblock ~1 ~ ~12 hay_block
setblock ~8 ~ ~19 water_cauldron[level=3]
summon minecraft:pig ~3 ~ ~14 {PersistenceRequired:1b}
summon minecraft:pig ~4 ~ ~14 {PersistenceRequired:1b}
summon minecraft:pig ~5 ~ ~14 {PersistenceRequired:1b}
summon minecraft:pig ~3 ~ ~15 {PersistenceRequired:1b}
summon minecraft:text_display ~4 ~3 ~15 {billboard:"center",text:{text:"CERDOS",color:"gold",bold:1b},background:1073741824}
fill ~11 ~ ~11 ~20 ~ ~11 oak_fence
fill ~11 ~ ~20 ~20 ~ ~20 oak_fence
fill ~11 ~ ~11 ~11 ~ ~20 oak_fence
fill ~20 ~ ~11 ~20 ~ ~20 oak_fence
setblock ~11 ~ ~15 oak_fence_gate[facing=west]
setblock ~11 ~1 ~11 lantern
setblock ~20 ~1 ~11 lantern
setblock ~11 ~1 ~20 lantern
setblock ~20 ~1 ~20 lantern
setblock ~12 ~ ~12 hay_block
setblock ~19 ~ ~19 water_cauldron[level=3]
summon minecraft:chicken ~14 ~ ~14 {PersistenceRequired:1b}
summon minecraft:chicken ~15 ~ ~14 {PersistenceRequired:1b}
summon minecraft:chicken ~16 ~ ~14 {PersistenceRequired:1b}
summon minecraft:chicken ~14 ~ ~15 {PersistenceRequired:1b}
summon minecraft:chicken ~15 ~ ~15 {PersistenceRequired:1b}
summon minecraft:chicken ~16 ~ ~15 {PersistenceRequired:1b}
summon minecraft:text_display ~15 ~3 ~15 {billboard:"center",text:{text:"GALLINAS",color:"gold",bold:1b},background:1073741824}
setblock ~10 ~ ~22 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat",count:64},{Slot:1b,id:"minecraft:wheat",count:64},{Slot:2b,id:"minecraft:carrot",count:64},{Slot:3b,id:"minecraft:wheat_seeds",count:64},{Slot:4b,id:"minecraft:shears",count:1}]}
summon minecraft:text_display ~10 ~2 ~22 {billboard:"center",text:{text:"COMIDA PARA ANIMALES\ntrigo, zanahoria, semillas",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Granja de animales lista: vacas, ovejas, cerdos y gallinas. En el barril de la entrada hay trigo, zanahorias y semillas para que se reproduzcan.","color":"green"}
