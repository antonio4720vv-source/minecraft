tellraw @s {"text":"Construyendo TORRE DE ELITROS con ascensor de burbujas (60 bloques)...","color":"yellow"}
fill ~-4 ~-1 ~-12 ~22 ~29 ~12 air
fill ~-4 ~30 ~-12 ~22 ~63 ~12 air
fill ~-4 ~-1 ~-12 ~22 ~-1 ~12 grass_block
fill ~ ~-1 ~ ~8 ~59 ~8 stone_bricks hollow
fill ~3 ~3 ~ ~5 ~5 ~ glass
fill ~3 ~3 ~8 ~5 ~5 ~8 glass
fill ~ ~3 ~3 ~ ~5 ~5 glass
fill ~8 ~3 ~3 ~8 ~5 ~5 glass
fill ~3 ~9 ~ ~5 ~11 ~ glass
fill ~3 ~9 ~8 ~5 ~11 ~8 glass
fill ~ ~9 ~3 ~ ~11 ~5 glass
fill ~8 ~9 ~3 ~8 ~11 ~5 glass
fill ~3 ~15 ~ ~5 ~17 ~ glass
fill ~3 ~15 ~8 ~5 ~17 ~8 glass
fill ~ ~15 ~3 ~ ~17 ~5 glass
fill ~8 ~15 ~3 ~8 ~17 ~5 glass
fill ~3 ~21 ~ ~5 ~23 ~ glass
fill ~3 ~21 ~8 ~5 ~23 ~8 glass
fill ~ ~21 ~3 ~ ~23 ~5 glass
fill ~8 ~21 ~3 ~8 ~23 ~5 glass
fill ~3 ~27 ~ ~5 ~29 ~ glass
fill ~3 ~27 ~8 ~5 ~29 ~8 glass
fill ~ ~27 ~3 ~ ~29 ~5 glass
fill ~8 ~27 ~3 ~8 ~29 ~5 glass
fill ~3 ~33 ~ ~5 ~35 ~ glass
fill ~3 ~33 ~8 ~5 ~35 ~8 glass
fill ~ ~33 ~3 ~ ~35 ~5 glass
fill ~8 ~33 ~3 ~8 ~35 ~5 glass
fill ~3 ~39 ~ ~5 ~41 ~ glass
fill ~3 ~39 ~8 ~5 ~41 ~8 glass
fill ~ ~39 ~3 ~ ~41 ~5 glass
fill ~8 ~39 ~3 ~8 ~41 ~5 glass
fill ~3 ~45 ~ ~5 ~47 ~ glass
fill ~3 ~45 ~8 ~5 ~47 ~8 glass
fill ~ ~45 ~3 ~ ~47 ~5 glass
fill ~8 ~45 ~3 ~8 ~47 ~5 glass
fill ~3 ~51 ~ ~5 ~53 ~ glass
fill ~3 ~51 ~8 ~5 ~53 ~8 glass
fill ~ ~51 ~3 ~ ~53 ~5 glass
fill ~8 ~51 ~3 ~8 ~53 ~5 glass
fill ~3 ~57 ~ ~5 ~59 ~ glass
fill ~3 ~57 ~8 ~5 ~59 ~8 glass
fill ~ ~57 ~3 ~ ~59 ~5 glass
fill ~8 ~57 ~3 ~8 ~59 ~5 glass
fill ~3 ~-1 ~3 ~5 ~59 ~5 glass
setblock ~4 ~-1 ~4 soul_sand
fill ~4 ~ ~4 ~4 ~59 ~4 bubble_column[drag=false]
fill ~4 ~ ~1 ~4 ~1 ~2 air
fill ~4 ~ ~ ~4 ~1 ~ air
setblock ~4 ~ ~3 oak_door[half=lower,facing=south,hinge=left]
setblock ~4 ~1 ~3 oak_door[half=upper,facing=south,hinge=left]
setblock ~4 ~ ~ iron_door[half=lower,facing=north,hinge=left]
setblock ~4 ~1 ~ iron_door[half=upper,facing=north,hinge=left]
setblock ~5 ~1 ~-1 stone_button[face=wall,facing=north]
setblock ~5 ~1 ~1 stone_button[face=wall,facing=south]
fill ~1 ~ ~1 ~7 ~58 ~7 air replace stone_bricks
fill ~3 ~ ~3 ~5 ~59 ~5 glass
fill ~4 ~ ~4 ~4 ~59 ~4 bubble_column[drag=false]
setblock ~4 ~ ~3 oak_door[half=lower,facing=south,hinge=left]
setblock ~4 ~1 ~3 oak_door[half=upper,facing=south,hinge=left]
fill ~-3 ~60 ~-3 ~11 ~60 ~11 polished_deepslate
setblock ~4 ~60 ~4 air
fill ~-3 ~61 ~-3 ~11 ~61 ~-3 glass_pane[east=true,west=true]
fill ~-3 ~61 ~11 ~11 ~61 ~11 glass_pane[east=true,west=true]
fill ~-3 ~61 ~-3 ~-3 ~61 ~11 glass_pane[north=true,south=true]
fill ~11 ~61 ~-3 ~11 ~61 ~11 glass_pane[north=true,south=true]
fill ~3 ~61 ~-3 ~5 ~61 ~-3 air
fill ~3 ~60 ~-10 ~5 ~60 ~-4 polished_deepslate
setblock ~3 ~61 ~-10 end_rod[facing=up]
setblock ~5 ~61 ~-10 end_rod[facing=up]
setblock ~-3 ~61 ~-3 end_rod[facing=up]
setblock ~11 ~61 ~-3 end_rod[facing=up]
setblock ~-3 ~61 ~11 end_rod[facing=up]
setblock ~11 ~61 ~11 end_rod[facing=up]
setblock ~ ~61 ~ lantern
setblock ~8 ~61 ~ lantern
setblock ~ ~61 ~8 lantern
setblock ~8 ~61 ~8 lantern
setblock ~4 ~61 ~8 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:firework_rocket",count:64,components:{"minecraft:fireworks":{flight_duration:2}}}]}
fill ~11 ~-4 ~-2 ~21 ~-1 ~10 stone_bricks
fill ~12 ~-3 ~-1 ~20 ~-1 ~9 water
summon minecraft:text_display ~4 ~3 ~-1 {billboard:"center",text:{text:"TORRE DE ELITROS\nentra a la columna: te sube sola",color:"gold",bold:1b},background:1073741824}
summon minecraft:text_display ~4 ~63 ~-6 {billboard:"center",text:{text:"SALTA DESDE EL TRAMPOLIN",color:"aqua",bold:1b},background:1073741824}
tellraw @s {"text":"Torre lista: entra por la puerta, metete en la columna de agua y sube sola hasta arriba. En la cima hay un barril con cohetes. Si caes, hay una piscina al este.","color":"green"}
