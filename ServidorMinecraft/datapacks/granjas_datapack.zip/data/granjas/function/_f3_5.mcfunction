execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run function granjas:_f3_5b
schedule function granjas:_f3_6 3s replace
