tellraw @a {"text":"[Ferrocarriles] Todas las lineas estan listas. En cada estacion: pon una vagoneta, subete y presiona el boton.","color":"green"}
execute at @e[type=minecraft:marker,tag=granjas_f1,limit=1] run forceload add ~-2 ~-4 ~70 ~26
execute at @e[type=minecraft:marker,tag=granjas_f2,limit=1] run forceload add ~-2 ~-4 ~160 ~48
execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run forceload add ~-2 ~-4 ~150 ~74
execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run forceload add ~-4 ~-16 ~94 ~66
execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run forceload add ~-115 ~-150 ~115 ~-18
execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run forceload add ~-115 ~-17 ~115 ~115
