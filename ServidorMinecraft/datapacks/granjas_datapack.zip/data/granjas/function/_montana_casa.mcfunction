execute positioned ~-8 ~16 ~-6 run function granjas:_casa_grande
tellraw @s {"text":"Montana con casa lista: sube por la escalera del lado norte.","color":"green"}
