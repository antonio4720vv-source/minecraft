tellraw @s {"text":"Construyendo MONTANA natural...","color":"yellow"}
fill ~2 ~ ~-30 ~4 ~ ~-30 stone
fill ~-3 ~ ~-29 ~8 ~ ~-29 stone
fill ~-6 ~ ~-28 ~10 ~ ~-28 stone
fill ~-9 ~ ~-27 ~11 ~ ~-27 stone
fill ~-11 ~ ~-26 ~12 ~ ~-26 stone
fill ~-13 ~ ~-25 ~13 ~ ~-25 stone
fill ~-15 ~ ~-24 ~13 ~ ~-24 stone
fill ~-16 ~ ~-23 ~14 ~ ~-23 stone
fill ~-17 ~ ~-22 ~15 ~ ~-22 stone
fill ~-18 ~ ~-21 ~15 ~ ~-21 stone
fill ~-19 ~ ~-20 ~16 ~ ~-20 stone
fill ~-20 ~ ~-19 ~16 ~ ~-19 stone
fill ~-21 ~ ~-18 ~16 ~ ~-18 stone
fill ~-21 ~ ~-17 ~17 ~ ~-17 stone
fill ~-22 ~ ~-16 ~17 ~ ~-16 stone
fill ~-22 ~ ~-15 ~18 ~ ~-15 stone
fill ~-22 ~ ~-14 ~18 ~ ~-14 stone
fill ~-22 ~ ~-13 ~19 ~ ~-13 stone
fill ~-22 ~ ~-12 ~20 ~ ~-12 stone
fill ~-23 ~ ~-11 ~21 ~ ~-11 stone
fill ~-23 ~ ~-10 ~22 ~ ~-10 stone
fill ~-23 ~ ~-9 ~23 ~ ~-9 stone
fill ~-23 ~ ~-8 ~24 ~ ~-8 stone
fill ~-23 ~ ~-7 ~25 ~ ~-7 stone
fill ~-23 ~ ~-6 ~26 ~ ~-6 stone
fill ~-23 ~ ~-5 ~27 ~ ~-5 stone
fill ~-23 ~ ~-4 ~28 ~ ~-4 stone
fill ~-24 ~ ~-3 ~28 ~ ~-3 stone
fill ~-24 ~ ~-2 ~29 ~ ~-2 stone
fill ~-24 ~ ~-1 ~30 ~ ~-1 stone
fill ~-25 ~ ~ ~30 ~ ~ stone
fill ~-25 ~ ~1 ~30 ~ ~1 stone
fill ~-25 ~ ~2 ~30 ~ ~2 stone
fill ~-26 ~ ~3 ~30 ~ ~3 stone
fill ~-26 ~ ~4 ~30 ~ ~4 stone
fill ~-27 ~ ~5 ~30 ~ ~5 stone
fill ~-27 ~ ~6 ~30 ~ ~6 stone
fill ~-27 ~ ~7 ~30 ~ ~7 stone
fill ~-27 ~ ~8 ~30 ~ ~8 stone
fill ~-28 ~ ~9 ~29 ~ ~9 stone
fill ~-28 ~ ~10 ~29 ~ ~10 stone
fill ~-28 ~ ~11 ~28 ~ ~11 stone
fill ~-28 ~ ~12 ~27 ~ ~12 stone
fill ~-28 ~ ~13 ~26 ~ ~13 stone
fill ~-28 ~ ~14 ~25 ~ ~14 stone
fill ~-27 ~ ~15 ~24 ~ ~15 stone
fill ~-27 ~ ~16 ~23 ~ ~16 stone
fill ~-27 ~ ~17 ~22 ~ ~17 stone
fill ~-26 ~ ~18 ~21 ~ ~18 stone
fill ~-25 ~ ~19 ~19 ~ ~19 stone
fill ~-24 ~ ~20 ~18 ~ ~20 stone
fill ~-23 ~ ~21 ~17 ~ ~21 stone
fill ~-21 ~ ~22 ~15 ~ ~22 stone
fill ~-19 ~ ~23 ~14 ~ ~23 stone
fill ~-12 ~ ~24 ~12 ~ ~24 stone
fill ~-2 ~ ~25 ~10 ~ ~25 stone
fill ~3 ~ ~26 ~6 ~ ~26 stone
fill ~-5 ~1 ~-27 ~6 ~1 ~-27 stone
fill ~-9 ~1 ~-26 ~8 ~1 ~-26 stone
fill ~-12 ~1 ~-25 ~10 ~1 ~-25 stone
fill ~-14 ~1 ~-24 ~11 ~1 ~-24 stone
fill ~-16 ~1 ~-23 ~12 ~1 ~-23 stone
fill ~-17 ~1 ~-22 ~13 ~1 ~-22 stone
fill ~-18 ~1 ~-21 ~13 ~1 ~-21 stone
fill ~-19 ~1 ~-20 ~14 ~1 ~-20 stone
fill ~-20 ~1 ~-19 ~14 ~1 ~-19 stone
fill ~-20 ~1 ~-18 ~15 ~1 ~-18 stone
fill ~-21 ~1 ~-17 ~15 ~1 ~-17 stone
fill ~-21 ~1 ~-16 ~16 ~1 ~-16 stone
fill ~-21 ~1 ~-15 ~17 ~1 ~-15 stone
fill ~-22 ~1 ~-14 ~17 ~1 ~-14 stone
fill ~-22 ~1 ~-13 ~18 ~1 ~-13 stone
fill ~-22 ~1 ~-12 ~19 ~1 ~-12 stone
fill ~-22 ~1 ~-11 ~20 ~1 ~-11 stone
fill ~-22 ~1 ~-10 ~21 ~1 ~-10 stone
fill ~-22 ~1 ~-9 ~23 ~1 ~-9 stone
fill ~-22 ~1 ~-8 ~24 ~1 ~-8 stone
fill ~-22 ~1 ~-7 ~25 ~1 ~-7 stone
fill ~-22 ~1 ~-6 ~26 ~1 ~-6 stone
fill ~-22 ~1 ~-5 ~27 ~1 ~-5 stone
fill ~-22 ~1 ~-4 ~28 ~1 ~-4 stone
fill ~-22 ~1 ~-3 ~28 ~1 ~-3 stone
fill ~-22 ~1 ~-2 ~29 ~1 ~-2 stone
fill ~-22 ~1 ~-1 ~29 ~1 ~-1 stone
fill ~-23 ~1 ~ ~29 ~1 ~ stone
fill ~-23 ~1 ~1 ~30 ~1 ~1 stone
fill ~-23 ~1 ~2 ~30 ~1 ~2 stone
fill ~-24 ~1 ~3 ~30 ~1 ~3 stone
fill ~-24 ~1 ~4 ~30 ~1 ~4 stone
fill ~-24 ~1 ~5 ~29 ~1 ~5 stone
fill ~-25 ~1 ~6 ~29 ~1 ~6 stone
fill ~-25 ~1 ~7 ~29 ~1 ~7 stone
fill ~-25 ~1 ~8 ~28 ~1 ~8 stone
fill ~-26 ~1 ~9 ~28 ~1 ~9 stone
fill ~-26 ~1 ~10 ~27 ~1 ~10 stone
fill ~-26 ~1 ~11 ~26 ~1 ~11 stone
fill ~-26 ~1 ~12 ~25 ~1 ~12 stone
fill ~-26 ~1 ~13 ~24 ~1 ~13 stone
fill ~-26 ~1 ~14 ~22 ~1 ~14 stone
fill ~-25 ~1 ~15 ~21 ~1 ~15 stone
fill ~-25 ~1 ~16 ~20 ~1 ~16 stone
fill ~-25 ~1 ~17 ~18 ~1 ~17 stone
fill ~-24 ~1 ~18 ~17 ~1 ~18 stone
fill ~-23 ~1 ~19 ~15 ~1 ~19 stone
fill ~-22 ~1 ~20 ~14 ~1 ~20 stone
fill ~-21 ~1 ~21 ~13 ~1 ~21 stone
fill ~-19 ~1 ~22 ~11 ~1 ~22 stone
fill ~-16 ~1 ~23 ~10 ~1 ~23 stone
fill ~-9 ~1 ~24 ~8 ~1 ~24 stone
fill ~ ~1 ~25 ~4 ~1 ~25 stone
fill ~-7 ~2 ~-25 ~5 ~2 ~-25 stone
fill ~-12 ~2 ~-24 ~7 ~2 ~-24 stone
fill ~-14 ~2 ~-23 ~9 ~2 ~-23 stone
fill ~-16 ~2 ~-22 ~10 ~2 ~-22 stone
fill ~-18 ~2 ~-21 ~11 ~2 ~-21 stone
fill ~-19 ~2 ~-20 ~12 ~2 ~-20 stone
fill ~-19 ~2 ~-19 ~13 ~2 ~-19 stone
fill ~-20 ~2 ~-18 ~14 ~2 ~-18 stone
fill ~-20 ~2 ~-17 ~14 ~2 ~-17 stone
fill ~-21 ~2 ~-16 ~15 ~2 ~-16 stone
fill ~-21 ~2 ~-15 ~16 ~2 ~-15 stone
fill ~-21 ~2 ~-14 ~16 ~2 ~-14 stone
fill ~-21 ~2 ~-13 ~17 ~2 ~-13 stone
fill ~-21 ~2 ~-12 ~19 ~2 ~-12 stone
fill ~-21 ~2 ~-11 ~20 ~2 ~-11 stone
fill ~-21 ~2 ~-10 ~21 ~2 ~-10 stone
fill ~-21 ~2 ~-9 ~22 ~2 ~-9 stone
fill ~-21 ~2 ~-8 ~24 ~2 ~-8 stone
fill ~-21 ~2 ~-7 ~25 ~2 ~-7 stone
fill ~-21 ~2 ~-6 ~26 ~2 ~-6 stone
fill ~-21 ~2 ~-5 ~26 ~2 ~-5 stone
fill ~-21 ~2 ~-4 ~27 ~2 ~-4 stone
fill ~-21 ~2 ~-3 ~28 ~2 ~-3 stone
fill ~-21 ~2 ~-2 ~28 ~2 ~-2 stone
fill ~-21 ~2 ~-1 ~28 ~2 ~-1 stone
fill ~-21 ~2 ~ ~29 ~2 ~ stone
fill ~-21 ~2 ~1 ~29 ~2 ~1 stone
fill ~-21 ~2 ~2 ~29 ~2 ~2 stone
fill ~-22 ~2 ~3 ~29 ~2 ~3 stone
fill ~-22 ~2 ~4 ~28 ~2 ~4 stone
fill ~-22 ~2 ~5 ~28 ~2 ~5 stone
fill ~-23 ~2 ~6 ~28 ~2 ~6 stone
fill ~-23 ~2 ~7 ~27 ~2 ~7 stone
fill ~-23 ~2 ~8 ~26 ~2 ~8 stone
fill ~-23 ~2 ~9 ~26 ~2 ~9 stone
fill ~-24 ~2 ~10 ~25 ~2 ~10 stone
fill ~-24 ~2 ~11 ~23 ~2 ~11 stone
fill ~-24 ~2 ~12 ~22 ~2 ~12 stone
fill ~-24 ~2 ~13 ~20 ~2 ~13 stone
fill ~-23 ~2 ~14 ~19 ~2 ~14 stone
fill ~-23 ~2 ~15 ~17 ~2 ~15 stone
fill ~-23 ~2 ~16 ~16 ~2 ~16 stone
fill ~-22 ~2 ~17 ~15 ~2 ~17 stone
fill ~-21 ~2 ~18 ~13 ~2 ~18 stone
fill ~-21 ~2 ~19 ~12 ~2 ~19 stone
fill ~-19 ~2 ~20 ~11 ~2 ~20 stone
fill ~-18 ~2 ~21 ~10 ~2 ~21 stone
fill ~-16 ~2 ~22 ~9 ~2 ~22 stone
fill ~-12 ~2 ~23 ~7 ~2 ~23 stone
fill ~-7 ~2 ~24 ~5 ~2 ~24 stone
fill ~-10 ~3 ~-23 ~5 ~3 ~-23 stone
fill ~-14 ~3 ~-22 ~7 ~3 ~-22 stone
fill ~-16 ~3 ~-21 ~9 ~3 ~-21 stone
fill ~-18 ~3 ~-20 ~10 ~3 ~-20 stone
fill ~-19 ~3 ~-19 ~11 ~3 ~-19 stone
fill ~-19 ~3 ~-18 ~12 ~3 ~-18 stone
fill ~-20 ~3 ~-17 ~13 ~3 ~-17 stone
fill ~-20 ~3 ~-16 ~14 ~3 ~-16 stone
fill ~-21 ~3 ~-15 ~15 ~3 ~-15 stone
fill ~-21 ~3 ~-14 ~16 ~3 ~-14 stone
fill ~-21 ~3 ~-13 ~17 ~3 ~-13 stone
fill ~-21 ~3 ~-12 ~18 ~3 ~-12 stone
fill ~-21 ~3 ~-11 ~20 ~3 ~-11 stone
fill ~-21 ~3 ~-10 ~21 ~3 ~-10 stone
fill ~-21 ~3 ~-9 ~22 ~3 ~-9 stone
fill ~-21 ~3 ~-8 ~23 ~3 ~-8 stone
fill ~-21 ~3 ~-7 ~24 ~3 ~-7 stone
fill ~-20 ~3 ~-6 ~25 ~3 ~-6 stone
fill ~-20 ~3 ~-5 ~26 ~3 ~-5 stone
fill ~-20 ~3 ~-4 ~26 ~3 ~-4 stone
fill ~-20 ~3 ~-3 ~27 ~3 ~-3 stone
fill ~-20 ~3 ~-2 ~27 ~3 ~-2 stone
fill ~-20 ~3 ~-1 ~27 ~3 ~-1 stone
fill ~-20 ~3 ~ ~27 ~3 ~ stone
fill ~-20 ~3 ~1 ~27 ~3 ~1 stone
fill ~-20 ~3 ~2 ~27 ~3 ~2 stone
fill ~-20 ~3 ~3 ~27 ~3 ~3 stone
fill ~-21 ~3 ~4 ~27 ~3 ~4 stone
fill ~-21 ~3 ~5 ~26 ~3 ~5 stone
fill ~-21 ~3 ~6 ~26 ~3 ~6 stone
fill ~-21 ~3 ~7 ~25 ~3 ~7 stone
fill ~-21 ~3 ~8 ~24 ~3 ~8 stone
fill ~-22 ~3 ~9 ~23 ~3 ~9 stone
fill ~-22 ~3 ~10 ~22 ~3 ~10 stone
fill ~-22 ~3 ~11 ~20 ~3 ~11 stone
fill ~-22 ~3 ~12 ~18 ~3 ~12 stone
fill ~-21 ~3 ~13 ~17 ~3 ~13 stone
fill ~-21 ~3 ~14 ~15 ~3 ~14 stone
fill ~-21 ~3 ~15 ~14 ~3 ~15 stone
fill ~-20 ~3 ~16 ~13 ~3 ~16 stone
fill ~-20 ~3 ~17 ~12 ~3 ~17 stone
fill ~-19 ~3 ~18 ~11 ~3 ~18 stone
fill ~-18 ~3 ~19 ~11 ~3 ~19 stone
fill ~-16 ~3 ~20 ~10 ~3 ~20 stone
fill ~-15 ~3 ~21 ~9 ~3 ~21 stone
fill ~-12 ~3 ~22 ~7 ~3 ~22 stone
fill ~-9 ~3 ~23 ~6 ~3 ~23 stone
fill ~-4 ~3 ~24 ~3 ~3 ~24 stone
fill ~-13 ~4 ~-21 ~6 ~4 ~-21 stone
fill ~-16 ~4 ~-20 ~8 ~4 ~-20 stone
fill ~-17 ~4 ~-19 ~10 ~4 ~-19 stone
fill ~-18 ~4 ~-18 ~11 ~4 ~-18 stone
fill ~-19 ~4 ~-17 ~13 ~4 ~-17 stone
fill ~-20 ~4 ~-16 ~14 ~4 ~-16 stone
fill ~-20 ~4 ~-15 ~15 ~4 ~-15 stone
fill ~-21 ~4 ~-14 ~16 ~4 ~-14 stone
fill ~-21 ~4 ~-13 ~17 ~4 ~-13 stone
fill ~-21 ~4 ~-12 ~18 ~4 ~-12 stone
fill ~-21 ~4 ~-11 ~19 ~4 ~-11 stone
fill ~-21 ~4 ~-10 ~20 ~4 ~-10 stone
fill ~-21 ~4 ~-9 ~21 ~4 ~-9 stone
fill ~-21 ~4 ~-8 ~22 ~4 ~-8 stone
fill ~-20 ~4 ~-7 ~23 ~4 ~-7 stone
fill ~-20 ~4 ~-6 ~24 ~4 ~-6 stone
fill ~-20 ~4 ~-5 ~25 ~4 ~-5 stone
fill ~-20 ~4 ~-4 ~25 ~4 ~-4 stone
fill ~-19 ~4 ~-3 ~25 ~4 ~-3 stone
fill ~-19 ~4 ~-2 ~26 ~4 ~-2 stone
fill ~-19 ~4 ~-1 ~26 ~4 ~-1 stone
fill ~-19 ~4 ~ ~26 ~4 ~ stone
fill ~-19 ~4 ~1 ~26 ~4 ~1 stone
fill ~-19 ~4 ~2 ~25 ~4 ~2 stone
fill ~-19 ~4 ~3 ~25 ~4 ~3 stone
fill ~-19 ~4 ~4 ~25 ~4 ~4 stone
fill ~-19 ~4 ~5 ~24 ~4 ~5 stone
fill ~-20 ~4 ~6 ~23 ~4 ~6 stone
fill ~-20 ~4 ~7 ~22 ~4 ~7 stone
fill ~-20 ~4 ~8 ~21 ~4 ~8 stone
fill ~-20 ~4 ~9 ~20 ~4 ~9 stone
fill ~-20 ~4 ~10 ~18 ~4 ~10 stone
fill ~-20 ~4 ~11 ~17 ~4 ~11 stone
fill ~-20 ~4 ~12 ~15 ~4 ~12 stone
fill ~-19 ~4 ~13 ~14 ~4 ~13 stone
fill ~-19 ~4 ~14 ~13 ~4 ~14 stone
fill ~-18 ~4 ~15 ~12 ~4 ~15 stone
fill ~-18 ~4 ~16 ~12 ~4 ~16 stone
fill ~-17 ~4 ~17 ~11 ~4 ~17 stone
fill ~-16 ~4 ~18 ~10 ~4 ~18 stone
fill ~-15 ~4 ~19 ~10 ~4 ~19 stone
fill ~-13 ~4 ~20 ~9 ~4 ~20 stone
fill ~-11 ~4 ~21 ~8 ~4 ~21 stone
fill ~-8 ~4 ~22 ~6 ~4 ~22 stone
fill ~-6 ~4 ~23 ~5 ~4 ~23 stone
fill ~-1 ~4 ~24 ~2 ~4 ~24 stone
fill ~-15 ~5 ~-19 ~9 ~5 ~-19 stone
fill ~-17 ~5 ~-18 ~11 ~5 ~-18 stone
fill ~-18 ~5 ~-17 ~12 ~5 ~-17 stone
fill ~-19 ~5 ~-16 ~13 ~5 ~-16 stone
fill ~-19 ~5 ~-15 ~14 ~5 ~-15 stone
fill ~-20 ~5 ~-14 ~15 ~5 ~-14 stone
fill ~-20 ~5 ~-13 ~17 ~5 ~-13 stone
fill ~-20 ~5 ~-12 ~18 ~5 ~-12 stone
fill ~-21 ~5 ~-11 ~19 ~5 ~-11 stone
fill ~-21 ~5 ~-10 ~20 ~5 ~-10 stone
fill ~-21 ~5 ~-9 ~20 ~5 ~-9 stone
fill ~-20 ~5 ~-8 ~21 ~5 ~-8 stone
fill ~-20 ~5 ~-7 ~22 ~5 ~-7 stone
fill ~-20 ~5 ~-6 ~23 ~5 ~-6 stone
fill ~-20 ~5 ~-5 ~23 ~5 ~-5 stone
fill ~-19 ~5 ~-4 ~23 ~5 ~-4 stone
fill ~-19 ~5 ~-3 ~24 ~5 ~-3 stone
fill ~-19 ~5 ~-2 ~24 ~5 ~-2 stone
fill ~-19 ~5 ~-1 ~24 ~5 ~-1 stone
fill ~-18 ~5 ~ ~24 ~5 ~ stone
fill ~-18 ~5 ~1 ~24 ~5 ~1 stone
fill ~-18 ~5 ~2 ~23 ~5 ~2 stone
fill ~-18 ~5 ~3 ~23 ~5 ~3 stone
fill ~-18 ~5 ~4 ~22 ~5 ~4 stone
fill ~-18 ~5 ~5 ~22 ~5 ~5 stone
fill ~-18 ~5 ~6 ~21 ~5 ~6 stone
fill ~-18 ~5 ~7 ~20 ~5 ~7 stone
fill ~-18 ~5 ~8 ~18 ~5 ~8 stone
fill ~-18 ~5 ~9 ~17 ~5 ~9 stone
fill ~-18 ~5 ~10 ~16 ~5 ~10 stone
fill ~-18 ~5 ~11 ~14 ~5 ~11 stone
fill ~-18 ~5 ~12 ~13 ~5 ~12 stone
fill ~-17 ~5 ~13 ~13 ~5 ~13 stone
fill ~-17 ~5 ~14 ~12 ~5 ~14 stone
fill ~-16 ~5 ~15 ~11 ~5 ~15 stone
fill ~-15 ~5 ~16 ~11 ~5 ~16 stone
fill ~-14 ~5 ~17 ~10 ~5 ~17 stone
fill ~-13 ~5 ~18 ~10 ~5 ~18 stone
fill ~-11 ~5 ~19 ~9 ~5 ~19 stone
fill ~-9 ~5 ~20 ~8 ~5 ~20 stone
fill ~-7 ~5 ~21 ~7 ~5 ~21 stone
fill ~-5 ~5 ~22 ~6 ~5 ~22 stone
fill ~-3 ~5 ~23 ~4 ~5 ~23 stone
fill ~4 ~6 ~-19 ~7 ~6 ~-19 stone
fill ~-12 ~6 ~-18 ~-8 ~6 ~-18 stone
fill ~-1 ~6 ~-18 ~10 ~6 ~-18 stone
fill ~-15 ~6 ~-17 ~12 ~6 ~-17 stone
fill ~-17 ~6 ~-16 ~13 ~6 ~-16 stone
fill ~-18 ~6 ~-15 ~14 ~6 ~-15 stone
fill ~-19 ~6 ~-14 ~15 ~6 ~-14 stone
fill ~-19 ~6 ~-13 ~16 ~6 ~-13 stone
fill ~-20 ~6 ~-12 ~17 ~6 ~-12 stone
fill ~-20 ~6 ~-11 ~18 ~6 ~-11 stone
fill ~-20 ~6 ~-10 ~18 ~6 ~-10 stone
fill ~-20 ~6 ~-9 ~19 ~6 ~-9 stone
fill ~-20 ~6 ~-8 ~20 ~6 ~-8 stone
fill ~-20 ~6 ~-7 ~21 ~6 ~-7 stone
fill ~-20 ~6 ~-6 ~21 ~6 ~-6 stone
fill ~-20 ~6 ~-5 ~21 ~6 ~-5 stone
fill ~-19 ~6 ~-4 ~22 ~6 ~-4 stone
fill ~-19 ~6 ~-3 ~22 ~6 ~-3 stone
fill ~-19 ~6 ~-2 ~22 ~6 ~-2 stone
fill ~-18 ~6 ~-1 ~22 ~6 ~-1 stone
fill ~-18 ~6 ~ ~22 ~6 ~ stone
fill ~-18 ~6 ~1 ~22 ~6 ~1 stone
fill ~-18 ~6 ~2 ~21 ~6 ~2 stone
fill ~-18 ~6 ~3 ~21 ~6 ~3 stone
fill ~-18 ~6 ~4 ~20 ~6 ~4 stone
fill ~-18 ~6 ~5 ~19 ~6 ~5 stone
fill ~-17 ~6 ~6 ~18 ~6 ~6 stone
fill ~-17 ~6 ~7 ~17 ~6 ~7 stone
fill ~-17 ~6 ~8 ~16 ~6 ~8 stone
fill ~-17 ~6 ~9 ~15 ~6 ~9 stone
fill ~-17 ~6 ~10 ~14 ~6 ~10 stone
fill ~-16 ~6 ~11 ~13 ~6 ~11 stone
fill ~-16 ~6 ~12 ~12 ~6 ~12 stone
fill ~-15 ~6 ~13 ~12 ~6 ~13 stone
fill ~-14 ~6 ~14 ~11 ~6 ~14 stone
fill ~-13 ~6 ~15 ~11 ~6 ~15 stone
fill ~-12 ~6 ~16 ~10 ~6 ~16 stone
fill ~-11 ~6 ~17 ~10 ~6 ~17 stone
fill ~-9 ~6 ~18 ~9 ~6 ~18 stone
fill ~-8 ~6 ~19 ~9 ~6 ~19 stone
fill ~-6 ~6 ~20 ~8 ~6 ~20 stone
fill ~-4 ~6 ~21 ~7 ~6 ~21 stone
fill ~-2 ~6 ~22 ~5 ~6 ~22 stone
fill ~3 ~7 ~-18 ~9 ~7 ~-18 stone
fill ~ ~7 ~-17 ~11 ~7 ~-17 stone
fill ~-13 ~7 ~-16 ~12 ~7 ~-16 stone
fill ~-16 ~7 ~-15 ~13 ~7 ~-15 stone
fill ~-17 ~7 ~-14 ~14 ~7 ~-14 stone
fill ~-18 ~7 ~-13 ~15 ~7 ~-13 stone
fill ~-18 ~7 ~-12 ~16 ~7 ~-12 stone
fill ~-19 ~7 ~-11 ~17 ~7 ~-11 stone
fill ~-19 ~7 ~-10 ~17 ~7 ~-10 stone
fill ~-19 ~7 ~-9 ~18 ~7 ~-9 stone
fill ~-19 ~7 ~-8 ~18 ~7 ~-8 stone
fill ~-19 ~7 ~-7 ~19 ~7 ~-7 stone
fill ~-19 ~7 ~-6 ~19 ~7 ~-6 stone
fill ~-19 ~7 ~-5 ~20 ~7 ~-5 stone
fill ~-19 ~7 ~-4 ~20 ~7 ~-4 stone
fill ~-19 ~7 ~-3 ~20 ~7 ~-3 stone
fill ~-18 ~7 ~-2 ~20 ~7 ~-2 stone
fill ~-18 ~7 ~-1 ~20 ~7 ~-1 stone
fill ~-18 ~7 ~ ~20 ~7 ~ stone
fill ~-18 ~7 ~1 ~20 ~7 ~1 stone
fill ~-18 ~7 ~2 ~19 ~7 ~2 stone
fill ~-17 ~7 ~3 ~19 ~7 ~3 stone
fill ~-17 ~7 ~4 ~18 ~7 ~4 stone
fill ~-17 ~7 ~5 ~17 ~7 ~5 stone
fill ~-17 ~7 ~6 ~16 ~7 ~6 stone
fill ~-17 ~7 ~7 ~15 ~7 ~7 stone
fill ~-16 ~7 ~8 ~14 ~7 ~8 stone
fill ~-16 ~7 ~9 ~13 ~7 ~9 stone
fill ~-15 ~7 ~10 ~13 ~7 ~10 stone
fill ~-15 ~7 ~11 ~12 ~7 ~11 stone
fill ~-14 ~7 ~12 ~12 ~7 ~12 stone
fill ~-13 ~7 ~13 ~11 ~7 ~13 stone
fill ~-12 ~7 ~14 ~11 ~7 ~14 stone
fill ~-10 ~7 ~15 ~11 ~7 ~15 stone
fill ~-9 ~7 ~16 ~10 ~7 ~16 stone
fill ~-7 ~7 ~17 ~10 ~7 ~17 stone
fill ~-6 ~7 ~18 ~9 ~7 ~18 stone
fill ~-5 ~7 ~19 ~8 ~7 ~19 stone
fill ~-3 ~7 ~20 ~7 ~7 ~20 stone
fill ~-2 ~7 ~21 ~6 ~7 ~21 stone
fill ~2 ~7 ~22 ~3 ~7 ~22 stone
fill ~4 ~8 ~-18 ~8 ~8 ~-18 stone
fill ~2 ~8 ~-17 ~10 ~8 ~-17 stone
fill ~-1 ~8 ~-16 ~12 ~8 ~-16 stone
fill ~-10 ~8 ~-15 ~-8 ~8 ~-15 stone
fill ~-4 ~8 ~-15 ~13 ~8 ~-15 stone
fill ~-14 ~8 ~-14 ~13 ~8 ~-14 stone
fill ~-16 ~8 ~-13 ~14 ~8 ~-13 stone
fill ~-17 ~8 ~-12 ~15 ~8 ~-12 stone
fill ~-17 ~8 ~-11 ~15 ~8 ~-11 stone
fill ~-18 ~8 ~-10 ~16 ~8 ~-10 stone
fill ~-18 ~8 ~-9 ~16 ~8 ~-9 stone
fill ~-18 ~8 ~-8 ~17 ~8 ~-8 stone
fill ~-18 ~8 ~-7 ~17 ~8 ~-7 stone
fill ~-19 ~8 ~-6 ~18 ~8 ~-6 stone
fill ~-18 ~8 ~-5 ~18 ~8 ~-5 stone
fill ~-18 ~8 ~-4 ~18 ~8 ~-4 stone
fill ~-18 ~8 ~-3 ~18 ~8 ~-3 stone
fill ~-18 ~8 ~-2 ~18 ~8 ~-2 stone
fill ~-18 ~8 ~-1 ~18 ~8 ~-1 stone
fill ~-18 ~8 ~ ~18 ~8 ~ stone
fill ~-18 ~8 ~1 ~18 ~8 ~1 stone
fill ~-17 ~8 ~2 ~18 ~8 ~2 stone
fill ~-17 ~8 ~3 ~17 ~8 ~3 stone
fill ~-17 ~8 ~4 ~17 ~8 ~4 stone
fill ~-17 ~8 ~5 ~16 ~8 ~5 stone
fill ~-16 ~8 ~6 ~15 ~8 ~6 stone
fill ~-16 ~8 ~7 ~14 ~8 ~7 stone
fill ~-16 ~8 ~8 ~13 ~8 ~8 stone
fill ~-15 ~8 ~9 ~13 ~8 ~9 stone
fill ~-14 ~8 ~10 ~12 ~8 ~10 stone
fill ~-13 ~8 ~11 ~12 ~8 ~11 stone
fill ~-12 ~8 ~12 ~11 ~8 ~12 stone
fill ~-10 ~8 ~13 ~11 ~8 ~13 stone
fill ~-9 ~8 ~14 ~11 ~8 ~14 stone
fill ~-7 ~8 ~15 ~10 ~8 ~15 stone
fill ~-6 ~8 ~16 ~10 ~8 ~16 stone
fill ~-5 ~8 ~17 ~9 ~8 ~17 stone
fill ~-4 ~8 ~18 ~9 ~8 ~18 stone
fill ~-2 ~8 ~19 ~8 ~8 ~19 stone
fill ~ ~8 ~20 ~6 ~8 ~20 stone
fill ~3 ~8 ~21 ~3 ~8 ~21 stone
fill ~2 ~9 ~-17 ~9 ~9 ~-17 stone
fill ~ ~9 ~-16 ~11 ~9 ~-16 stone
fill ~-1 ~9 ~-15 ~11 ~9 ~-15 stone
fill ~-4 ~9 ~-14 ~12 ~9 ~-14 stone
fill ~-12 ~9 ~-13 ~13 ~9 ~-13 stone
fill ~-14 ~9 ~-12 ~13 ~9 ~-12 stone
fill ~-15 ~9 ~-11 ~14 ~9 ~-11 stone
fill ~-16 ~9 ~-10 ~14 ~9 ~-10 stone
fill ~-17 ~9 ~-9 ~15 ~9 ~-9 stone
fill ~-17 ~9 ~-8 ~15 ~9 ~-8 stone
fill ~-17 ~9 ~-7 ~15 ~9 ~-7 stone
fill ~-17 ~9 ~-6 ~16 ~9 ~-6 stone
fill ~-18 ~9 ~-5 ~16 ~9 ~-5 stone
fill ~-18 ~9 ~-4 ~16 ~9 ~-4 stone
fill ~-18 ~9 ~-3 ~17 ~9 ~-3 stone
fill ~-17 ~9 ~-2 ~17 ~9 ~-2 stone
fill ~-17 ~9 ~-1 ~17 ~9 ~-1 stone
fill ~-17 ~9 ~ ~17 ~9 ~ stone
fill ~-17 ~9 ~1 ~16 ~9 ~1 stone
fill ~-17 ~9 ~2 ~16 ~9 ~2 stone
fill ~-17 ~9 ~3 ~16 ~9 ~3 stone
fill ~-17 ~9 ~4 ~15 ~9 ~4 stone
fill ~-16 ~9 ~5 ~15 ~9 ~5 stone
fill ~-16 ~9 ~6 ~14 ~9 ~6 stone
fill ~-16 ~9 ~7 ~13 ~9 ~7 stone
fill ~-15 ~9 ~8 ~13 ~9 ~8 stone
fill ~-14 ~9 ~9 ~12 ~9 ~9 stone
fill ~-13 ~9 ~10 ~12 ~9 ~10 stone
fill ~-12 ~9 ~11 ~12 ~9 ~11 stone
fill ~-10 ~9 ~12 ~11 ~9 ~12 stone
fill ~-8 ~9 ~13 ~11 ~9 ~13 stone
fill ~-6 ~9 ~14 ~10 ~9 ~14 stone
fill ~-5 ~9 ~15 ~10 ~9 ~15 stone
fill ~-4 ~9 ~16 ~9 ~9 ~16 stone
fill ~-2 ~9 ~17 ~9 ~9 ~17 stone
fill ~-1 ~9 ~18 ~8 ~9 ~18 stone
fill ~1 ~9 ~19 ~6 ~9 ~19 stone
fill ~3 ~10 ~-17 ~8 ~10 ~-17 stone
fill ~1 ~10 ~-16 ~9 ~10 ~-16 stone
fill ~-1 ~10 ~-15 ~10 ~10 ~-15 stone
fill ~-2 ~10 ~-14 ~11 ~10 ~-14 stone
fill ~-5 ~10 ~-13 ~12 ~10 ~-13 stone
fill ~-11 ~10 ~-12 ~12 ~10 ~-12 stone
fill ~-13 ~10 ~-11 ~12 ~10 ~-11 stone
fill ~-14 ~10 ~-10 ~13 ~10 ~-10 stone
fill ~-15 ~10 ~-9 ~13 ~10 ~-9 stone
fill ~-15 ~10 ~-8 ~13 ~10 ~-8 stone
fill ~-16 ~10 ~-7 ~14 ~10 ~-7 stone
fill ~-16 ~10 ~-6 ~14 ~10 ~-6 stone
fill ~-16 ~10 ~-5 ~14 ~10 ~-5 stone
fill ~-16 ~10 ~-4 ~15 ~10 ~-4 stone
fill ~-17 ~10 ~-3 ~15 ~10 ~-3 stone
fill ~-17 ~10 ~-2 ~15 ~10 ~-2 stone
fill ~-17 ~10 ~-1 ~15 ~10 ~-1 stone
fill ~-17 ~10 ~ ~15 ~10 ~ stone
fill ~-17 ~10 ~1 ~15 ~10 ~1 stone
fill ~-17 ~10 ~2 ~15 ~10 ~2 stone
fill ~-16 ~10 ~3 ~15 ~10 ~3 stone
fill ~-16 ~10 ~4 ~15 ~10 ~4 stone
fill ~-16 ~10 ~5 ~14 ~10 ~5 stone
fill ~-16 ~10 ~6 ~14 ~10 ~6 stone
fill ~-15 ~10 ~7 ~13 ~10 ~7 stone
fill ~-15 ~10 ~8 ~13 ~10 ~8 stone
fill ~-14 ~10 ~9 ~12 ~10 ~9 stone
fill ~-12 ~10 ~10 ~12 ~10 ~10 stone
fill ~-10 ~10 ~11 ~11 ~10 ~11 stone
fill ~-8 ~10 ~12 ~11 ~10 ~12 stone
fill ~-5 ~10 ~13 ~10 ~10 ~13 stone
fill ~-4 ~10 ~14 ~10 ~10 ~14 stone
fill ~-3 ~10 ~15 ~9 ~10 ~15 stone
fill ~-1 ~10 ~16 ~9 ~10 ~16 stone
fill ~ ~10 ~17 ~8 ~10 ~17 stone
fill ~2 ~10 ~18 ~6 ~10 ~18 stone
fill ~4 ~11 ~-17 ~5 ~11 ~-17 stone
fill ~1 ~11 ~-16 ~8 ~11 ~-16 stone
fill ~ ~11 ~-15 ~9 ~11 ~-15 stone
fill ~-2 ~11 ~-14 ~10 ~11 ~-14 stone
fill ~-5 ~11 ~-13 ~10 ~11 ~-13 stone
fill ~-7 ~11 ~-12 ~11 ~11 ~-12 stone
fill ~-10 ~11 ~-11 ~11 ~11 ~-11 stone
fill ~-12 ~11 ~-10 ~11 ~11 ~-10 stone
fill ~-13 ~11 ~-9 ~12 ~11 ~-9 stone
fill ~-14 ~11 ~-8 ~12 ~11 ~-8 stone
fill ~-14 ~11 ~-7 ~12 ~11 ~-7 stone
fill ~-15 ~11 ~-6 ~13 ~11 ~-6 stone
fill ~-15 ~11 ~-5 ~13 ~11 ~-5 stone
fill ~-15 ~11 ~-4 ~13 ~11 ~-4 stone
fill ~-15 ~11 ~-3 ~14 ~11 ~-3 stone
fill ~-16 ~11 ~-2 ~14 ~11 ~-2 stone
fill ~-16 ~11 ~-1 ~14 ~11 ~-1 stone
fill ~-16 ~11 ~ ~14 ~11 ~ stone
fill ~-16 ~11 ~1 ~15 ~11 ~1 stone
fill ~-16 ~11 ~2 ~14 ~11 ~2 stone
fill ~-16 ~11 ~3 ~14 ~11 ~3 stone
fill ~-16 ~11 ~4 ~14 ~11 ~4 stone
fill ~-16 ~11 ~5 ~14 ~11 ~5 stone
fill ~-15 ~11 ~6 ~13 ~11 ~6 stone
fill ~-15 ~11 ~7 ~13 ~11 ~7 stone
fill ~-14 ~11 ~8 ~12 ~11 ~8 stone
fill ~-13 ~11 ~9 ~12 ~11 ~9 stone
fill ~-12 ~11 ~10 ~11 ~11 ~10 stone
fill ~-9 ~11 ~11 ~11 ~11 ~11 stone
fill ~-7 ~11 ~12 ~10 ~11 ~12 stone
fill ~-5 ~11 ~13 ~10 ~11 ~13 stone
fill ~-2 ~11 ~14 ~9 ~11 ~14 stone
fill ~-1 ~11 ~15 ~8 ~11 ~15 stone
fill ~1 ~11 ~16 ~7 ~11 ~16 stone
fill ~2 ~12 ~-16 ~6 ~12 ~-16 stone
fill ~ ~12 ~-15 ~7 ~12 ~-15 stone
fill ~-2 ~12 ~-14 ~8 ~12 ~-14 stone
fill ~-5 ~12 ~-13 ~9 ~12 ~-13 stone
fill ~-7 ~12 ~-12 ~9 ~12 ~-12 stone
fill ~-8 ~12 ~-11 ~10 ~12 ~-11 stone
fill ~-10 ~12 ~-10 ~10 ~12 ~-10 stone
fill ~-11 ~12 ~-9 ~10 ~12 ~-9 stone
fill ~-12 ~12 ~-8 ~11 ~12 ~-8 stone
fill ~-12 ~12 ~-7 ~12 ~12 ~-7 stone
fill ~-13 ~12 ~-6 ~12 ~12 ~-6 stone
fill ~-13 ~12 ~-5 ~13 ~12 ~-5 stone
fill ~-14 ~12 ~-4 ~13 ~12 ~-4 stone
fill ~-14 ~12 ~-3 ~13 ~12 ~-3 stone
fill ~-14 ~12 ~-2 ~13 ~12 ~-2 stone
fill ~-15 ~12 ~-1 ~14 ~12 ~-1 stone
fill ~-15 ~12 ~ ~14 ~12 ~ stone
fill ~-15 ~12 ~1 ~14 ~12 ~1 stone
fill ~-15 ~12 ~2 ~14 ~12 ~2 stone
fill ~-15 ~12 ~3 ~14 ~12 ~3 stone
fill ~-15 ~12 ~4 ~14 ~12 ~4 stone
fill ~-15 ~12 ~5 ~13 ~12 ~5 stone
fill ~-15 ~12 ~6 ~13 ~12 ~6 stone
fill ~-14 ~12 ~7 ~13 ~12 ~7 stone
fill ~-14 ~12 ~8 ~12 ~12 ~8 stone
fill ~-13 ~12 ~9 ~12 ~12 ~9 stone
fill ~-11 ~12 ~10 ~11 ~12 ~10 stone
fill ~-8 ~12 ~11 ~10 ~12 ~11 stone
fill ~-7 ~12 ~12 ~10 ~12 ~12 stone
fill ~-5 ~12 ~13 ~9 ~12 ~13 stone
fill ~-1 ~12 ~14 ~8 ~12 ~14 stone
fill ~2 ~12 ~15 ~6 ~12 ~15 stone
fill ~-1 ~13 ~-14 ~1 ~13 ~-14 stone
fill ~-5 ~13 ~-13 ~5 ~13 ~-13 stone
fill ~-7 ~13 ~-12 ~7 ~13 ~-12 stone
fill ~-8 ~13 ~-11 ~8 ~13 ~-11 stone
fill ~-9 ~13 ~-10 ~9 ~13 ~-10 stone
fill ~-10 ~13 ~-9 ~10 ~13 ~-9 stone
fill ~-11 ~13 ~-8 ~11 ~13 ~-8 stone
fill ~-12 ~13 ~-7 ~12 ~13 ~-7 stone
fill ~-12 ~13 ~-6 ~12 ~13 ~-6 stone
fill ~-13 ~13 ~-5 ~13 ~13 ~-5 stone
fill ~-13 ~13 ~-4 ~13 ~13 ~-4 stone
fill ~-13 ~13 ~-3 ~13 ~13 ~-3 stone
fill ~-13 ~13 ~-2 ~13 ~13 ~-2 stone
fill ~-14 ~13 ~-1 ~14 ~13 ~-1 stone
fill ~-14 ~13 ~ ~14 ~13 ~ stone
fill ~-14 ~13 ~1 ~14 ~13 ~1 stone
fill ~-13 ~13 ~2 ~13 ~13 ~2 stone
fill ~-13 ~13 ~3 ~13 ~13 ~3 stone
fill ~-13 ~13 ~4 ~13 ~13 ~4 stone
fill ~-13 ~13 ~5 ~13 ~13 ~5 stone
fill ~-12 ~13 ~6 ~12 ~13 ~6 stone
fill ~-12 ~13 ~7 ~12 ~13 ~7 stone
fill ~-11 ~13 ~8 ~11 ~13 ~8 stone
fill ~-10 ~13 ~9 ~10 ~13 ~9 stone
fill ~-9 ~13 ~10 ~9 ~13 ~10 stone
fill ~-8 ~13 ~11 ~8 ~13 ~11 stone
fill ~-7 ~13 ~12 ~7 ~13 ~12 stone
fill ~-5 ~13 ~13 ~5 ~13 ~13 stone
fill ~-1 ~13 ~14 ~1 ~13 ~14 stone
fill ~-3 ~14 ~-13 ~3 ~14 ~-13 dirt
fill ~-6 ~14 ~-12 ~6 ~14 ~-12 dirt
fill ~-7 ~14 ~-11 ~7 ~14 ~-11 dirt
fill ~-8 ~14 ~-10 ~8 ~14 ~-10 dirt
fill ~-9 ~14 ~-9 ~9 ~14 ~-9 dirt
fill ~-10 ~14 ~-8 ~10 ~14 ~-8 dirt
fill ~-11 ~14 ~-7 ~11 ~14 ~-7 dirt
fill ~-12 ~14 ~-6 ~12 ~14 ~-6 dirt
fill ~-12 ~14 ~-5 ~12 ~14 ~-5 dirt
fill ~-12 ~14 ~-4 ~12 ~14 ~-4 dirt
fill ~-13 ~14 ~-3 ~13 ~14 ~-3 dirt
fill ~-13 ~14 ~-2 ~13 ~14 ~-2 dirt
fill ~-13 ~14 ~-1 ~13 ~14 ~-1 dirt
fill ~-13 ~14 ~ ~13 ~14 ~ dirt
fill ~-13 ~14 ~1 ~13 ~14 ~1 dirt
fill ~-13 ~14 ~2 ~13 ~14 ~2 dirt
fill ~-13 ~14 ~3 ~13 ~14 ~3 dirt
fill ~-12 ~14 ~4 ~12 ~14 ~4 dirt
fill ~-12 ~14 ~5 ~12 ~14 ~5 dirt
fill ~-12 ~14 ~6 ~12 ~14 ~6 dirt
fill ~-11 ~14 ~7 ~11 ~14 ~7 dirt
fill ~-10 ~14 ~8 ~10 ~14 ~8 dirt
fill ~-9 ~14 ~9 ~9 ~14 ~9 dirt
fill ~-8 ~14 ~10 ~8 ~14 ~10 dirt
fill ~-7 ~14 ~11 ~7 ~14 ~11 dirt
fill ~-6 ~14 ~12 ~6 ~14 ~12 dirt
fill ~-3 ~14 ~13 ~3 ~14 ~13 dirt
fill ~ ~15 ~-13 ~ ~15 ~-13 dirt
fill ~-5 ~15 ~-12 ~5 ~15 ~-12 dirt
fill ~-6 ~15 ~-11 ~6 ~15 ~-11 dirt
fill ~-8 ~15 ~-10 ~8 ~15 ~-10 dirt
fill ~-9 ~15 ~-9 ~9 ~15 ~-9 dirt
fill ~-10 ~15 ~-8 ~10 ~15 ~-8 dirt
fill ~-10 ~15 ~-7 ~10 ~15 ~-7 dirt
fill ~-11 ~15 ~-6 ~11 ~15 ~-6 dirt
fill ~-12 ~15 ~-5 ~12 ~15 ~-5 dirt
fill ~-12 ~15 ~-4 ~12 ~15 ~-4 dirt
fill ~-12 ~15 ~-3 ~12 ~15 ~-3 dirt
fill ~-12 ~15 ~-2 ~12 ~15 ~-2 dirt
fill ~-12 ~15 ~-1 ~12 ~15 ~-1 dirt
fill ~-13 ~15 ~ ~13 ~15 ~ dirt
fill ~-12 ~15 ~1 ~12 ~15 ~1 dirt
fill ~-12 ~15 ~2 ~12 ~15 ~2 dirt
fill ~-12 ~15 ~3 ~12 ~15 ~3 dirt
fill ~-12 ~15 ~4 ~12 ~15 ~4 dirt
fill ~-12 ~15 ~5 ~12 ~15 ~5 dirt
fill ~-11 ~15 ~6 ~11 ~15 ~6 dirt
fill ~-10 ~15 ~7 ~10 ~15 ~7 dirt
fill ~-10 ~15 ~8 ~10 ~15 ~8 dirt
fill ~-9 ~15 ~9 ~9 ~15 ~9 dirt
fill ~-8 ~15 ~10 ~8 ~15 ~10 dirt
fill ~-6 ~15 ~11 ~6 ~15 ~11 dirt
fill ~-5 ~15 ~12 ~5 ~15 ~12 dirt
fill ~ ~15 ~13 ~ ~15 ~13 dirt
setblock ~-28 ~ ~9 grass_block
setblock ~-28 ~ ~10 grass_block
setblock ~-28 ~ ~11 grass_block
setblock ~-28 ~ ~12 grass_block
setblock ~-28 ~ ~13 grass_block
setblock ~-28 ~ ~14 grass_block
setblock ~-27 ~ ~5 grass_block
setblock ~-27 ~ ~6 grass_block
setblock ~-27 ~ ~7 grass_block
setblock ~-27 ~ ~8 grass_block
setblock ~-27 ~ ~9 grass_block
setblock ~-27 ~ ~10 andesite
setblock ~-27 ~ ~11 andesite
setblock ~-27 ~ ~12 grass_block
setblock ~-27 ~ ~13 coarse_dirt
setblock ~-27 ~ ~14 grass_block
setblock ~-27 ~ ~15 andesite
setblock ~-27 ~ ~16 grass_block
setblock ~-27 ~ ~17 moss_block
setblock ~-26 ~ ~3 grass_block
setblock ~-26 ~ ~4 grass_block
setblock ~-26 ~ ~5 grass_block
setblock ~-26 ~ ~6 coarse_dirt
setblock ~-26 ~ ~7 andesite
setblock ~-26 ~ ~8 grass_block
setblock ~-26 ~1 ~9 coarse_dirt
setblock ~-26 ~1 ~10 grass_block
setblock ~-26 ~1 ~11 andesite
setblock ~-26 ~1 ~12 grass_block
setblock ~-26 ~1 ~13 grass_block
setblock ~-26 ~1 ~14 grass_block
setblock ~-26 ~ ~15 grass_block
setblock ~-26 ~ ~16 grass_block
setblock ~-26 ~ ~17 grass_block
setblock ~-26 ~ ~18 grass_block
setblock ~-25 ~ ~ coarse_dirt
setblock ~-25 ~ ~1 coarse_dirt
setblock ~-25 ~ ~2 grass_block
setblock ~-25 ~ ~3 coarse_dirt
setblock ~-25 ~ ~4 grass_block
setblock ~-25 ~ ~5 moss_block
setblock ~-25 ~1 ~6 grass_block
setblock ~-25 ~1 ~7 moss_block
setblock ~-25 ~1 ~8 grass_block
setblock ~-25 ~1 ~9 grass_block
setblock ~-25 ~1 ~10 grass_block
setblock ~-25 ~1 ~11 grass_block
setblock ~-25 ~1 ~12 grass_block
setblock ~-25 ~1 ~13 grass_block
setblock ~-25 ~1 ~14 grass_block
setblock ~-25 ~1 ~15 grass_block
setblock ~-25 ~1 ~16 grass_block
setblock ~-25 ~1 ~17 grass_block
setblock ~-25 ~ ~18 grass_block
setblock ~-25 ~ ~19 andesite
setblock ~-24 ~ ~-3 grass_block
setblock ~-24 ~ ~-2 grass_block
setblock ~-24 ~ ~-1 grass_block
setblock ~-24 ~ ~ grass_block
setblock ~-24 ~ ~1 andesite
setblock ~-24 ~ ~2 grass_block
setblock ~-24 ~1 ~3 grass_block
setblock ~-24 ~1 ~4 grass_block
setblock ~-24 ~1 ~5 grass_block
setblock ~-24 ~1 ~6 grass_block
setblock ~-24 ~1 ~7 grass_block
setblock ~-24 ~1 ~8 grass_block
setblock ~-24 ~1 ~9 andesite
setblock ~-24 ~2 ~10 grass_block
setblock ~-24 ~2 ~11 moss_block
setblock ~-24 ~2 ~12 grass_block
setblock ~-24 ~2 ~13 grass_block
setblock ~-24 ~1 ~14 moss_block
setblock ~-24 ~1 ~15 grass_block
setblock ~-24 ~1 ~16 grass_block
setblock ~-24 ~1 ~17 grass_block
setblock ~-24 ~1 ~18 grass_block
setblock ~-24 ~ ~19 grass_block
setblock ~-24 ~ ~20 grass_block
setblock ~-23 ~ ~-11 grass_block
setblock ~-23 ~ ~-10 grass_block
setblock ~-23 ~ ~-9 andesite
setblock ~-23 ~ ~-8 grass_block
setblock ~-23 ~ ~-7 coarse_dirt
setblock ~-23 ~ ~-6 grass_block
setblock ~-23 ~ ~-5 grass_block
setblock ~-23 ~ ~-4 coarse_dirt
setblock ~-23 ~ ~-3 grass_block
setblock ~-23 ~ ~-2 grass_block
setblock ~-23 ~ ~-1 grass_block
setblock ~-23 ~1 ~ grass_block
setblock ~-23 ~1 ~1 grass_block
setblock ~-23 ~1 ~2 grass_block
setblock ~-23 ~1 ~3 grass_block
setblock ~-23 ~1 ~4 grass_block
setblock ~-23 ~1 ~5 grass_block
setblock ~-23 ~2 ~6 grass_block
setblock ~-23 ~2 ~7 grass_block
setblock ~-23 ~2 ~8 grass_block
setblock ~-23 ~2 ~9 grass_block
setblock ~-23 ~2 ~10 grass_block
setblock ~-23 ~2 ~11 andesite
setblock ~-23 ~2 ~12 grass_block
setblock ~-23 ~2 ~13 moss_block
setblock ~-23 ~2 ~14 grass_block
setblock ~-23 ~2 ~15 grass_block
setblock ~-23 ~2 ~16 grass_block
setblock ~-23 ~1 ~17 grass_block
setblock ~-23 ~1 ~18 andesite
setblock ~-23 ~1 ~19 grass_block
setblock ~-23 ~ ~20 grass_block
setblock ~-23 ~ ~21 grass_block
setblock ~-22 ~ ~-16 grass_block
setblock ~-22 ~ ~-15 andesite
setblock ~-22 ~1 ~-14 grass_block
setblock ~-22 ~1 ~-13 coarse_dirt
setblock ~-22 ~1 ~-12 grass_block
setblock ~-22 ~1 ~-11 grass_block
setblock ~-22 ~1 ~-10 grass_block
setblock ~-22 ~1 ~-9 grass_block
setblock ~-22 ~1 ~-8 moss_block
setblock ~-22 ~1 ~-7 grass_block
setblock ~-22 ~1 ~-6 grass_block
setblock ~-22 ~1 ~-5 grass_block
setblock ~-22 ~1 ~-4 grass_block
setblock ~-22 ~1 ~-3 grass_block
setblock ~-22 ~1 ~-2 grass_block
setblock ~-22 ~1 ~-1 grass_block
setblock ~-22 ~1 ~ grass_block
setblock ~-22 ~1 ~1 grass_block
setblock ~-22 ~1 ~2 moss_block
setblock ~-22 ~2 ~3 grass_block
setblock ~-22 ~2 ~4 grass_block
setblock ~-22 ~2 ~5 grass_block
setblock ~-22 ~2 ~6 grass_block
setblock ~-22 ~2 ~7 grass_block
setblock ~-22 ~2 ~8 grass_block
setblock ~-22 ~3 ~9 grass_block
setblock ~-22 ~3 ~10 grass_block
setblock ~-22 ~3 ~11 grass_block
setblock ~-22 ~3 ~12 grass_block
setblock ~-22 ~2 ~13 grass_block
setblock ~-22 ~2 ~14 moss_block
setblock ~-22 ~2 ~15 andesite
setblock ~-22 ~2 ~16 grass_block
setblock ~-22 ~2 ~17 grass_block
setblock ~-22 ~1 ~18 grass_block
setblock ~-22 ~1 ~19 grass_block
setblock ~-22 ~1 ~20 grass_block
setblock ~-22 ~ ~21 grass_block
setblock ~-21 ~ ~-18 grass_block
setblock ~-21 ~1 ~-17 grass_block
setblock ~-21 ~2 ~-16 grass_block
setblock ~-21 ~3 ~-15 grass_block
setblock ~-21 ~4 ~-14 grass_block
setblock ~-21 ~4 ~-13 coarse_dirt
setblock ~-21 ~4 ~-12 grass_block
setblock ~-21 ~5 ~-11 grass_block
setblock ~-21 ~5 ~-10 grass_block
setblock ~-21 ~5 ~-9 grass_block
setblock ~-21 ~4 ~-8 grass_block
setblock ~-21 ~3 ~-7 grass_block
setblock ~-21 ~2 ~-6 andesite
setblock ~-21 ~2 ~-5 grass_block
setblock ~-21 ~2 ~-4 grass_block
setblock ~-21 ~2 ~-3 grass_block
setblock ~-21 ~2 ~-2 grass_block
setblock ~-21 ~2 ~-1 andesite
setblock ~-21 ~2 ~ grass_block
setblock ~-21 ~2 ~1 grass_block
setblock ~-21 ~2 ~2 grass_block
setblock ~-21 ~2 ~3 grass_block
setblock ~-21 ~3 ~4 grass_block
setblock ~-21 ~3 ~5 grass_block
setblock ~-21 ~3 ~6 grass_block
setblock ~-21 ~3 ~7 grass_block
setblock ~-21 ~3 ~8 grass_block
setblock ~-21 ~3 ~9 grass_block
setblock ~-21 ~3 ~10 grass_block
setblock ~-21 ~3 ~11 grass_block
setblock ~-21 ~3 ~12 grass_block
setblock ~-21 ~3 ~13 grass_block
setblock ~-21 ~3 ~14 grass_block
setblock ~-21 ~3 ~15 grass_block
setblock ~-21 ~2 ~16 andesite
setblock ~-21 ~2 ~17 grass_block
setblock ~-21 ~2 ~18 grass_block
setblock ~-21 ~2 ~19 grass_block
setblock ~-21 ~1 ~20 moss_block
setblock ~-21 ~1 ~21 andesite
setblock ~-21 ~ ~22 grass_block
setblock ~-20 ~1 ~-19 moss_block
setblock ~-20 ~2 ~-18 coarse_dirt
setblock ~-20 ~3 ~-17 grass_block
setblock ~-20 ~4 ~-16 grass_block
setblock ~-20 ~4 ~-15 grass_block
setblock ~-20 ~5 ~-14 grass_block
setblock ~-20 ~5 ~-13 grass_block
setblock ~-20 ~6 ~-12 grass_block
setblock ~-20 ~6 ~-11 grass_block
setblock ~-20 ~6 ~-10 grass_block
setblock ~-20 ~6 ~-9 andesite
setblock ~-20 ~6 ~-8 grass_block
setblock ~-20 ~6 ~-7 grass_block
setblock ~-20 ~6 ~-6 grass_block
setblock ~-20 ~6 ~-5 andesite
setblock ~-20 ~4 ~-4 grass_block
setblock ~-20 ~3 ~-3 grass_block
setblock ~-20 ~3 ~-2 coarse_dirt
setblock ~-20 ~3 ~-1 grass_block
setblock ~-20 ~3 ~ grass_block
setblock ~-20 ~3 ~1 grass_block
setblock ~-20 ~3 ~2 grass_block
setblock ~-20 ~3 ~3 grass_block
setblock ~-20 ~3 ~4 grass_block
setblock ~-20 ~3 ~5 grass_block
setblock ~-20 ~4 ~6 moss_block
setblock ~-20 ~4 ~7 grass_block
setblock ~-20 ~4 ~8 grass_block
setblock ~-20 ~4 ~9 grass_block
setblock ~-20 ~4 ~10 grass_block
setblock ~-20 ~4 ~11 grass_block
setblock ~-20 ~4 ~12 grass_block
setblock ~-20 ~3 ~13 grass_block
setblock ~-20 ~3 ~14 grass_block
setblock ~-20 ~3 ~15 grass_block
setblock ~-20 ~3 ~16 grass_block
setblock ~-20 ~3 ~17 grass_block
setblock ~-20 ~2 ~18 grass_block
setblock ~-20 ~2 ~19 grass_block
setblock ~-20 ~1 ~20 grass_block
setblock ~-20 ~1 ~21 grass_block
setblock ~-20 ~ ~22 grass_block
setblock ~-19 ~2 ~-20 grass_block
setblock ~-19 ~3 ~-19 grass_block
setblock ~-19 ~3 ~-18 grass_block
setblock ~-19 ~4 ~-17 grass_block
setblock ~-19 ~5 ~-16 grass_block
setblock ~-19 ~5 ~-15 grass_block
setblock ~-19 ~6 ~-14 grass_block
setblock ~-19 ~6 ~-13 grass_block
setblock ~-19 ~6 ~-12 grass_block
setblock ~-19 ~7 ~-11 grass_block
setblock ~-19 ~7 ~-10 grass_block
setblock ~-19 ~7 ~-9 grass_block
setblock ~-19 ~7 ~-8 andesite
setblock ~-19 ~7 ~-7 grass_block
setblock ~-19 ~8 ~-6 grass_block
setblock ~-19 ~7 ~-5 grass_block
setblock ~-19 ~7 ~-4 andesite
setblock ~-19 ~7 ~-3 grass_block
setblock ~-19 ~6 ~-2 moss_block
setblock ~-19 ~5 ~-1 grass_block
setblock ~-19 ~4 ~ grass_block
setblock ~-19 ~4 ~1 grass_block
setblock ~-19 ~4 ~2 grass_block
setblock ~-19 ~4 ~3 andesite
setblock ~-19 ~4 ~4 grass_block
setblock ~-19 ~4 ~5 grass_block
setblock ~-19 ~4 ~6 grass_block
setblock ~-19 ~4 ~7 grass_block
setblock ~-19 ~4 ~8 coarse_dirt
setblock ~-19 ~4 ~9 moss_block
setblock ~-19 ~4 ~10 grass_block
setblock ~-19 ~4 ~11 moss_block
setblock ~-19 ~4 ~12 grass_block
setblock ~-19 ~4 ~13 grass_block
setblock ~-19 ~4 ~14 moss_block
setblock ~-19 ~3 ~15 grass_block
setblock ~-19 ~3 ~16 grass_block
setblock ~-19 ~3 ~17 grass_block
setblock ~-19 ~3 ~18 grass_block
setblock ~-19 ~2 ~19 grass_block
setblock ~-19 ~2 ~20 grass_block
setblock ~-19 ~1 ~21 grass_block
setblock ~-19 ~1 ~22 coarse_dirt
setblock ~-19 ~ ~23 grass_block
setblock ~-18 ~2 ~-21 grass_block
setblock ~-18 ~3 ~-20 grass_block
setblock ~-18 ~3 ~-19 grass_block
setblock ~-18 ~4 ~-18 grass_block
setblock ~-18 ~5 ~-17 grass_block
setblock ~-18 ~5 ~-16 moss_block
setblock ~-18 ~6 ~-15 grass_block
setblock ~-18 ~6 ~-14 grass_block
setblock ~-18 ~7 ~-13 grass_block
setblock ~-18 ~7 ~-12 grass_block
setblock ~-18 ~7 ~-11 grass_block
setblock ~-18 ~8 ~-10 grass_block
setblock ~-18 ~8 ~-9 grass_block
setblock ~-18 ~8 ~-8 moss_block
setblock ~-18 ~8 ~-7 grass_block
setblock ~-18 ~8 ~-6 grass_block
setblock ~-18 ~9 ~-5 grass_block
setblock ~-18 ~9 ~-4 grass_block
setblock ~-18 ~9 ~-3 coarse_dirt
setblock ~-18 ~8 ~-2 grass_block
setblock ~-18 ~8 ~-1 grass_block
setblock ~-18 ~8 ~ grass_block
setblock ~-18 ~8 ~1 grass_block
setblock ~-18 ~7 ~2 grass_block
setblock ~-18 ~6 ~3 grass_block
setblock ~-18 ~6 ~4 grass_block
setblock ~-18 ~6 ~5 grass_block
setblock ~-18 ~5 ~6 grass_block
setblock ~-18 ~5 ~7 grass_block
setblock ~-18 ~5 ~8 grass_block
setblock ~-18 ~5 ~9 grass_block
setblock ~-18 ~5 ~10 grass_block
setblock ~-18 ~5 ~11 moss_block
setblock ~-18 ~5 ~12 grass_block
setblock ~-18 ~4 ~13 grass_block
setblock ~-18 ~4 ~14 grass_block
setblock ~-18 ~4 ~15 grass_block
setblock ~-18 ~4 ~16 grass_block
setblock ~-18 ~3 ~17 moss_block
setblock ~-18 ~3 ~18 grass_block
setblock ~-18 ~3 ~19 grass_block
setblock ~-18 ~2 ~20 grass_block
setblock ~-18 ~2 ~21 grass_block
setblock ~-18 ~1 ~22 coarse_dirt
setblock ~-18 ~ ~23 grass_block
setblock ~-17 ~1 ~-22 grass_block
setblock ~-17 ~2 ~-21 andesite
setblock ~-17 ~3 ~-20 grass_block
setblock ~-17 ~4 ~-19 grass_block
setblock ~-17 ~5 ~-18 coarse_dirt
setblock ~-17 ~5 ~-17 grass_block
setblock ~-17 ~6 ~-16 moss_block
setblock ~-17 ~6 ~-15 grass_block
setblock ~-17 ~7 ~-14 grass_block
setblock ~-17 ~7 ~-13 grass_block
setblock ~-17 ~8 ~-12 grass_block
setblock ~-17 ~8 ~-11 andesite
setblock ~-17 ~8 ~-10 grass_block
setblock ~-17 ~9 ~-9 grass_block
setblock ~-17 ~9 ~-8 andesite
setblock ~-17 ~9 ~-7 grass_block
setblock ~-17 ~9 ~-6 grass_block
setblock ~-17 ~9 ~-5 moss_block
setblock ~-17 ~9 ~-4 grass_block
setblock ~-17 ~10 ~-3 grass_block
setblock ~-17 ~10 ~-2 grass_block
setblock ~-17 ~10 ~-1 grass_block
setblock ~-17 ~10 ~ grass_block
setblock ~-17 ~10 ~1 moss_block
setblock ~-17 ~10 ~2 moss_block
setblock ~-17 ~9 ~3 moss_block
setblock ~-17 ~9 ~4 grass_block
setblock ~-17 ~8 ~5 coarse_dirt
setblock ~-17 ~7 ~6 andesite
setblock ~-17 ~7 ~7 grass_block
setblock ~-17 ~6 ~8 grass_block
setblock ~-17 ~6 ~9 grass_block
setblock ~-17 ~6 ~10 grass_block
setblock ~-17 ~5 ~11 grass_block
setblock ~-17 ~5 ~12 grass_block
setblock ~-17 ~5 ~13 coarse_dirt
setblock ~-17 ~5 ~14 grass_block
setblock ~-17 ~4 ~15 grass_block
setblock ~-17 ~4 ~16 grass_block
setblock ~-17 ~4 ~17 grass_block
setblock ~-17 ~3 ~18 grass_block
setblock ~-17 ~3 ~19 grass_block
setblock ~-17 ~2 ~20 grass_block
setblock ~-17 ~2 ~21 grass_block
setblock ~-17 ~1 ~22 grass_block
setblock ~-17 ~ ~23 grass_block
setblock ~-16 ~1 ~-23 grass_block
setblock ~-16 ~2 ~-22 grass_block
setblock ~-16 ~3 ~-21 grass_block
setblock ~-16 ~4 ~-20 moss_block
setblock ~-16 ~4 ~-19 grass_block
setblock ~-16 ~5 ~-18 grass_block
setblock ~-16 ~5 ~-17 grass_block
setblock ~-16 ~6 ~-16 grass_block
setblock ~-16 ~7 ~-15 grass_block
setblock ~-16 ~7 ~-14 grass_block
setblock ~-16 ~8 ~-13 grass_block
setblock ~-16 ~8 ~-12 andesite
setblock ~-16 ~8 ~-11 grass_block
setblock ~-16 ~9 ~-10 grass_block
setblock ~-16 ~9 ~-9 andesite
setblock ~-16 ~9 ~-8 grass_block
setblock ~-16 ~10 ~-7 grass_block
setblock ~-16 ~10 ~-6 grass_block
setblock ~-16 ~10 ~-5 grass_block
setblock ~-16 ~10 ~-4 coarse_dirt
setblock ~-16 ~10 ~-3 andesite
setblock ~-16 ~11 ~-2 grass_block
setblock ~-16 ~11 ~-1 grass_block
setblock ~-16 ~11 ~ grass_block
setblock ~-16 ~11 ~1 grass_block
setblock ~-16 ~11 ~2 grass_block
setblock ~-16 ~11 ~3 grass_block
setblock ~-16 ~11 ~4 grass_block
setblock ~-16 ~11 ~5 grass_block
setblock ~-16 ~10 ~6 coarse_dirt
setblock ~-16 ~9 ~7 grass_block
setblock ~-16 ~8 ~8 grass_block
setblock ~-16 ~7 ~9 grass_block
setblock ~-16 ~6 ~10 grass_block
setblock ~-16 ~6 ~11 moss_block
setblock ~-16 ~6 ~12 grass_block
setblock ~-16 ~5 ~13 grass_block
setblock ~-16 ~5 ~14 grass_block
setblock ~-16 ~5 ~15 grass_block
setblock ~-16 ~4 ~16 grass_block
setblock ~-16 ~4 ~17 grass_block
setblock ~-16 ~4 ~18 coarse_dirt
setblock ~-16 ~3 ~19 moss_block
setblock ~-16 ~3 ~20 coarse_dirt
setblock ~-16 ~2 ~21 moss_block
setblock ~-16 ~2 ~22 grass_block
setblock ~-16 ~1 ~23 grass_block
setblock ~-15 ~ ~-24 grass_block
setblock ~-15 ~1 ~-23 grass_block
setblock ~-15 ~2 ~-22 grass_block
setblock ~-15 ~3 ~-21 grass_block
setblock ~-15 ~4 ~-20 grass_block
setblock ~-15 ~5 ~-19 andesite
setblock ~-15 ~5 ~-18 grass_block
setblock ~-15 ~6 ~-17 grass_block
setblock ~-15 ~6 ~-16 grass_block
setblock ~-15 ~7 ~-15 grass_block
setblock ~-15 ~7 ~-14 grass_block
setblock ~-15 ~8 ~-13 grass_block
setblock ~-15 ~8 ~-12 andesite
setblock ~-15 ~9 ~-11 grass_block
setblock ~-15 ~9 ~-10 grass_block
setblock ~-15 ~10 ~-9 grass_block
setblock ~-15 ~10 ~-8 grass_block
setblock ~-15 ~10 ~-7 grass_block
setblock ~-15 ~11 ~-6 grass_block
setblock ~-15 ~11 ~-5 moss_block
setblock ~-15 ~11 ~-4 grass_block
setblock ~-15 ~11 ~-3 grass_block
setblock ~-15 ~11 ~-2 grass_block
setblock ~-15 ~12 ~-1 andesite
setblock ~-15 ~12 ~ grass_block
setblock ~-15 ~12 ~1 grass_block
setblock ~-15 ~12 ~2 grass_block
setblock ~-15 ~12 ~3 grass_block
setblock ~-15 ~12 ~4 grass_block
setblock ~-15 ~12 ~5 andesite
setblock ~-15 ~12 ~6 andesite
setblock ~-15 ~11 ~7 grass_block
setblock ~-15 ~10 ~8 grass_block
setblock ~-15 ~8 ~9 grass_block
setblock ~-15 ~7 ~10 grass_block
setblock ~-15 ~7 ~11 grass_block
setblock ~-15 ~6 ~12 grass_block
setblock ~-15 ~6 ~13 grass_block
setblock ~-15 ~5 ~14 grass_block
setblock ~-15 ~5 ~15 grass_block
setblock ~-15 ~5 ~16 grass_block
setblock ~-15 ~4 ~17 grass_block
setblock ~-15 ~4 ~18 grass_block
setblock ~-15 ~4 ~19 grass_block
setblock ~-15 ~3 ~20 grass_block
setblock ~-15 ~3 ~21 grass_block
setblock ~-15 ~2 ~22 grass_block
setblock ~-15 ~1 ~23 grass_block
setblock ~-14 ~1 ~-24 grass_block
setblock ~-14 ~2 ~-23 grass_block
setblock ~-14 ~3 ~-22 grass_block
setblock ~-14 ~3 ~-21 grass_block
setblock ~-14 ~4 ~-20 grass_block
setblock ~-14 ~5 ~-19 grass_block
setblock ~-14 ~5 ~-18 grass_block
setblock ~-14 ~6 ~-17 grass_block
setblock ~-14 ~6 ~-16 grass_block
setblock ~-14 ~7 ~-15 moss_block
setblock ~-14 ~8 ~-14 grass_block
setblock ~-14 ~8 ~-13 grass_block
setblock ~-14 ~9 ~-12 grass_block
setblock ~-14 ~9 ~-11 grass_block
setblock ~-14 ~10 ~-10 grass_block
setblock ~-14 ~10 ~-9 moss_block
setblock ~-14 ~11 ~-8 andesite
setblock ~-14 ~11 ~-7 coarse_dirt
setblock ~-14 ~11 ~-6 coarse_dirt
setblock ~-14 ~11 ~-5 moss_block
setblock ~-14 ~12 ~-4 grass_block
setblock ~-14 ~12 ~-3 grass_block
setblock ~-14 ~12 ~-2 grass_block
setblock ~-14 ~13 ~-1 grass_block
setblock ~-14 ~13 ~ grass_block
setblock ~-14 ~13 ~1 grass_block
setblock ~-14 ~12 ~2 grass_block
setblock ~-14 ~12 ~3 grass_block
setblock ~-14 ~12 ~4 grass_block
setblock ~-14 ~12 ~5 coarse_dirt
setblock ~-14 ~12 ~6 grass_block
setblock ~-14 ~12 ~7 moss_block
setblock ~-14 ~12 ~8 grass_block
setblock ~-14 ~10 ~9 grass_block
setblock ~-14 ~8 ~10 grass_block
setblock ~-14 ~7 ~11 grass_block
setblock ~-14 ~7 ~12 moss_block
setblock ~-14 ~6 ~13 grass_block
setblock ~-14 ~6 ~14 grass_block
setblock ~-14 ~5 ~15 grass_block
setblock ~-14 ~5 ~16 grass_block
setblock ~-14 ~5 ~17 grass_block
setblock ~-14 ~4 ~18 grass_block
setblock ~-14 ~4 ~19 grass_block
setblock ~-14 ~3 ~20 grass_block
setblock ~-14 ~3 ~21 grass_block
setblock ~-14 ~2 ~22 grass_block
setblock ~-14 ~1 ~23 grass_block
setblock ~-13 ~ ~-25 grass_block
setblock ~-13 ~1 ~-24 grass_block
setblock ~-13 ~2 ~-23 coarse_dirt
setblock ~-13 ~3 ~-22 grass_block
setblock ~-13 ~4 ~-21 grass_block
setblock ~-13 ~4 ~-20 grass_block
setblock ~-13 ~5 ~-19 coarse_dirt
setblock ~-13 ~5 ~-18 grass_block
setblock ~-13 ~6 ~-17 grass_block
setblock ~-13 ~7 ~-16 grass_block
setblock ~-13 ~7 ~-15 grass_block
setblock ~-13 ~8 ~-14 grass_block
setblock ~-13 ~8 ~-13 coarse_dirt
setblock ~-13 ~9 ~-12 grass_block
setblock ~-13 ~10 ~-11 grass_block
setblock ~-13 ~10 ~-10 grass_block
setblock ~-13 ~11 ~-9 grass_block
setblock ~-13 ~11 ~-8 grass_block
setblock ~-13 ~11 ~-7 grass_block
setblock ~-13 ~12 ~-6 moss_block
setblock ~-13 ~13 ~-5 grass_block
setblock ~-13 ~13 ~-4 grass_block
setblock ~-13 ~14 ~-3 grass_block
setblock ~-13 ~14 ~-2 grass_block
setblock ~-13 ~14 ~-1 grass_block
setblock ~-13 ~15 ~ grass_block
setblock ~-13 ~14 ~1 grass_block
setblock ~-13 ~14 ~2 grass_block
setblock ~-13 ~14 ~3 grass_block
setblock ~-13 ~13 ~4 grass_block
setblock ~-13 ~13 ~5 grass_block
setblock ~-13 ~12 ~6 andesite
setblock ~-13 ~12 ~7 grass_block
setblock ~-13 ~12 ~8 grass_block
setblock ~-13 ~12 ~9 grass_block
setblock ~-13 ~9 ~10 andesite
setblock ~-13 ~8 ~11 grass_block
setblock ~-13 ~7 ~12 moss_block
setblock ~-13 ~7 ~13 grass_block
setblock ~-13 ~6 ~14 grass_block
setblock ~-13 ~6 ~15 grass_block
setblock ~-13 ~5 ~16 grass_block
setblock ~-13 ~5 ~17 grass_block
setblock ~-13 ~5 ~18 grass_block
setblock ~-13 ~4 ~19 coarse_dirt
setblock ~-13 ~4 ~20 grass_block
setblock ~-13 ~3 ~21 grass_block
setblock ~-13 ~2 ~22 grass_block
setblock ~-13 ~1 ~23 grass_block
setblock ~-12 ~1 ~-25 grass_block
setblock ~-12 ~2 ~-24 grass_block
setblock ~-12 ~2 ~-23 grass_block
setblock ~-12 ~3 ~-22 grass_block
setblock ~-12 ~4 ~-21 grass_block
setblock ~-12 ~4 ~-20 grass_block
setblock ~-12 ~5 ~-19 grass_block
setblock ~-12 ~6 ~-18 moss_block
setblock ~-12 ~6 ~-17 moss_block
setblock ~-12 ~7 ~-16 grass_block
setblock ~-12 ~7 ~-15 grass_block
setblock ~-12 ~8 ~-14 grass_block
setblock ~-12 ~9 ~-13 grass_block
setblock ~-12 ~9 ~-12 grass_block
setblock ~-12 ~10 ~-11 moss_block
setblock ~-12 ~11 ~-10 moss_block
setblock ~-12 ~11 ~-9 grass_block
setblock ~-12 ~12 ~-8 grass_block
setblock ~-12 ~13 ~-7 grass_block
setblock ~-12 ~14 ~-6 grass_block
setblock ~-12 ~15 ~-5 grass_block
setblock ~-12 ~15 ~-4 grass_block
setblock ~-12 ~15 ~-3 grass_block
setblock ~-12 ~15 ~-2 grass_block
setblock ~-12 ~15 ~-1 grass_block
setblock ~-12 ~15 ~ grass_block
setblock ~-12 ~15 ~1 grass_block
setblock ~-12 ~15 ~2 grass_block
setblock ~-12 ~15 ~3 grass_block
setblock ~-12 ~15 ~4 grass_block
setblock ~-12 ~15 ~5 grass_block
setblock ~-12 ~14 ~6 grass_block
setblock ~-12 ~13 ~7 grass_block
setblock ~-12 ~12 ~8 moss_block
setblock ~-12 ~12 ~9 grass_block
setblock ~-12 ~11 ~10 coarse_dirt
setblock ~-12 ~9 ~11 grass_block
setblock ~-12 ~8 ~12 grass_block
setblock ~-12 ~7 ~13 grass_block
setblock ~-12 ~7 ~14 grass_block
setblock ~-12 ~6 ~15 grass_block
setblock ~-12 ~6 ~16 grass_block
setblock ~-12 ~5 ~17 grass_block
setblock ~-12 ~5 ~18 grass_block
setblock ~-12 ~4 ~19 grass_block
setblock ~-12 ~4 ~20 moss_block
setblock ~-12 ~3 ~21 grass_block
setblock ~-12 ~3 ~22 grass_block
setblock ~-12 ~2 ~23 grass_block
setblock ~-12 ~ ~24 grass_block
setblock ~-11 ~ ~-26 grass_block
setblock ~-11 ~1 ~-25 grass_block
setblock ~-11 ~2 ~-24 grass_block
setblock ~-11 ~2 ~-23 grass_block
setblock ~-11 ~3 ~-22 grass_block
setblock ~-11 ~4 ~-21 grass_block
setblock ~-11 ~4 ~-20 grass_block
setblock ~-11 ~5 ~-19 andesite
setblock ~-11 ~6 ~-18 grass_block
setblock ~-11 ~6 ~-17 grass_block
setblock ~-11 ~7 ~-16 grass_block
setblock ~-11 ~7 ~-15 andesite
setblock ~-11 ~8 ~-14 grass_block
setblock ~-11 ~9 ~-13 andesite
setblock ~-11 ~10 ~-12 grass_block
setblock ~-11 ~10 ~-11 grass_block
setblock ~-11 ~11 ~-10 grass_block
setblock ~-11 ~12 ~-9 grass_block
setblock ~-11 ~13 ~-8 moss_block
setblock ~-11 ~14 ~-7 moss_block
setblock ~-11 ~15 ~-6 grass_block
setblock ~-11 ~15 ~-5 grass_block
setblock ~-11 ~15 ~-4 grass_block
setblock ~-11 ~15 ~-3 grass_block
setblock ~-11 ~15 ~-2 grass_block
setblock ~-11 ~15 ~-1 grass_block
setblock ~-11 ~15 ~ grass_block
setblock ~-11 ~15 ~1 grass_block
setblock ~-11 ~15 ~2 grass_block
setblock ~-11 ~15 ~3 grass_block
setblock ~-11 ~15 ~4 grass_block
setblock ~-11 ~15 ~5 grass_block
setblock ~-11 ~15 ~6 grass_block
setblock ~-11 ~14 ~7 grass_block
setblock ~-11 ~13 ~8 grass_block
setblock ~-11 ~12 ~9 grass_block
setblock ~-11 ~12 ~10 grass_block
setblock ~-11 ~9 ~11 grass_block
setblock ~-11 ~8 ~12 grass_block
setblock ~-11 ~7 ~13 grass_block
setblock ~-11 ~7 ~14 coarse_dirt
setblock ~-11 ~6 ~15 grass_block
setblock ~-11 ~6 ~16 andesite
setblock ~-11 ~6 ~17 coarse_dirt
setblock ~-11 ~5 ~18 grass_block
setblock ~-11 ~5 ~19 grass_block
setblock ~-11 ~4 ~20 grass_block
setblock ~-11 ~4 ~21 grass_block
setblock ~-11 ~3 ~22 grass_block
setblock ~-11 ~2 ~23 moss_block
setblock ~-11 ~ ~24 grass_block
setblock ~-10 ~ ~-26 grass_block
setblock ~-10 ~1 ~-25 grass_block
setblock ~-10 ~2 ~-24 grass_block
setblock ~-10 ~3 ~-23 grass_block
setblock ~-10 ~3 ~-22 grass_block
setblock ~-10 ~4 ~-21 coarse_dirt
setblock ~-10 ~4 ~-20 grass_block
setblock ~-10 ~5 ~-19 moss_block
setblock ~-10 ~6 ~-18 grass_block
setblock ~-10 ~6 ~-17 coarse_dirt
setblock ~-10 ~7 ~-16 grass_block
setblock ~-10 ~8 ~-15 grass_block
setblock ~-10 ~8 ~-14 grass_block
setblock ~-10 ~9 ~-13 coarse_dirt
setblock ~-10 ~10 ~-12 grass_block
setblock ~-10 ~11 ~-11 andesite
setblock ~-10 ~12 ~-10 grass_block
setblock ~-10 ~13 ~-9 coarse_dirt
setblock ~-10 ~15 ~-8 grass_block
setblock ~-10 ~15 ~-7 grass_block
setblock ~-10 ~15 ~-6 grass_block
setblock ~-10 ~15 ~-5 grass_block
setblock ~-10 ~15 ~-4 grass_block
setblock ~-10 ~15 ~-3 grass_block
setblock ~-10 ~15 ~-2 grass_block
setblock ~-10 ~15 ~-1 grass_block
setblock ~-10 ~15 ~ grass_block
setblock ~-10 ~15 ~1 grass_block
setblock ~-10 ~15 ~2 grass_block
setblock ~-10 ~15 ~3 grass_block
setblock ~-10 ~15 ~4 grass_block
setblock ~-10 ~15 ~5 grass_block
setblock ~-10 ~15 ~6 grass_block
setblock ~-10 ~15 ~7 grass_block
setblock ~-10 ~15 ~8 grass_block
setblock ~-10 ~13 ~9 grass_block
setblock ~-10 ~12 ~10 grass_block
setblock ~-10 ~10 ~11 andesite
setblock ~-10 ~9 ~12 grass_block
setblock ~-10 ~8 ~13 grass_block
setblock ~-10 ~7 ~14 grass_block
setblock ~-10 ~7 ~15 grass_block
setblock ~-10 ~6 ~16 grass_block
setblock ~-10 ~6 ~17 grass_block
setblock ~-10 ~5 ~18 grass_block
setblock ~-10 ~5 ~19 grass_block
setblock ~-10 ~4 ~20 grass_block
setblock ~-10 ~4 ~21 grass_block
setblock ~-10 ~3 ~22 grass_block
setblock ~-10 ~2 ~23 andesite
setblock ~-10 ~ ~24 coarse_dirt
setblock ~-9 ~ ~-27 grass_block
setblock ~-9 ~1 ~-26 grass_block
setblock ~-9 ~1 ~-25 andesite
setblock ~-9 ~2 ~-24 grass_block
setblock ~-9 ~3 ~-23 grass_block
setblock ~-9 ~3 ~-22 grass_block
setblock ~-9 ~4 ~-21 andesite
setblock ~-9 ~4 ~-20 grass_block
setblock ~-9 ~5 ~-19 grass_block
setblock ~-9 ~6 ~-18 grass_block
setblock ~-9 ~6 ~-17 coarse_dirt
setblock ~-9 ~7 ~-16 grass_block
setblock ~-9 ~8 ~-15 grass_block
setblock ~-9 ~8 ~-14 grass_block
setblock ~-9 ~9 ~-13 moss_block
setblock ~-9 ~10 ~-12 grass_block
setblock ~-9 ~11 ~-11 grass_block
setblock ~-9 ~13 ~-10 grass_block
setblock ~-9 ~15 ~-9 grass_block
setblock ~-9 ~15 ~-8 grass_block
setblock ~-9 ~15 ~-7 grass_block
setblock ~-9 ~15 ~-6 grass_block
setblock ~-9 ~15 ~-5 grass_block
setblock ~-9 ~15 ~-4 grass_block
setblock ~-9 ~15 ~-3 grass_block
setblock ~-9 ~15 ~-2 grass_block
setblock ~-9 ~15 ~-1 grass_block
setblock ~-9 ~15 ~ grass_block
setblock ~-9 ~15 ~1 grass_block
setblock ~-9 ~15 ~2 grass_block
setblock ~-9 ~15 ~3 grass_block
setblock ~-9 ~15 ~4 grass_block
setblock ~-9 ~15 ~5 grass_block
setblock ~-9 ~15 ~6 grass_block
setblock ~-9 ~15 ~7 grass_block
setblock ~-9 ~15 ~8 grass_block
setblock ~-9 ~15 ~9 grass_block
setblock ~-9 ~13 ~10 andesite
setblock ~-9 ~11 ~11 moss_block
setblock ~-9 ~9 ~12 moss_block
setblock ~-9 ~8 ~13 grass_block
setblock ~-9 ~8 ~14 grass_block
setblock ~-9 ~7 ~15 grass_block
setblock ~-9 ~7 ~16 grass_block
setblock ~-9 ~6 ~17 grass_block
setblock ~-9 ~6 ~18 grass_block
setblock ~-9 ~5 ~19 grass_block
setblock ~-9 ~5 ~20 grass_block
setblock ~-9 ~4 ~21 coarse_dirt
setblock ~-9 ~3 ~22 moss_block
setblock ~-9 ~3 ~23 grass_block
setblock ~-9 ~1 ~24 grass_block
setblock ~-8 ~ ~-27 grass_block
setblock ~-8 ~1 ~-26 grass_block
setblock ~-8 ~1 ~-25 grass_block
setblock ~-8 ~2 ~-24 grass_block
setblock ~-8 ~3 ~-23 andesite
setblock ~-8 ~3 ~-22 grass_block
setblock ~-8 ~4 ~-21 grass_block
setblock ~-8 ~4 ~-20 moss_block
setblock ~-8 ~5 ~-19 grass_block
setblock ~-8 ~6 ~-18 grass_block
setblock ~-8 ~6 ~-17 grass_block
setblock ~-8 ~7 ~-16 grass_block
setblock ~-8 ~8 ~-15 grass_block
setblock ~-8 ~8 ~-14 grass_block
setblock ~-8 ~9 ~-13 grass_block
setblock ~-8 ~10 ~-12 grass_block
setblock ~-8 ~13 ~-11 grass_block
setblock ~-8 ~15 ~-10 grass_block
setblock ~-8 ~15 ~-9 grass_block
setblock ~-8 ~15 ~-8 grass_block
setblock ~-8 ~15 ~-7 grass_block
setblock ~-8 ~15 ~-6 grass_block
setblock ~-8 ~15 ~-5 grass_block
setblock ~-8 ~15 ~-4 grass_block
setblock ~-8 ~15 ~-3 grass_block
setblock ~-8 ~15 ~-2 grass_block
setblock ~-8 ~15 ~-1 grass_block
setblock ~-8 ~15 ~ grass_block
setblock ~-8 ~15 ~1 grass_block
setblock ~-8 ~15 ~2 grass_block
setblock ~-8 ~15 ~3 grass_block
setblock ~-8 ~15 ~4 grass_block
setblock ~-8 ~15 ~5 grass_block
setblock ~-8 ~15 ~6 grass_block
setblock ~-8 ~15 ~7 grass_block
setblock ~-8 ~15 ~8 grass_block
setblock ~-8 ~15 ~9 grass_block
setblock ~-8 ~15 ~10 grass_block
setblock ~-8 ~13 ~11 grass_block
setblock ~-8 ~10 ~12 grass_block
setblock ~-8 ~9 ~13 moss_block
setblock ~-8 ~8 ~14 grass_block
setblock ~-8 ~7 ~15 grass_block
setblock ~-8 ~7 ~16 grass_block
setblock ~-8 ~6 ~17 grass_block
setblock ~-8 ~6 ~18 grass_block
setblock ~-8 ~6 ~19 andesite
setblock ~-8 ~5 ~20 grass_block
setblock ~-8 ~4 ~21 grass_block
setblock ~-8 ~4 ~22 grass_block
setblock ~-8 ~3 ~23 grass_block
setblock ~-8 ~1 ~24 grass_block
setblock ~-7 ~ ~-27 grass_block
setblock ~-7 ~1 ~-26 grass_block
setblock ~-7 ~2 ~-25 grass_block
setblock ~-7 ~2 ~-24 grass_block
setblock ~-7 ~3 ~-23 grass_block
setblock ~-7 ~3 ~-22 grass_block
setblock ~-7 ~4 ~-21 grass_block
setblock ~-7 ~4 ~-20 grass_block
setblock ~-7 ~5 ~-19 grass_block
setblock ~-7 ~5 ~-18 moss_block
setblock ~-7 ~6 ~-17 grass_block
setblock ~-7 ~7 ~-16 grass_block
setblock ~-7 ~7 ~-15 moss_block
setblock ~-7 ~8 ~-14 grass_block
setblock ~-7 ~9 ~-13 grass_block
setblock ~-7 ~13 ~-12 andesite
setblock ~-7 ~14 ~-11 grass_block
setblock ~-7 ~15 ~-10 grass_block
setblock ~-7 ~15 ~-9 grass_block
setblock ~-7 ~15 ~-8 grass_block
setblock ~-7 ~15 ~-7 grass_block
setblock ~-7 ~15 ~-6 grass_block
setblock ~-7 ~15 ~-5 grass_block
setblock ~-7 ~15 ~-4 grass_block
setblock ~-7 ~15 ~-3 grass_block
setblock ~-7 ~15 ~-2 grass_block
setblock ~-7 ~15 ~-1 grass_block
setblock ~-7 ~15 ~ grass_block
setblock ~-7 ~15 ~1 grass_block
setblock ~-7 ~15 ~2 grass_block
setblock ~-7 ~15 ~3 grass_block
setblock ~-7 ~15 ~4 grass_block
setblock ~-7 ~15 ~5 grass_block
setblock ~-7 ~15 ~6 grass_block
setblock ~-7 ~15 ~7 grass_block
setblock ~-7 ~15 ~8 grass_block
setblock ~-7 ~15 ~9 grass_block
setblock ~-7 ~15 ~10 grass_block
setblock ~-7 ~14 ~11 grass_block
setblock ~-7 ~13 ~12 grass_block
setblock ~-7 ~9 ~13 grass_block
setblock ~-7 ~8 ~14 grass_block
setblock ~-7 ~8 ~15 grass_block
setblock ~-7 ~7 ~16 grass_block
setblock ~-7 ~7 ~17 grass_block
setblock ~-7 ~6 ~18 grass_block
setblock ~-7 ~6 ~19 andesite
setblock ~-7 ~5 ~20 grass_block
setblock ~-7 ~5 ~21 coarse_dirt
setblock ~-7 ~4 ~22 grass_block
setblock ~-7 ~3 ~23 grass_block
setblock ~-7 ~2 ~24 grass_block
setblock ~-6 ~ ~-28 grass_block
setblock ~-6 ~ ~-27 grass_block
setblock ~-6 ~1 ~-26 grass_block
setblock ~-6 ~2 ~-25 grass_block
setblock ~-6 ~2 ~-24 moss_block
setblock ~-6 ~3 ~-23 grass_block
setblock ~-6 ~3 ~-22 grass_block
setblock ~-6 ~4 ~-21 coarse_dirt
setblock ~-6 ~4 ~-20 grass_block
setblock ~-6 ~5 ~-19 grass_block
setblock ~-6 ~5 ~-18 grass_block
setblock ~-6 ~6 ~-17 grass_block
setblock ~-6 ~7 ~-16 grass_block
setblock ~-6 ~7 ~-15 grass_block
setblock ~-6 ~8 ~-14 grass_block
setblock ~-6 ~9 ~-13 grass_block
setblock ~-6 ~14 ~-12 moss_block
setblock ~-6 ~15 ~-11 grass_block
setblock ~-6 ~15 ~-10 grass_block
setblock ~-6 ~15 ~-9 grass_block
setblock ~-6 ~15 ~-8 grass_block
setblock ~-6 ~15 ~-7 grass_block
setblock ~-6 ~15 ~-6 grass_block
setblock ~-6 ~15 ~-5 grass_block
setblock ~-6 ~15 ~-4 grass_block
setblock ~-6 ~15 ~-3 grass_block
setblock ~-6 ~15 ~-2 grass_block
setblock ~-6 ~15 ~-1 grass_block
setblock ~-6 ~15 ~ grass_block
setblock ~-6 ~15 ~1 grass_block
setblock ~-6 ~15 ~2 grass_block
setblock ~-6 ~15 ~3 grass_block
setblock ~-6 ~15 ~4 grass_block
setblock ~-6 ~15 ~5 grass_block
setblock ~-6 ~15 ~6 grass_block
setblock ~-6 ~15 ~7 grass_block
setblock ~-6 ~15 ~8 grass_block
setblock ~-6 ~15 ~9 grass_block
setblock ~-6 ~15 ~10 grass_block
setblock ~-6 ~15 ~11 grass_block
setblock ~-6 ~14 ~12 grass_block
setblock ~-6 ~9 ~13 andesite
setblock ~-6 ~9 ~14 moss_block
setblock ~-6 ~8 ~15 grass_block
setblock ~-6 ~8 ~16 grass_block
setblock ~-6 ~7 ~17 grass_block
setblock ~-6 ~7 ~18 grass_block
setblock ~-6 ~6 ~19 grass_block
setblock ~-6 ~6 ~20 grass_block
setblock ~-6 ~5 ~21 andesite
setblock ~-6 ~4 ~22 coarse_dirt
setblock ~-6 ~4 ~23 andesite
setblock ~-6 ~2 ~24 grass_block
setblock ~-5 ~ ~-28 grass_block
setblock ~-5 ~1 ~-27 grass_block
setblock ~-5 ~1 ~-26 grass_block
setblock ~-5 ~2 ~-25 grass_block
setblock ~-5 ~2 ~-24 andesite
setblock ~-5 ~3 ~-23 grass_block
setblock ~-5 ~3 ~-22 moss_block
setblock ~-5 ~4 ~-21 grass_block
setblock ~-5 ~4 ~-20 grass_block
setblock ~-5 ~5 ~-19 grass_block
setblock ~-5 ~5 ~-18 grass_block
setblock ~-5 ~6 ~-17 grass_block
setblock ~-5 ~7 ~-16 grass_block
setblock ~-5 ~7 ~-15 grass_block
setblock ~-5 ~8 ~-14 coarse_dirt
setblock ~-5 ~13 ~-13 grass_block
setblock ~-5 ~15 ~-12 grass_block
setblock ~-5 ~15 ~-11 grass_block
setblock ~-5 ~15 ~-10 grass_block
setblock ~-5 ~15 ~-9 grass_block
setblock ~-5 ~15 ~-8 grass_block
setblock ~-5 ~15 ~-7 grass_block
setblock ~-5 ~15 ~-6 grass_block
setblock ~-5 ~15 ~-5 grass_block
setblock ~-5 ~15 ~-4 grass_block
setblock ~-5 ~15 ~-3 grass_block
setblock ~-5 ~15 ~-2 grass_block
setblock ~-5 ~15 ~-1 grass_block
setblock ~-5 ~15 ~ grass_block
setblock ~-5 ~15 ~1 grass_block
setblock ~-5 ~15 ~2 grass_block
setblock ~-5 ~15 ~3 grass_block
setblock ~-5 ~15 ~4 grass_block
setblock ~-5 ~15 ~5 grass_block
setblock ~-5 ~15 ~6 grass_block
setblock ~-5 ~15 ~7 grass_block
setblock ~-5 ~15 ~8 grass_block
setblock ~-5 ~15 ~9 grass_block
setblock ~-5 ~15 ~10 grass_block
setblock ~-5 ~15 ~11 grass_block
setblock ~-5 ~15 ~12 grass_block
setblock ~-5 ~13 ~13 grass_block
setblock ~-5 ~9 ~14 grass_block
setblock ~-5 ~9 ~15 grass_block
setblock ~-5 ~8 ~16 andesite
setblock ~-5 ~8 ~17 coarse_dirt
setblock ~-5 ~7 ~18 grass_block
setblock ~-5 ~7 ~19 grass_block
setblock ~-5 ~6 ~20 grass_block
setblock ~-5 ~5 ~21 grass_block
setblock ~-5 ~5 ~22 grass_block
setblock ~-5 ~4 ~23 moss_block
setblock ~-5 ~2 ~24 grass_block
setblock ~-4 ~ ~-28 grass_block
setblock ~-4 ~1 ~-27 grass_block
setblock ~-4 ~1 ~-26 grass_block
setblock ~-4 ~2 ~-25 grass_block
setblock ~-4 ~2 ~-24 grass_block
setblock ~-4 ~3 ~-23 grass_block
setblock ~-4 ~3 ~-22 grass_block
setblock ~-4 ~4 ~-21 grass_block
setblock ~-4 ~4 ~-20 grass_block
setblock ~-4 ~5 ~-19 grass_block
setblock ~-4 ~5 ~-18 grass_block
setblock ~-4 ~6 ~-17 andesite
setblock ~-4 ~7 ~-16 grass_block
setblock ~-4 ~8 ~-15 moss_block
setblock ~-4 ~9 ~-14 grass_block
setblock ~-4 ~13 ~-13 grass_block
setblock ~-4 ~15 ~-12 grass_block
setblock ~-4 ~15 ~-11 grass_block
setblock ~-4 ~15 ~-10 grass_block
setblock ~-4 ~15 ~-9 grass_block
setblock ~-4 ~15 ~-8 grass_block
setblock ~-4 ~15 ~-7 grass_block
setblock ~-4 ~15 ~-6 grass_block
setblock ~-4 ~15 ~-5 grass_block
setblock ~-4 ~15 ~-4 grass_block
setblock ~-4 ~15 ~-3 grass_block
setblock ~-4 ~15 ~-2 grass_block
setblock ~-4 ~15 ~-1 grass_block
setblock ~-4 ~15 ~ grass_block
setblock ~-4 ~15 ~1 grass_block
setblock ~-4 ~15 ~2 grass_block
setblock ~-4 ~15 ~3 grass_block
setblock ~-4 ~15 ~4 grass_block
setblock ~-4 ~15 ~5 grass_block
setblock ~-4 ~15 ~6 grass_block
setblock ~-4 ~15 ~7 grass_block
setblock ~-4 ~15 ~8 grass_block
setblock ~-4 ~15 ~9 grass_block
setblock ~-4 ~15 ~10 grass_block
setblock ~-4 ~15 ~11 grass_block
setblock ~-4 ~15 ~12 grass_block
setblock ~-4 ~13 ~13 grass_block
setblock ~-4 ~10 ~14 grass_block
setblock ~-4 ~9 ~15 grass_block
setblock ~-4 ~9 ~16 grass_block
setblock ~-4 ~8 ~17 moss_block
setblock ~-4 ~8 ~18 coarse_dirt
setblock ~-4 ~7 ~19 moss_block
setblock ~-4 ~6 ~20 grass_block
setblock ~-4 ~6 ~21 grass_block
setblock ~-4 ~5 ~22 andesite
setblock ~-4 ~4 ~23 grass_block
setblock ~-4 ~3 ~24 grass_block
setblock ~-3 ~ ~-29 grass_block
setblock ~-3 ~ ~-28 grass_block
setblock ~-3 ~1 ~-27 grass_block
setblock ~-3 ~1 ~-26 grass_block
setblock ~-3 ~2 ~-25 grass_block
setblock ~-3 ~2 ~-24 grass_block
setblock ~-3 ~3 ~-23 grass_block
setblock ~-3 ~3 ~-22 grass_block
setblock ~-3 ~4 ~-21 grass_block
setblock ~-3 ~4 ~-20 grass_block
setblock ~-3 ~5 ~-19 grass_block
setblock ~-3 ~5 ~-18 grass_block
setblock ~-3 ~6 ~-17 grass_block
setblock ~-3 ~7 ~-16 grass_block
setblock ~-3 ~8 ~-15 grass_block
setblock ~-3 ~9 ~-14 coarse_dirt
setblock ~-3 ~14 ~-13 grass_block
setblock ~-3 ~15 ~-12 grass_block
setblock ~-3 ~15 ~-11 grass_block
setblock ~-3 ~15 ~-10 grass_block
setblock ~-3 ~15 ~-9 grass_block
setblock ~-3 ~15 ~-8 grass_block
setblock ~-3 ~15 ~-7 grass_block
setblock ~-3 ~15 ~-6 grass_block
setblock ~-3 ~15 ~-5 grass_block
setblock ~-3 ~15 ~-4 grass_block
setblock ~-3 ~15 ~-3 grass_block
setblock ~-3 ~15 ~-2 grass_block
setblock ~-3 ~15 ~-1 grass_block
setblock ~-3 ~15 ~ grass_block
setblock ~-3 ~15 ~1 grass_block
setblock ~-3 ~15 ~2 grass_block
setblock ~-3 ~15 ~3 grass_block
setblock ~-3 ~15 ~4 grass_block
setblock ~-3 ~15 ~5 grass_block
setblock ~-3 ~15 ~6 grass_block
setblock ~-3 ~15 ~7 grass_block
setblock ~-3 ~15 ~8 grass_block
setblock ~-3 ~15 ~9 grass_block
setblock ~-3 ~15 ~10 grass_block
setblock ~-3 ~15 ~11 grass_block
setblock ~-3 ~15 ~12 grass_block
setblock ~-3 ~14 ~13 grass_block
setblock ~-3 ~10 ~14 grass_block
setblock ~-3 ~10 ~15 grass_block
setblock ~-3 ~9 ~16 grass_block
setblock ~-3 ~8 ~17 moss_block
setblock ~-3 ~8 ~18 grass_block
setblock ~-3 ~7 ~19 grass_block
setblock ~-3 ~7 ~20 grass_block
setblock ~-3 ~6 ~21 grass_block
setblock ~-3 ~5 ~22 grass_block
setblock ~-3 ~5 ~23 grass_block
setblock ~-3 ~3 ~24 coarse_dirt
setblock ~-2 ~ ~-29 grass_block
setblock ~-2 ~ ~-28 grass_block
setblock ~-2 ~1 ~-27 moss_block
setblock ~-2 ~1 ~-26 grass_block
setblock ~-2 ~2 ~-25 grass_block
setblock ~-2 ~2 ~-24 grass_block
setblock ~-2 ~3 ~-23 andesite
setblock ~-2 ~3 ~-22 grass_block
setblock ~-2 ~4 ~-21 grass_block
setblock ~-2 ~4 ~-20 grass_block
setblock ~-2 ~5 ~-19 grass_block
setblock ~-2 ~5 ~-18 grass_block
setblock ~-2 ~6 ~-17 grass_block
setblock ~-2 ~7 ~-16 grass_block
setblock ~-2 ~8 ~-15 moss_block
setblock ~-2 ~12 ~-14 grass_block
setblock ~-2 ~14 ~-13 grass_block
setblock ~-2 ~15 ~-12 grass_block
setblock ~-2 ~15 ~-11 grass_block
setblock ~-2 ~15 ~-10 grass_block
setblock ~-2 ~15 ~-9 grass_block
setblock ~-2 ~15 ~-8 grass_block
setblock ~-2 ~15 ~-7 grass_block
setblock ~-2 ~15 ~-6 grass_block
setblock ~-2 ~15 ~-5 grass_block
setblock ~-2 ~15 ~-4 grass_block
setblock ~-2 ~15 ~-3 grass_block
setblock ~-2 ~15 ~-2 grass_block
setblock ~-2 ~15 ~-1 grass_block
setblock ~-2 ~15 ~ grass_block
setblock ~-2 ~15 ~1 grass_block
setblock ~-2 ~15 ~2 grass_block
setblock ~-2 ~15 ~3 grass_block
setblock ~-2 ~15 ~4 grass_block
setblock ~-2 ~15 ~5 grass_block
setblock ~-2 ~15 ~6 grass_block
setblock ~-2 ~15 ~7 grass_block
setblock ~-2 ~15 ~8 grass_block
setblock ~-2 ~15 ~9 grass_block
setblock ~-2 ~15 ~10 grass_block
setblock ~-2 ~15 ~11 grass_block
setblock ~-2 ~15 ~12 grass_block
setblock ~-2 ~14 ~13 grass_block
setblock ~-2 ~11 ~14 grass_block
setblock ~-2 ~10 ~15 grass_block
setblock ~-2 ~9 ~16 grass_block
setblock ~-2 ~9 ~17 grass_block
setblock ~-2 ~8 ~18 grass_block
setblock ~-2 ~8 ~19 grass_block
setblock ~-2 ~7 ~20 grass_block
setblock ~-2 ~7 ~21 grass_block
setblock ~-2 ~6 ~22 grass_block
setblock ~-2 ~5 ~23 grass_block
setblock ~-2 ~3 ~24 grass_block
setblock ~-2 ~ ~25 grass_block
setblock ~-1 ~ ~-29 grass_block
setblock ~-1 ~ ~-28 grass_block
setblock ~-1 ~1 ~-27 andesite
setblock ~-1 ~1 ~-26 coarse_dirt
setblock ~-1 ~2 ~-25 grass_block
setblock ~-1 ~2 ~-24 grass_block
setblock ~-1 ~3 ~-23 grass_block
setblock ~-1 ~3 ~-22 grass_block
setblock ~-1 ~4 ~-21 grass_block
setblock ~-1 ~4 ~-20 moss_block
setblock ~-1 ~5 ~-19 grass_block
setblock ~-1 ~6 ~-18 grass_block
setblock ~-1 ~6 ~-17 moss_block
setblock ~-1 ~8 ~-16 grass_block
setblock ~-1 ~10 ~-15 grass_block
setblock ~-1 ~13 ~-14 grass_block
setblock ~-1 ~14 ~-13 grass_block
setblock ~-1 ~15 ~-12 grass_block
setblock ~-1 ~15 ~-11 grass_block
setblock ~-1 ~15 ~-10 grass_block
setblock ~-1 ~15 ~-9 grass_block
setblock ~-1 ~15 ~-8 grass_block
setblock ~-1 ~15 ~-7 grass_block
setblock ~-1 ~15 ~-6 grass_block
setblock ~-1 ~15 ~-5 grass_block
setblock ~-1 ~15 ~-4 grass_block
setblock ~-1 ~15 ~-3 grass_block
setblock ~-1 ~15 ~-2 grass_block
setblock ~-1 ~15 ~-1 grass_block
setblock ~-1 ~15 ~ grass_block
setblock ~-1 ~15 ~1 grass_block
setblock ~-1 ~15 ~2 grass_block
setblock ~-1 ~15 ~3 grass_block
setblock ~-1 ~15 ~4 grass_block
setblock ~-1 ~15 ~5 grass_block
setblock ~-1 ~15 ~6 grass_block
setblock ~-1 ~15 ~7 grass_block
setblock ~-1 ~15 ~8 grass_block
setblock ~-1 ~15 ~9 grass_block
setblock ~-1 ~15 ~10 grass_block
setblock ~-1 ~15 ~11 grass_block
setblock ~-1 ~15 ~12 grass_block
setblock ~-1 ~14 ~13 grass_block
setblock ~-1 ~13 ~14 grass_block
setblock ~-1 ~11 ~15 grass_block
setblock ~-1 ~10 ~16 grass_block
setblock ~-1 ~9 ~17 grass_block
setblock ~-1 ~9 ~18 grass_block
setblock ~-1 ~8 ~19 grass_block
setblock ~-1 ~7 ~20 grass_block
setblock ~-1 ~7 ~21 coarse_dirt
setblock ~-1 ~6 ~22 grass_block
setblock ~-1 ~5 ~23 grass_block
setblock ~-1 ~4 ~24 grass_block
setblock ~-1 ~ ~25 coarse_dirt
setblock ~ ~ ~-29 grass_block
setblock ~ ~ ~-28 grass_block
setblock ~ ~1 ~-27 grass_block
setblock ~ ~1 ~-26 grass_block
setblock ~ ~2 ~-25 grass_block
setblock ~ ~2 ~-24 grass_block
setblock ~ ~3 ~-23 grass_block
setblock ~ ~3 ~-22 grass_block
setblock ~ ~4 ~-21 grass_block
setblock ~ ~4 ~-20 grass_block
setblock ~ ~5 ~-19 grass_block
setblock ~ ~6 ~-18 grass_block
setblock ~ ~7 ~-17 moss_block
setblock ~ ~9 ~-16 grass_block
setblock ~ ~12 ~-15 grass_block
setblock ~ ~13 ~-14 grass_block
setblock ~ ~15 ~-13 grass_block
setblock ~ ~15 ~-12 grass_block
setblock ~ ~15 ~-11 grass_block
setblock ~ ~15 ~-10 grass_block
setblock ~ ~15 ~-9 grass_block
setblock ~ ~15 ~-8 grass_block
setblock ~ ~15 ~-7 grass_block
setblock ~ ~15 ~-6 grass_block
setblock ~ ~15 ~-5 grass_block
setblock ~ ~15 ~-4 grass_block
setblock ~ ~15 ~-3 grass_block
setblock ~ ~15 ~-2 grass_block
setblock ~ ~15 ~-1 grass_block
setblock ~ ~15 ~ grass_block
setblock ~ ~15 ~1 grass_block
setblock ~ ~15 ~2 grass_block
setblock ~ ~15 ~3 grass_block
setblock ~ ~15 ~4 grass_block
setblock ~ ~15 ~5 grass_block
setblock ~ ~15 ~6 grass_block
setblock ~ ~15 ~7 grass_block
setblock ~ ~15 ~8 grass_block
setblock ~ ~15 ~9 grass_block
setblock ~ ~15 ~10 grass_block
setblock ~ ~15 ~11 grass_block
setblock ~ ~15 ~12 grass_block
setblock ~ ~15 ~13 grass_block
setblock ~ ~13 ~14 grass_block
setblock ~ ~11 ~15 grass_block
setblock ~ ~10 ~16 grass_block
setblock ~ ~10 ~17 grass_block
setblock ~ ~9 ~18 grass_block
setblock ~ ~8 ~19 grass_block
setblock ~ ~8 ~20 grass_block
setblock ~ ~7 ~21 grass_block
setblock ~ ~6 ~22 grass_block
setblock ~ ~5 ~23 grass_block
setblock ~ ~4 ~24 grass_block
setblock ~ ~1 ~25 moss_block
setblock ~1 ~ ~-29 grass_block
setblock ~1 ~ ~-28 grass_block
setblock ~1 ~1 ~-27 grass_block
setblock ~1 ~1 ~-26 coarse_dirt
setblock ~1 ~2 ~-25 grass_block
setblock ~1 ~2 ~-24 grass_block
setblock ~1 ~3 ~-23 grass_block
setblock ~1 ~3 ~-22 grass_block
setblock ~1 ~4 ~-21 grass_block
setblock ~1 ~4 ~-20 grass_block
setblock ~1 ~5 ~-19 moss_block
setblock ~1 ~6 ~-18 grass_block
setblock ~1 ~7 ~-17 grass_block
setblock ~1 ~11 ~-16 grass_block
setblock ~1 ~12 ~-15 grass_block
setblock ~1 ~13 ~-14 grass_block
setblock ~1 ~14 ~-13 grass_block
setblock ~1 ~15 ~-12 grass_block
setblock ~1 ~15 ~-11 grass_block
setblock ~1 ~15 ~-10 grass_block
setblock ~1 ~15 ~-9 grass_block
setblock ~1 ~15 ~-8 grass_block
setblock ~1 ~15 ~-7 grass_block
setblock ~1 ~15 ~-6 grass_block
setblock ~1 ~15 ~-5 grass_block
setblock ~1 ~15 ~-4 grass_block
setblock ~1 ~15 ~-3 grass_block
setblock ~1 ~15 ~-2 grass_block
setblock ~1 ~15 ~-1 grass_block
setblock ~1 ~15 ~ grass_block
setblock ~1 ~15 ~1 grass_block
setblock ~1 ~15 ~2 grass_block
setblock ~1 ~15 ~3 grass_block
setblock ~1 ~15 ~4 grass_block
setblock ~1 ~15 ~5 grass_block
setblock ~1 ~15 ~6 grass_block
setblock ~1 ~15 ~7 grass_block
setblock ~1 ~15 ~8 grass_block
setblock ~1 ~15 ~9 grass_block
setblock ~1 ~15 ~10 grass_block
setblock ~1 ~15 ~11 grass_block
setblock ~1 ~15 ~12 grass_block
setblock ~1 ~14 ~13 grass_block
setblock ~1 ~13 ~14 grass_block
setblock ~1 ~11 ~15 grass_block
setblock ~1 ~11 ~16 grass_block
setblock ~1 ~10 ~17 grass_block
setblock ~1 ~9 ~18 grass_block
setblock ~1 ~9 ~19 grass_block
setblock ~1 ~8 ~20 grass_block
setblock ~1 ~7 ~21 moss_block
setblock ~1 ~6 ~22 grass_block
setblock ~1 ~5 ~23 grass_block
setblock ~1 ~4 ~24 grass_block
setblock ~1 ~1 ~25 andesite
setblock ~2 ~ ~-30 grass_block
setblock ~2 ~ ~-29 grass_block
setblock ~2 ~ ~-28 andesite
setblock ~2 ~1 ~-27 grass_block
setblock ~2 ~1 ~-26 grass_block
setblock ~2 ~2 ~-25 grass_block
setblock ~2 ~2 ~-24 grass_block
setblock ~2 ~3 ~-23 coarse_dirt
setblock ~2 ~3 ~-22 grass_block
setblock ~2 ~4 ~-21 grass_block
setblock ~2 ~4 ~-20 grass_block
setblock ~2 ~5 ~-19 grass_block
setblock ~2 ~6 ~-18 grass_block
setblock ~2 ~9 ~-17 grass_block
setblock ~2 ~12 ~-16 grass_block
setblock ~2 ~12 ~-15 grass_block
setblock ~2 ~12 ~-14 andesite
setblock ~2 ~14 ~-13 coarse_dirt
setblock ~2 ~15 ~-12 grass_block
setblock ~2 ~15 ~-11 grass_block
setblock ~2 ~15 ~-10 grass_block
setblock ~2 ~15 ~-9 grass_block
setblock ~2 ~15 ~-8 grass_block
setblock ~2 ~15 ~-7 grass_block
setblock ~2 ~15 ~-6 grass_block
setblock ~2 ~15 ~-5 grass_block
setblock ~2 ~15 ~-4 grass_block
setblock ~2 ~15 ~-3 grass_block
setblock ~2 ~15 ~-2 grass_block
setblock ~2 ~15 ~-1 grass_block
setblock ~2 ~15 ~ grass_block
setblock ~2 ~15 ~1 grass_block
setblock ~2 ~15 ~2 grass_block
setblock ~2 ~15 ~3 grass_block
setblock ~2 ~15 ~4 grass_block
setblock ~2 ~15 ~5 grass_block
setblock ~2 ~15 ~6 grass_block
setblock ~2 ~15 ~7 grass_block
setblock ~2 ~15 ~8 grass_block
setblock ~2 ~15 ~9 grass_block
setblock ~2 ~15 ~10 grass_block
setblock ~2 ~15 ~11 grass_block
setblock ~2 ~15 ~12 grass_block
setblock ~2 ~14 ~13 moss_block
setblock ~2 ~12 ~14 coarse_dirt
setblock ~2 ~12 ~15 grass_block
setblock ~2 ~11 ~16 grass_block
setblock ~2 ~10 ~17 grass_block
setblock ~2 ~10 ~18 grass_block
setblock ~2 ~9 ~19 coarse_dirt
setblock ~2 ~8 ~20 andesite
setblock ~2 ~7 ~21 grass_block
setblock ~2 ~7 ~22 grass_block
setblock ~2 ~5 ~23 grass_block
setblock ~2 ~4 ~24 andesite
setblock ~2 ~1 ~25 moss_block
setblock ~3 ~ ~-30 grass_block
setblock ~3 ~ ~-29 grass_block
setblock ~3 ~ ~-28 grass_block
setblock ~3 ~1 ~-27 grass_block
setblock ~3 ~1 ~-26 moss_block
setblock ~3 ~2 ~-25 grass_block
setblock ~3 ~2 ~-24 grass_block
setblock ~3 ~3 ~-23 grass_block
setblock ~3 ~3 ~-22 grass_block
setblock ~3 ~4 ~-21 grass_block
setblock ~3 ~4 ~-20 grass_block
setblock ~3 ~5 ~-19 grass_block
setblock ~3 ~7 ~-18 andesite
setblock ~3 ~10 ~-17 grass_block
setblock ~3 ~12 ~-16 grass_block
setblock ~3 ~12 ~-15 grass_block
setblock ~3 ~12 ~-14 andesite
setblock ~3 ~14 ~-13 andesite
setblock ~3 ~15 ~-12 grass_block
setblock ~3 ~15 ~-11 grass_block
setblock ~3 ~15 ~-10 grass_block
setblock ~3 ~15 ~-9 grass_block
setblock ~3 ~15 ~-8 grass_block
setblock ~3 ~15 ~-7 grass_block
setblock ~3 ~15 ~-6 grass_block
setblock ~3 ~15 ~-5 grass_block
setblock ~3 ~15 ~-4 grass_block
setblock ~3 ~15 ~-3 grass_block
setblock ~3 ~15 ~-2 grass_block
setblock ~3 ~15 ~-1 grass_block
setblock ~3 ~15 ~ grass_block
setblock ~3 ~15 ~1 grass_block
setblock ~3 ~15 ~2 grass_block
setblock ~3 ~15 ~3 grass_block
setblock ~3 ~15 ~4 grass_block
setblock ~3 ~15 ~5 grass_block
setblock ~3 ~15 ~6 grass_block
setblock ~3 ~15 ~7 grass_block
setblock ~3 ~15 ~8 grass_block
setblock ~3 ~15 ~9 grass_block
setblock ~3 ~15 ~10 grass_block
setblock ~3 ~15 ~11 grass_block
setblock ~3 ~15 ~12 grass_block
setblock ~3 ~14 ~13 grass_block
setblock ~3 ~12 ~14 grass_block
setblock ~3 ~12 ~15 grass_block
setblock ~3 ~11 ~16 andesite
setblock ~3 ~10 ~17 grass_block
setblock ~3 ~10 ~18 grass_block
setblock ~3 ~9 ~19 grass_block
setblock ~3 ~8 ~20 grass_block
setblock ~3 ~8 ~21 grass_block
setblock ~3 ~7 ~22 grass_block
setblock ~3 ~5 ~23 grass_block
setblock ~3 ~3 ~24 coarse_dirt
setblock ~3 ~1 ~25 grass_block
setblock ~3 ~ ~26 andesite
setblock ~4 ~ ~-30 grass_block
setblock ~4 ~ ~-29 grass_block
setblock ~4 ~ ~-28 grass_block
setblock ~4 ~1 ~-27 grass_block
setblock ~4 ~1 ~-26 grass_block
setblock ~4 ~2 ~-25 grass_block
setblock ~4 ~2 ~-24 grass_block
setblock ~4 ~3 ~-23 coarse_dirt
setblock ~4 ~3 ~-22 grass_block
setblock ~4 ~4 ~-21 grass_block
setblock ~4 ~4 ~-20 grass_block
setblock ~4 ~6 ~-19 grass_block
setblock ~4 ~8 ~-18 grass_block
setblock ~4 ~11 ~-17 grass_block
setblock ~4 ~12 ~-16 grass_block
setblock ~4 ~12 ~-15 grass_block
setblock ~4 ~12 ~-14 grass_block
setblock ~4 ~13 ~-13 coarse_dirt
setblock ~4 ~15 ~-12 grass_block
setblock ~4 ~15 ~-11 grass_block
setblock ~4 ~15 ~-10 grass_block
setblock ~4 ~15 ~-9 grass_block
setblock ~4 ~15 ~-8 grass_block
setblock ~4 ~15 ~-7 grass_block
setblock ~4 ~15 ~-6 grass_block
setblock ~4 ~15 ~-5 grass_block
setblock ~4 ~15 ~-4 grass_block
setblock ~4 ~15 ~-3 grass_block
setblock ~4 ~15 ~-2 grass_block
setblock ~4 ~15 ~-1 grass_block
setblock ~4 ~15 ~ grass_block
setblock ~4 ~15 ~1 grass_block
setblock ~4 ~15 ~2 grass_block
setblock ~4 ~15 ~3 grass_block
setblock ~4 ~15 ~4 grass_block
setblock ~4 ~15 ~5 grass_block
setblock ~4 ~15 ~6 grass_block
setblock ~4 ~15 ~7 grass_block
setblock ~4 ~15 ~8 grass_block
setblock ~4 ~15 ~9 grass_block
setblock ~4 ~15 ~10 grass_block
setblock ~4 ~15 ~11 grass_block
setblock ~4 ~15 ~12 grass_block
setblock ~4 ~13 ~13 grass_block
setblock ~4 ~12 ~14 grass_block
setblock ~4 ~12 ~15 coarse_dirt
setblock ~4 ~11 ~16 grass_block
setblock ~4 ~10 ~17 grass_block
setblock ~4 ~10 ~18 grass_block
setblock ~4 ~9 ~19 grass_block
setblock ~4 ~8 ~20 grass_block
setblock ~4 ~7 ~21 grass_block
setblock ~4 ~6 ~22 grass_block
setblock ~4 ~5 ~23 grass_block
setblock ~4 ~2 ~24 grass_block
setblock ~4 ~1 ~25 grass_block
setblock ~4 ~ ~26 coarse_dirt
setblock ~5 ~ ~-29 moss_block
setblock ~5 ~ ~-28 andesite
setblock ~5 ~1 ~-27 grass_block
setblock ~5 ~1 ~-26 grass_block
setblock ~5 ~2 ~-25 grass_block
setblock ~5 ~2 ~-24 grass_block
setblock ~5 ~3 ~-23 grass_block
setblock ~5 ~3 ~-22 grass_block
setblock ~5 ~4 ~-21 grass_block
setblock ~5 ~4 ~-20 grass_block
setblock ~5 ~6 ~-19 grass_block
setblock ~5 ~8 ~-18 moss_block
setblock ~5 ~11 ~-17 grass_block
setblock ~5 ~12 ~-16 grass_block
setblock ~5 ~12 ~-15 grass_block
setblock ~5 ~12 ~-14 moss_block
setblock ~5 ~13 ~-13 grass_block
setblock ~5 ~15 ~-12 grass_block
setblock ~5 ~15 ~-11 grass_block
setblock ~5 ~15 ~-10 grass_block
setblock ~5 ~15 ~-9 grass_block
setblock ~5 ~15 ~-8 grass_block
setblock ~5 ~15 ~-7 grass_block
setblock ~5 ~15 ~-6 grass_block
setblock ~5 ~15 ~-5 grass_block
setblock ~5 ~15 ~-4 grass_block
setblock ~5 ~15 ~-3 grass_block
setblock ~5 ~15 ~-2 grass_block
setblock ~5 ~15 ~-1 grass_block
setblock ~5 ~15 ~ grass_block
setblock ~5 ~15 ~1 grass_block
setblock ~5 ~15 ~2 grass_block
setblock ~5 ~15 ~3 grass_block
setblock ~5 ~15 ~4 grass_block
setblock ~5 ~15 ~5 grass_block
setblock ~5 ~15 ~6 grass_block
setblock ~5 ~15 ~7 grass_block
setblock ~5 ~15 ~8 grass_block
setblock ~5 ~15 ~9 grass_block
setblock ~5 ~15 ~10 grass_block
setblock ~5 ~15 ~11 grass_block
setblock ~5 ~15 ~12 grass_block
setblock ~5 ~13 ~13 coarse_dirt
setblock ~5 ~12 ~14 grass_block
setblock ~5 ~12 ~15 grass_block
setblock ~5 ~11 ~16 grass_block
setblock ~5 ~10 ~17 grass_block
setblock ~5 ~10 ~18 grass_block
setblock ~5 ~9 ~19 grass_block
setblock ~5 ~8 ~20 grass_block
setblock ~5 ~7 ~21 grass_block
setblock ~5 ~6 ~22 andesite
setblock ~5 ~4 ~23 grass_block
setblock ~5 ~2 ~24 grass_block
setblock ~5 ~ ~25 grass_block
setblock ~5 ~ ~26 grass_block
setblock ~6 ~ ~-29 grass_block
setblock ~6 ~ ~-28 andesite
setblock ~6 ~1 ~-27 grass_block
setblock ~6 ~1 ~-26 grass_block
setblock ~6 ~1 ~-25 grass_block
setblock ~6 ~2 ~-24 grass_block
setblock ~6 ~2 ~-23 grass_block
setblock ~6 ~3 ~-22 coarse_dirt
setblock ~6 ~4 ~-21 grass_block
setblock ~6 ~4 ~-20 grass_block
setblock ~6 ~6 ~-19 grass_block
setblock ~6 ~8 ~-18 grass_block
setblock ~6 ~10 ~-17 grass_block
setblock ~6 ~12 ~-16 grass_block
setblock ~6 ~12 ~-15 grass_block
setblock ~6 ~12 ~-14 grass_block
setblock ~6 ~12 ~-13 grass_block
setblock ~6 ~14 ~-12 coarse_dirt
setblock ~6 ~15 ~-11 grass_block
setblock ~6 ~15 ~-10 grass_block
setblock ~6 ~15 ~-9 grass_block
setblock ~6 ~15 ~-8 grass_block
setblock ~6 ~15 ~-7 grass_block
setblock ~6 ~15 ~-6 grass_block
setblock ~6 ~15 ~-5 grass_block
setblock ~6 ~15 ~-4 grass_block
setblock ~6 ~15 ~-3 grass_block
setblock ~6 ~15 ~-2 grass_block
setblock ~6 ~15 ~-1 grass_block
setblock ~6 ~15 ~ grass_block
setblock ~6 ~15 ~1 grass_block
setblock ~6 ~15 ~2 grass_block
setblock ~6 ~15 ~3 grass_block
setblock ~6 ~15 ~4 grass_block
setblock ~6 ~15 ~5 grass_block
setblock ~6 ~15 ~6 grass_block
setblock ~6 ~15 ~7 grass_block
setblock ~6 ~15 ~8 grass_block
setblock ~6 ~15 ~9 grass_block
setblock ~6 ~15 ~10 grass_block
setblock ~6 ~15 ~11 grass_block
setblock ~6 ~14 ~12 grass_block
setblock ~6 ~12 ~13 coarse_dirt
setblock ~6 ~12 ~14 grass_block
setblock ~6 ~12 ~15 grass_block
setblock ~6 ~11 ~16 grass_block
setblock ~6 ~10 ~17 moss_block
setblock ~6 ~10 ~18 grass_block
setblock ~6 ~9 ~19 grass_block
setblock ~6 ~8 ~20 grass_block
setblock ~6 ~7 ~21 grass_block
setblock ~6 ~5 ~22 grass_block
setblock ~6 ~3 ~23 grass_block
setblock ~6 ~1 ~24 grass_block
setblock ~6 ~ ~25 grass_block
setblock ~6 ~ ~26 grass_block
setblock ~7 ~ ~-29 grass_block
setblock ~7 ~ ~-28 grass_block
setblock ~7 ~ ~-27 grass_block
setblock ~7 ~1 ~-26 grass_block
setblock ~7 ~1 ~-25 grass_block
setblock ~7 ~2 ~-24 coarse_dirt
setblock ~7 ~2 ~-23 grass_block
setblock ~7 ~3 ~-22 andesite
setblock ~7 ~3 ~-21 grass_block
setblock ~7 ~4 ~-20 grass_block
setblock ~7 ~6 ~-19 grass_block
setblock ~7 ~8 ~-18 grass_block
setblock ~7 ~10 ~-17 grass_block
setblock ~7 ~11 ~-16 grass_block
setblock ~7 ~12 ~-15 grass_block
setblock ~7 ~12 ~-14 grass_block
setblock ~7 ~12 ~-13 grass_block
setblock ~7 ~13 ~-12 grass_block
setblock ~7 ~14 ~-11 grass_block
setblock ~7 ~15 ~-10 grass_block
setblock ~7 ~15 ~-9 grass_block
setblock ~7 ~15 ~-8 grass_block
setblock ~7 ~15 ~-7 grass_block
setblock ~7 ~15 ~-6 grass_block
setblock ~7 ~15 ~-5 grass_block
setblock ~7 ~15 ~-4 grass_block
setblock ~7 ~15 ~-3 grass_block
setblock ~7 ~15 ~-2 grass_block
setblock ~7 ~15 ~-1 grass_block
setblock ~7 ~15 ~ grass_block
setblock ~7 ~15 ~1 grass_block
setblock ~7 ~15 ~2 grass_block
setblock ~7 ~15 ~3 grass_block
setblock ~7 ~15 ~4 grass_block
setblock ~7 ~15 ~5 grass_block
setblock ~7 ~15 ~6 grass_block
setblock ~7 ~15 ~7 grass_block
setblock ~7 ~15 ~8 grass_block
setblock ~7 ~15 ~9 grass_block
setblock ~7 ~15 ~10 grass_block
setblock ~7 ~14 ~11 grass_block
setblock ~7 ~13 ~12 coarse_dirt
setblock ~7 ~12 ~13 grass_block
setblock ~7 ~12 ~14 grass_block
setblock ~7 ~11 ~15 grass_block
setblock ~7 ~11 ~16 grass_block
setblock ~7 ~10 ~17 grass_block
setblock ~7 ~9 ~18 grass_block
setblock ~7 ~8 ~19 grass_block
setblock ~7 ~7 ~20 grass_block
setblock ~7 ~6 ~21 moss_block
setblock ~7 ~3 ~22 moss_block
setblock ~7 ~2 ~23 grass_block
setblock ~7 ~1 ~24 coarse_dirt
setblock ~7 ~ ~25 andesite
setblock ~8 ~ ~-29 grass_block
setblock ~8 ~ ~-28 grass_block
setblock ~8 ~ ~-27 grass_block
setblock ~8 ~1 ~-26 grass_block
setblock ~8 ~1 ~-25 grass_block
setblock ~8 ~1 ~-24 grass_block
setblock ~8 ~2 ~-23 grass_block
setblock ~8 ~2 ~-22 grass_block
setblock ~8 ~3 ~-21 grass_block
setblock ~8 ~4 ~-20 grass_block
setblock ~8 ~5 ~-19 grass_block
setblock ~8 ~8 ~-18 grass_block
setblock ~8 ~10 ~-17 grass_block
setblock ~8 ~11 ~-16 coarse_dirt
setblock ~8 ~11 ~-15 grass_block
setblock ~8 ~12 ~-14 grass_block
setblock ~8 ~12 ~-13 grass_block
setblock ~8 ~12 ~-12 grass_block
setblock ~8 ~13 ~-11 grass_block
setblock ~8 ~15 ~-10 grass_block
setblock ~8 ~15 ~-9 grass_block
setblock ~8 ~15 ~-8 grass_block
setblock ~8 ~15 ~-7 grass_block
setblock ~8 ~15 ~-6 grass_block
setblock ~8 ~15 ~-5 grass_block
setblock ~8 ~15 ~-4 grass_block
setblock ~8 ~15 ~-3 grass_block
setblock ~8 ~15 ~-2 grass_block
setblock ~8 ~15 ~-1 grass_block
setblock ~8 ~15 ~ grass_block
setblock ~8 ~15 ~1 grass_block
setblock ~8 ~15 ~2 grass_block
setblock ~8 ~15 ~3 grass_block
setblock ~8 ~15 ~4 grass_block
setblock ~8 ~15 ~5 grass_block
setblock ~8 ~15 ~6 grass_block
setblock ~8 ~15 ~7 grass_block
setblock ~8 ~15 ~8 grass_block
setblock ~8 ~15 ~9 grass_block
setblock ~8 ~15 ~10 grass_block
setblock ~8 ~13 ~11 grass_block
setblock ~8 ~12 ~12 grass_block
setblock ~8 ~12 ~13 grass_block
setblock ~8 ~12 ~14 grass_block
setblock ~8 ~11 ~15 grass_block
setblock ~8 ~10 ~16 grass_block
setblock ~8 ~10 ~17 andesite
setblock ~8 ~9 ~18 grass_block
setblock ~8 ~8 ~19 grass_block
setblock ~8 ~6 ~20 grass_block
setblock ~8 ~4 ~21 grass_block
setblock ~8 ~2 ~22 grass_block
setblock ~8 ~1 ~23 grass_block
setblock ~8 ~1 ~24 andesite
setblock ~8 ~ ~25 grass_block
setblock ~9 ~ ~-28 andesite
setblock ~9 ~ ~-27 grass_block
setblock ~9 ~ ~-26 grass_block
setblock ~9 ~1 ~-25 andesite
setblock ~9 ~1 ~-24 grass_block
setblock ~9 ~2 ~-23 moss_block
setblock ~9 ~2 ~-22 coarse_dirt
setblock ~9 ~3 ~-21 moss_block
setblock ~9 ~3 ~-20 grass_block
setblock ~9 ~5 ~-19 grass_block
setblock ~9 ~7 ~-18 grass_block
setblock ~9 ~9 ~-17 grass_block
setblock ~9 ~10 ~-16 moss_block
setblock ~9 ~11 ~-15 grass_block
setblock ~9 ~11 ~-14 grass_block
setblock ~9 ~12 ~-13 grass_block
setblock ~9 ~12 ~-12 grass_block
setblock ~9 ~12 ~-11 grass_block
setblock ~9 ~13 ~-10 moss_block
setblock ~9 ~15 ~-9 grass_block
setblock ~9 ~15 ~-8 grass_block
setblock ~9 ~15 ~-7 grass_block
setblock ~9 ~15 ~-6 grass_block
setblock ~9 ~15 ~-5 grass_block
setblock ~9 ~15 ~-4 grass_block
setblock ~9 ~15 ~-3 grass_block
setblock ~9 ~15 ~-2 grass_block
setblock ~9 ~15 ~-1 grass_block
setblock ~9 ~15 ~ grass_block
setblock ~9 ~15 ~1 grass_block
setblock ~9 ~15 ~2 grass_block
setblock ~9 ~15 ~3 grass_block
setblock ~9 ~15 ~4 grass_block
setblock ~9 ~15 ~5 grass_block
setblock ~9 ~15 ~6 grass_block
setblock ~9 ~15 ~7 grass_block
setblock ~9 ~15 ~8 grass_block
setblock ~9 ~15 ~9 grass_block
setblock ~9 ~13 ~10 grass_block
setblock ~9 ~12 ~11 grass_block
setblock ~9 ~12 ~12 grass_block
setblock ~9 ~12 ~13 grass_block
setblock ~9 ~11 ~14 moss_block
setblock ~9 ~10 ~15 grass_block
setblock ~9 ~10 ~16 grass_block
setblock ~9 ~9 ~17 grass_block
setblock ~9 ~8 ~18 grass_block
setblock ~9 ~6 ~19 grass_block
setblock ~9 ~4 ~20 grass_block
setblock ~9 ~3 ~21 grass_block
setblock ~9 ~2 ~22 grass_block
setblock ~9 ~1 ~23 grass_block
setblock ~9 ~ ~24 grass_block
setblock ~9 ~ ~25 moss_block
setblock ~10 ~ ~-28 grass_block
setblock ~10 ~ ~-27 grass_block
setblock ~10 ~ ~-26 grass_block
setblock ~10 ~1 ~-25 grass_block
setblock ~10 ~1 ~-24 grass_block
setblock ~10 ~1 ~-23 coarse_dirt
setblock ~10 ~2 ~-22 andesite
setblock ~10 ~2 ~-21 coarse_dirt
setblock ~10 ~3 ~-20 grass_block
setblock ~10 ~4 ~-19 grass_block
setblock ~10 ~6 ~-18 grass_block
setblock ~10 ~8 ~-17 grass_block
setblock ~10 ~9 ~-16 coarse_dirt
setblock ~10 ~10 ~-15 grass_block
setblock ~10 ~11 ~-14 grass_block
setblock ~10 ~11 ~-13 grass_block
setblock ~10 ~11 ~-12 grass_block
setblock ~10 ~12 ~-11 andesite
setblock ~10 ~12 ~-10 grass_block
setblock ~10 ~13 ~-9 grass_block
setblock ~10 ~15 ~-8 grass_block
setblock ~10 ~15 ~-7 grass_block
setblock ~10 ~15 ~-6 grass_block
setblock ~10 ~15 ~-5 grass_block
setblock ~10 ~15 ~-4 grass_block
setblock ~10 ~15 ~-3 grass_block
setblock ~10 ~15 ~-2 grass_block
setblock ~10 ~15 ~-1 grass_block
setblock ~10 ~15 ~ grass_block
setblock ~10 ~15 ~1 grass_block
setblock ~10 ~15 ~2 grass_block
setblock ~10 ~15 ~3 grass_block
setblock ~10 ~15 ~4 grass_block
setblock ~10 ~15 ~5 grass_block
setblock ~10 ~15 ~6 grass_block
setblock ~10 ~15 ~7 grass_block
setblock ~10 ~15 ~8 grass_block
setblock ~10 ~13 ~9 grass_block
setblock ~10 ~12 ~10 grass_block
setblock ~10 ~12 ~11 grass_block
setblock ~10 ~12 ~12 grass_block
setblock ~10 ~11 ~13 grass_block
setblock ~10 ~10 ~14 grass_block
setblock ~10 ~9 ~15 grass_block
setblock ~10 ~8 ~16 grass_block
setblock ~10 ~7 ~17 grass_block
setblock ~10 ~5 ~18 grass_block
setblock ~10 ~4 ~19 grass_block
setblock ~10 ~3 ~20 moss_block
setblock ~10 ~2 ~21 coarse_dirt
setblock ~10 ~1 ~22 grass_block
setblock ~10 ~1 ~23 grass_block
setblock ~10 ~ ~24 moss_block
setblock ~10 ~ ~25 grass_block
setblock ~11 ~ ~-27 grass_block
setblock ~11 ~ ~-26 grass_block
setblock ~11 ~ ~-25 grass_block
setblock ~11 ~1 ~-24 grass_block
setblock ~11 ~1 ~-23 grass_block
setblock ~11 ~1 ~-22 grass_block
setblock ~11 ~2 ~-21 grass_block
setblock ~11 ~2 ~-20 grass_block
setblock ~11 ~3 ~-19 grass_block
setblock ~11 ~5 ~-18 grass_block
setblock ~11 ~7 ~-17 grass_block
setblock ~11 ~9 ~-16 grass_block
setblock ~11 ~9 ~-15 grass_block
setblock ~11 ~10 ~-14 grass_block
setblock ~11 ~10 ~-13 grass_block
setblock ~11 ~11 ~-12 grass_block
setblock ~11 ~11 ~-11 grass_block
setblock ~11 ~11 ~-10 grass_block
setblock ~11 ~11 ~-9 grass_block
setblock ~11 ~13 ~-8 grass_block
setblock ~11 ~14 ~-7 grass_block
setblock ~11 ~15 ~-6 grass_block
setblock ~11 ~15 ~-5 grass_block
setblock ~11 ~15 ~-4 grass_block
setblock ~11 ~15 ~-3 grass_block
setblock ~11 ~15 ~-2 grass_block
setblock ~11 ~15 ~-1 grass_block
setblock ~11 ~15 ~ grass_block
setblock ~11 ~15 ~1 grass_block
setblock ~11 ~15 ~2 grass_block
setblock ~11 ~15 ~3 grass_block
setblock ~11 ~15 ~4 grass_block
setblock ~11 ~15 ~5 grass_block
setblock ~11 ~15 ~6 grass_block
setblock ~11 ~14 ~7 grass_block
setblock ~11 ~13 ~8 grass_block
setblock ~11 ~12 ~9 grass_block
setblock ~11 ~12 ~10 grass_block
setblock ~11 ~11 ~11 grass_block
setblock ~11 ~10 ~12 grass_block
setblock ~11 ~9 ~13 grass_block
setblock ~11 ~8 ~14 coarse_dirt
setblock ~11 ~7 ~15 grass_block
setblock ~11 ~5 ~16 grass_block
setblock ~11 ~4 ~17 grass_block
setblock ~11 ~3 ~18 grass_block
setblock ~11 ~3 ~19 grass_block
setblock ~11 ~2 ~20 grass_block
setblock ~11 ~1 ~21 grass_block
setblock ~11 ~1 ~22 grass_block
setblock ~11 ~ ~23 moss_block
setblock ~11 ~ ~24 moss_block
setblock ~12 ~ ~-26 andesite
setblock ~12 ~ ~-25 grass_block
setblock ~12 ~ ~-24 moss_block
setblock ~12 ~1 ~-23 moss_block
setblock ~12 ~1 ~-22 grass_block
setblock ~12 ~1 ~-21 grass_block
setblock ~12 ~2 ~-20 grass_block
setblock ~12 ~2 ~-19 andesite
setblock ~12 ~3 ~-18 grass_block
setblock ~12 ~6 ~-17 grass_block
setblock ~12 ~8 ~-16 grass_block
setblock ~12 ~8 ~-15 grass_block
setblock ~12 ~9 ~-14 grass_block
setblock ~12 ~10 ~-13 grass_block
setblock ~12 ~10 ~-12 grass_block
setblock ~12 ~10 ~-11 grass_block
setblock ~12 ~10 ~-10 grass_block
setblock ~12 ~11 ~-9 grass_block
setblock ~12 ~11 ~-8 coarse_dirt
setblock ~12 ~13 ~-7 grass_block
setblock ~12 ~14 ~-6 grass_block
setblock ~12 ~15 ~-5 grass_block
setblock ~12 ~15 ~-4 grass_block
setblock ~12 ~15 ~-3 grass_block
setblock ~12 ~15 ~-2 grass_block
setblock ~12 ~15 ~-1 grass_block
setblock ~12 ~15 ~ grass_block
setblock ~12 ~15 ~1 grass_block
setblock ~12 ~15 ~2 grass_block
setblock ~12 ~15 ~3 grass_block
setblock ~12 ~15 ~4 grass_block
setblock ~12 ~15 ~5 grass_block
setblock ~12 ~14 ~6 grass_block
setblock ~12 ~13 ~7 grass_block
setblock ~12 ~12 ~8 grass_block
setblock ~12 ~12 ~9 grass_block
setblock ~12 ~10 ~10 grass_block
setblock ~12 ~9 ~11 grass_block
setblock ~12 ~7 ~12 moss_block
setblock ~12 ~6 ~13 grass_block
setblock ~12 ~5 ~14 moss_block
setblock ~12 ~4 ~15 grass_block
setblock ~12 ~4 ~16 grass_block
setblock ~12 ~3 ~17 grass_block
setblock ~12 ~2 ~18 grass_block
setblock ~12 ~2 ~19 grass_block
setblock ~12 ~1 ~20 grass_block
setblock ~12 ~1 ~21 grass_block
setblock ~12 ~ ~22 grass_block
setblock ~12 ~ ~23 grass_block
setblock ~12 ~ ~24 grass_block
setblock ~13 ~ ~-25 coarse_dirt
setblock ~13 ~ ~-24 grass_block
setblock ~13 ~ ~-23 grass_block
setblock ~13 ~1 ~-22 grass_block
setblock ~13 ~1 ~-21 grass_block
setblock ~13 ~1 ~-20 grass_block
setblock ~13 ~2 ~-19 grass_block
setblock ~13 ~2 ~-18 grass_block
setblock ~13 ~4 ~-17 grass_block
setblock ~13 ~6 ~-16 moss_block
setblock ~13 ~8 ~-15 grass_block
setblock ~13 ~8 ~-14 moss_block
setblock ~13 ~9 ~-13 grass_block
setblock ~13 ~9 ~-12 grass_block
setblock ~13 ~9 ~-11 grass_block
setblock ~13 ~10 ~-10 grass_block
setblock ~13 ~10 ~-9 grass_block
setblock ~13 ~10 ~-8 coarse_dirt
setblock ~13 ~10 ~-7 grass_block
setblock ~13 ~11 ~-6 grass_block
setblock ~13 ~13 ~-5 grass_block
setblock ~13 ~13 ~-4 coarse_dirt
setblock ~13 ~14 ~-3 grass_block
setblock ~13 ~14 ~-2 grass_block
setblock ~13 ~14 ~-1 grass_block
setblock ~13 ~15 ~ grass_block
setblock ~13 ~14 ~1 grass_block
setblock ~13 ~14 ~2 coarse_dirt
setblock ~13 ~14 ~3 grass_block
setblock ~13 ~13 ~4 grass_block
setblock ~13 ~13 ~5 grass_block
setblock ~13 ~12 ~6 andesite
setblock ~13 ~12 ~7 coarse_dirt
setblock ~13 ~10 ~8 grass_block
setblock ~13 ~8 ~9 grass_block
setblock ~13 ~7 ~10 moss_block
setblock ~13 ~6 ~11 grass_block
setblock ~13 ~5 ~12 coarse_dirt
setblock ~13 ~5 ~13 moss_block
setblock ~13 ~4 ~14 grass_block
setblock ~13 ~3 ~15 grass_block
setblock ~13 ~3 ~16 andesite
setblock ~13 ~2 ~17 grass_block
setblock ~13 ~2 ~18 grass_block
setblock ~13 ~1 ~19 grass_block
setblock ~13 ~1 ~20 grass_block
setblock ~13 ~1 ~21 grass_block
setblock ~13 ~ ~22 grass_block
setblock ~13 ~ ~23 moss_block
setblock ~14 ~ ~-23 grass_block
setblock ~14 ~ ~-22 grass_block
setblock ~14 ~ ~-21 andesite
setblock ~14 ~1 ~-20 grass_block
setblock ~14 ~1 ~-19 grass_block
setblock ~14 ~2 ~-18 coarse_dirt
setblock ~14 ~2 ~-17 andesite
setblock ~14 ~4 ~-16 andesite
setblock ~14 ~6 ~-15 grass_block
setblock ~14 ~7 ~-14 grass_block
setblock ~14 ~8 ~-13 grass_block
setblock ~14 ~8 ~-12 grass_block
setblock ~14 ~9 ~-11 grass_block
setblock ~14 ~9 ~-10 coarse_dirt
setblock ~14 ~9 ~-9 grass_block
setblock ~14 ~9 ~-8 grass_block
setblock ~14 ~10 ~-7 grass_block
setblock ~14 ~10 ~-6 grass_block
setblock ~14 ~10 ~-5 grass_block
setblock ~14 ~10 ~-4 grass_block
setblock ~14 ~11 ~-3 grass_block
setblock ~14 ~11 ~-2 grass_block
setblock ~14 ~13 ~-1 grass_block
setblock ~14 ~13 ~ grass_block
setblock ~14 ~13 ~1 grass_block
setblock ~14 ~12 ~2 grass_block
setblock ~14 ~12 ~3 grass_block
setblock ~14 ~12 ~4 andesite
setblock ~14 ~11 ~5 grass_block
setblock ~14 ~10 ~6 grass_block
setblock ~14 ~8 ~7 grass_block
setblock ~14 ~7 ~8 moss_block
setblock ~14 ~6 ~9 grass_block
setblock ~14 ~6 ~10 grass_block
setblock ~14 ~5 ~11 grass_block
setblock ~14 ~4 ~12 grass_block
setblock ~14 ~4 ~13 coarse_dirt
setblock ~14 ~3 ~14 grass_block
setblock ~14 ~3 ~15 grass_block
setblock ~14 ~2 ~16 grass_block
setblock ~14 ~2 ~17 coarse_dirt
setblock ~14 ~1 ~18 grass_block
setblock ~14 ~1 ~19 grass_block
setblock ~14 ~1 ~20 grass_block
setblock ~14 ~ ~21 grass_block
setblock ~14 ~ ~22 coarse_dirt
setblock ~14 ~ ~23 coarse_dirt
setblock ~15 ~ ~-22 coarse_dirt
setblock ~15 ~ ~-21 grass_block
setblock ~15 ~ ~-20 grass_block
setblock ~15 ~ ~-19 grass_block
setblock ~15 ~1 ~-18 grass_block
setblock ~15 ~1 ~-17 grass_block
setblock ~15 ~2 ~-16 grass_block
setblock ~15 ~4 ~-15 grass_block
setblock ~15 ~6 ~-14 coarse_dirt
setblock ~15 ~7 ~-13 grass_block
setblock ~15 ~8 ~-12 grass_block
setblock ~15 ~8 ~-11 grass_block
setblock ~15 ~8 ~-10 coarse_dirt
setblock ~15 ~9 ~-9 grass_block
setblock ~15 ~9 ~-8 grass_block
setblock ~15 ~9 ~-7 grass_block
setblock ~15 ~9 ~-6 grass_block
setblock ~15 ~9 ~-5 grass_block
setblock ~15 ~10 ~-4 grass_block
setblock ~15 ~10 ~-3 grass_block
setblock ~15 ~10 ~-2 andesite
setblock ~15 ~10 ~-1 coarse_dirt
setblock ~15 ~10 ~ grass_block
setblock ~15 ~11 ~1 grass_block
setblock ~15 ~10 ~2 grass_block
setblock ~15 ~10 ~3 grass_block
setblock ~15 ~10 ~4 andesite
setblock ~15 ~9 ~5 grass_block
setblock ~15 ~8 ~6 grass_block
setblock ~15 ~7 ~7 grass_block
setblock ~15 ~6 ~8 grass_block
setblock ~15 ~6 ~9 grass_block
setblock ~15 ~5 ~10 moss_block
setblock ~15 ~4 ~11 andesite
setblock ~15 ~4 ~12 grass_block
setblock ~15 ~3 ~13 grass_block
setblock ~15 ~3 ~14 moss_block
setblock ~15 ~2 ~15 coarse_dirt
setblock ~15 ~2 ~16 coarse_dirt
setblock ~15 ~2 ~17 coarse_dirt
setblock ~15 ~1 ~18 grass_block
setblock ~15 ~1 ~19 grass_block
setblock ~15 ~ ~20 grass_block
setblock ~15 ~ ~21 grass_block
setblock ~15 ~ ~22 grass_block
setblock ~16 ~ ~-20 grass_block
setblock ~16 ~ ~-19 grass_block
setblock ~16 ~ ~-18 grass_block
setblock ~16 ~ ~-17 andesite
setblock ~16 ~1 ~-16 grass_block
setblock ~16 ~2 ~-15 grass_block
setblock ~16 ~4 ~-14 moss_block
setblock ~16 ~6 ~-13 grass_block
setblock ~16 ~7 ~-12 grass_block
setblock ~16 ~7 ~-11 coarse_dirt
setblock ~16 ~8 ~-10 grass_block
setblock ~16 ~8 ~-9 grass_block
setblock ~16 ~8 ~-8 grass_block
setblock ~16 ~8 ~-7 grass_block
setblock ~16 ~9 ~-6 andesite
setblock ~16 ~9 ~-5 grass_block
setblock ~16 ~9 ~-4 grass_block
setblock ~16 ~9 ~-3 moss_block
setblock ~16 ~9 ~-2 grass_block
setblock ~16 ~9 ~-1 grass_block
setblock ~16 ~9 ~ grass_block
setblock ~16 ~9 ~1 grass_block
setblock ~16 ~9 ~2 grass_block
setblock ~16 ~9 ~3 grass_block
setblock ~16 ~8 ~4 grass_block
setblock ~16 ~8 ~5 grass_block
setblock ~16 ~7 ~6 grass_block
setblock ~16 ~6 ~7 grass_block
setblock ~16 ~6 ~8 coarse_dirt
setblock ~16 ~5 ~9 grass_block
setblock ~16 ~5 ~10 grass_block
setblock ~16 ~4 ~11 andesite
setblock ~16 ~3 ~12 grass_block
setblock ~16 ~3 ~13 andesite
setblock ~16 ~2 ~14 grass_block
setblock ~16 ~2 ~15 grass_block
setblock ~16 ~2 ~16 grass_block
setblock ~16 ~1 ~17 grass_block
setblock ~16 ~1 ~18 grass_block
setblock ~16 ~ ~19 grass_block
setblock ~16 ~ ~20 grass_block
setblock ~16 ~ ~21 grass_block
setblock ~17 ~ ~-17 grass_block
setblock ~17 ~ ~-16 grass_block
setblock ~17 ~1 ~-15 grass_block
setblock ~17 ~1 ~-14 grass_block
setblock ~17 ~5 ~-13 grass_block
setblock ~17 ~6 ~-12 grass_block
setblock ~17 ~7 ~-11 grass_block
setblock ~17 ~7 ~-10 moss_block
setblock ~17 ~7 ~-9 grass_block
setblock ~17 ~8 ~-8 grass_block
setblock ~17 ~8 ~-7 coarse_dirt
setblock ~17 ~8 ~-6 moss_block
setblock ~17 ~8 ~-5 grass_block
setblock ~17 ~8 ~-4 grass_block
setblock ~17 ~9 ~-3 moss_block
setblock ~17 ~9 ~-2 grass_block
setblock ~17 ~9 ~-1 moss_block
setblock ~17 ~9 ~ grass_block
setblock ~17 ~8 ~1 grass_block
setblock ~17 ~8 ~2 grass_block
setblock ~17 ~8 ~3 grass_block
setblock ~17 ~8 ~4 grass_block
setblock ~17 ~7 ~5 grass_block
setblock ~17 ~6 ~6 grass_block
setblock ~17 ~6 ~7 grass_block
setblock ~17 ~5 ~8 grass_block
setblock ~17 ~5 ~9 grass_block
setblock ~17 ~4 ~10 grass_block
setblock ~17 ~4 ~11 grass_block
setblock ~17 ~3 ~12 grass_block
setblock ~17 ~3 ~13 grass_block
setblock ~17 ~2 ~14 grass_block
setblock ~17 ~2 ~15 grass_block
setblock ~17 ~1 ~16 grass_block
setblock ~17 ~1 ~17 grass_block
setblock ~17 ~1 ~18 grass_block
setblock ~17 ~ ~19 grass_block
setblock ~17 ~ ~20 grass_block
setblock ~17 ~ ~21 moss_block
setblock ~18 ~ ~-15 grass_block
setblock ~18 ~ ~-14 grass_block
setblock ~18 ~1 ~-13 grass_block
setblock ~18 ~5 ~-12 grass_block
setblock ~18 ~6 ~-11 coarse_dirt
setblock ~18 ~6 ~-10 andesite
setblock ~18 ~7 ~-9 grass_block
setblock ~18 ~7 ~-8 grass_block
setblock ~18 ~7 ~-7 grass_block
setblock ~18 ~8 ~-6 grass_block
setblock ~18 ~8 ~-5 grass_block
setblock ~18 ~8 ~-4 grass_block
setblock ~18 ~8 ~-3 grass_block
setblock ~18 ~8 ~-2 grass_block
setblock ~18 ~8 ~-1 grass_block
setblock ~18 ~8 ~ grass_block
setblock ~18 ~8 ~1 grass_block
setblock ~18 ~8 ~2 grass_block
setblock ~18 ~7 ~3 grass_block
setblock ~18 ~7 ~4 grass_block
setblock ~18 ~6 ~5 grass_block
setblock ~18 ~6 ~6 grass_block
setblock ~18 ~5 ~7 grass_block
setblock ~18 ~5 ~8 grass_block
setblock ~18 ~4 ~9 grass_block
setblock ~18 ~4 ~10 grass_block
setblock ~18 ~3 ~11 moss_block
setblock ~18 ~3 ~12 grass_block
setblock ~18 ~2 ~13 grass_block
setblock ~18 ~2 ~14 grass_block
setblock ~18 ~1 ~15 grass_block
setblock ~18 ~1 ~16 grass_block
setblock ~18 ~1 ~17 grass_block
setblock ~18 ~ ~18 grass_block
setblock ~18 ~ ~19 coarse_dirt
setblock ~18 ~ ~20 moss_block
setblock ~19 ~ ~-13 grass_block
setblock ~19 ~2 ~-12 grass_block
setblock ~19 ~5 ~-11 grass_block
setblock ~19 ~5 ~-10 moss_block
setblock ~19 ~6 ~-9 grass_block
setblock ~19 ~6 ~-8 grass_block
setblock ~19 ~7 ~-7 moss_block
setblock ~19 ~7 ~-6 coarse_dirt
setblock ~19 ~7 ~-5 grass_block
setblock ~19 ~7 ~-4 moss_block
setblock ~19 ~7 ~-3 coarse_dirt
setblock ~19 ~7 ~-2 andesite
setblock ~19 ~7 ~-1 andesite
setblock ~19 ~7 ~ grass_block
setblock ~19 ~7 ~1 grass_block
setblock ~19 ~7 ~2 grass_block
setblock ~19 ~7 ~3 grass_block
setblock ~19 ~6 ~4 grass_block
setblock ~19 ~6 ~5 grass_block
setblock ~19 ~5 ~6 grass_block
setblock ~19 ~5 ~7 grass_block
setblock ~19 ~4 ~8 moss_block
setblock ~19 ~4 ~9 andesite
setblock ~19 ~3 ~10 andesite
setblock ~19 ~3 ~11 grass_block
setblock ~19 ~2 ~12 grass_block
setblock ~19 ~2 ~13 grass_block
setblock ~19 ~2 ~14 coarse_dirt
setblock ~19 ~1 ~15 grass_block
setblock ~19 ~1 ~16 andesite
setblock ~19 ~ ~17 andesite
setblock ~19 ~ ~18 grass_block
setblock ~19 ~ ~19 grass_block
setblock ~20 ~ ~-12 grass_block
setblock ~20 ~3 ~-11 grass_block
setblock ~20 ~5 ~-10 grass_block
setblock ~20 ~5 ~-9 grass_block
setblock ~20 ~6 ~-8 coarse_dirt
setblock ~20 ~6 ~-7 grass_block
setblock ~20 ~6 ~-6 grass_block
setblock ~20 ~7 ~-5 grass_block
setblock ~20 ~7 ~-4 grass_block
setblock ~20 ~7 ~-3 grass_block
setblock ~20 ~7 ~-2 andesite
setblock ~20 ~7 ~-1 grass_block
setblock ~20 ~7 ~ grass_block
setblock ~20 ~7 ~1 coarse_dirt
setblock ~20 ~6 ~2 moss_block
setblock ~20 ~6 ~3 grass_block
setblock ~20 ~6 ~4 coarse_dirt
setblock ~20 ~5 ~5 grass_block
setblock ~20 ~5 ~6 grass_block
setblock ~20 ~5 ~7 coarse_dirt
setblock ~20 ~4 ~8 grass_block
setblock ~20 ~4 ~9 grass_block
setblock ~20 ~3 ~10 grass_block
setblock ~20 ~3 ~11 grass_block
setblock ~20 ~2 ~12 andesite
setblock ~20 ~2 ~13 moss_block
setblock ~20 ~1 ~14 moss_block
setblock ~20 ~1 ~15 andesite
setblock ~20 ~1 ~16 grass_block
setblock ~20 ~ ~17 grass_block
setblock ~20 ~ ~18 grass_block
setblock ~21 ~ ~-11 coarse_dirt
setblock ~21 ~3 ~-10 grass_block
setblock ~21 ~4 ~-9 grass_block
setblock ~21 ~5 ~-8 grass_block
setblock ~21 ~6 ~-7 grass_block
setblock ~21 ~6 ~-6 andesite
setblock ~21 ~6 ~-5 grass_block
setblock ~21 ~6 ~-4 moss_block
setblock ~21 ~6 ~-3 moss_block
setblock ~21 ~6 ~-2 grass_block
setblock ~21 ~6 ~-1 grass_block
setblock ~21 ~6 ~ moss_block
setblock ~21 ~6 ~1 moss_block
setblock ~21 ~6 ~2 grass_block
setblock ~21 ~6 ~3 grass_block
setblock ~21 ~5 ~4 grass_block
setblock ~21 ~5 ~5 grass_block
setblock ~21 ~5 ~6 grass_block
setblock ~21 ~4 ~7 grass_block
setblock ~21 ~4 ~8 grass_block
setblock ~21 ~3 ~9 coarse_dirt
setblock ~21 ~3 ~10 grass_block
setblock ~21 ~2 ~11 grass_block
setblock ~21 ~2 ~12 grass_block
setblock ~21 ~1 ~13 grass_block
setblock ~21 ~1 ~14 grass_block
setblock ~21 ~1 ~15 grass_block
setblock ~21 ~ ~16 grass_block
setblock ~21 ~ ~17 grass_block
setblock ~21 ~ ~18 grass_block
setblock ~22 ~ ~-10 grass_block
setblock ~22 ~3 ~-9 grass_block
setblock ~22 ~4 ~-8 grass_block
setblock ~22 ~5 ~-7 moss_block
setblock ~22 ~5 ~-6 grass_block
setblock ~22 ~5 ~-5 grass_block
setblock ~22 ~6 ~-4 grass_block
setblock ~22 ~6 ~-3 grass_block
setblock ~22 ~6 ~-2 moss_block
setblock ~22 ~6 ~-1 grass_block
setblock ~22 ~6 ~ grass_block
setblock ~22 ~6 ~1 grass_block
setblock ~22 ~5 ~2 grass_block
setblock ~22 ~5 ~3 andesite
setblock ~22 ~5 ~4 grass_block
setblock ~22 ~5 ~5 grass_block
setblock ~22 ~4 ~6 andesite
setblock ~22 ~4 ~7 grass_block
setblock ~22 ~3 ~8 grass_block
setblock ~22 ~3 ~9 andesite
setblock ~22 ~3 ~10 grass_block
setblock ~22 ~2 ~11 grass_block
setblock ~22 ~2 ~12 grass_block
setblock ~22 ~1 ~13 grass_block
setblock ~22 ~1 ~14 grass_block
setblock ~22 ~ ~15 grass_block
setblock ~22 ~ ~16 grass_block
setblock ~22 ~ ~17 grass_block
setblock ~23 ~1 ~-9 grass_block
setblock ~23 ~3 ~-8 grass_block
setblock ~23 ~4 ~-7 grass_block
setblock ~23 ~5 ~-6 grass_block
setblock ~23 ~5 ~-5 grass_block
setblock ~23 ~5 ~-4 grass_block
setblock ~23 ~5 ~-3 grass_block
setblock ~23 ~5 ~-2 coarse_dirt
setblock ~23 ~5 ~-1 grass_block
setblock ~23 ~5 ~ coarse_dirt
setblock ~23 ~5 ~1 andesite
setblock ~23 ~5 ~2 grass_block
setblock ~23 ~5 ~3 andesite
setblock ~23 ~4 ~4 grass_block
setblock ~23 ~4 ~5 grass_block
setblock ~23 ~4 ~6 grass_block
setblock ~23 ~3 ~7 grass_block
setblock ~23 ~3 ~8 grass_block
setblock ~23 ~3 ~9 grass_block
setblock ~23 ~2 ~10 grass_block
setblock ~23 ~2 ~11 grass_block
setblock ~23 ~1 ~12 andesite
setblock ~23 ~1 ~13 coarse_dirt
setblock ~23 ~ ~14 grass_block
setblock ~23 ~ ~15 coarse_dirt
setblock ~23 ~ ~16 grass_block
setblock ~24 ~2 ~-8 grass_block
setblock ~24 ~3 ~-7 grass_block
setblock ~24 ~4 ~-6 moss_block
setblock ~24 ~4 ~-5 grass_block
setblock ~24 ~4 ~-4 grass_block
setblock ~24 ~5 ~-3 grass_block
setblock ~24 ~5 ~-2 grass_block
setblock ~24 ~5 ~-1 grass_block
setblock ~24 ~5 ~ coarse_dirt
setblock ~24 ~5 ~1 grass_block
setblock ~24 ~4 ~2 moss_block
setblock ~24 ~4 ~3 grass_block
setblock ~24 ~4 ~4 coarse_dirt
setblock ~24 ~4 ~5 grass_block
setblock ~24 ~3 ~6 grass_block
setblock ~24 ~3 ~7 grass_block
setblock ~24 ~3 ~8 moss_block
setblock ~24 ~2 ~9 moss_block
setblock ~24 ~2 ~10 andesite
setblock ~24 ~1 ~11 andesite
setblock ~24 ~1 ~12 moss_block
setblock ~24 ~1 ~13 andesite
setblock ~24 ~ ~14 coarse_dirt
setblock ~24 ~ ~15 grass_block
setblock ~25 ~2 ~-7 grass_block
setblock ~25 ~3 ~-6 andesite
setblock ~25 ~4 ~-5 grass_block
setblock ~25 ~4 ~-4 grass_block
setblock ~25 ~4 ~-3 grass_block
setblock ~25 ~4 ~-2 grass_block
setblock ~25 ~4 ~-1 moss_block
setblock ~25 ~4 ~ andesite
setblock ~25 ~4 ~1 grass_block
setblock ~25 ~4 ~2 grass_block
setblock ~25 ~4 ~3 coarse_dirt
setblock ~25 ~4 ~4 grass_block
setblock ~25 ~3 ~5 grass_block
setblock ~25 ~3 ~6 grass_block
setblock ~25 ~3 ~7 grass_block
setblock ~25 ~2 ~8 grass_block
setblock ~25 ~2 ~9 grass_block
setblock ~25 ~2 ~10 grass_block
setblock ~25 ~1 ~11 grass_block
setblock ~25 ~1 ~12 grass_block
setblock ~25 ~ ~13 andesite
setblock ~25 ~ ~14 grass_block
setblock ~26 ~2 ~-6 grass_block
setblock ~26 ~3 ~-5 grass_block
setblock ~26 ~3 ~-4 grass_block
setblock ~26 ~3 ~-3 andesite
setblock ~26 ~4 ~-2 grass_block
setblock ~26 ~4 ~-1 grass_block
setblock ~26 ~4 ~ coarse_dirt
setblock ~26 ~4 ~1 grass_block
setblock ~26 ~3 ~2 grass_block
setblock ~26 ~3 ~3 grass_block
setblock ~26 ~3 ~4 moss_block
setblock ~26 ~3 ~5 grass_block
setblock ~26 ~3 ~6 grass_block
setblock ~26 ~2 ~7 grass_block
setblock ~26 ~2 ~8 grass_block
setblock ~26 ~2 ~9 andesite
setblock ~26 ~1 ~10 moss_block
setblock ~26 ~1 ~11 coarse_dirt
setblock ~26 ~ ~12 grass_block
setblock ~26 ~ ~13 coarse_dirt
setblock ~27 ~1 ~-5 moss_block
setblock ~27 ~2 ~-4 grass_block
setblock ~27 ~3 ~-3 grass_block
setblock ~27 ~3 ~-2 grass_block
setblock ~27 ~3 ~-1 grass_block
setblock ~27 ~3 ~ grass_block
setblock ~27 ~3 ~1 grass_block
setblock ~27 ~3 ~2 grass_block
setblock ~27 ~3 ~3 grass_block
setblock ~27 ~3 ~4 moss_block
setblock ~27 ~2 ~5 grass_block
setblock ~27 ~2 ~6 grass_block
setblock ~27 ~2 ~7 coarse_dirt
setblock ~27 ~1 ~8 andesite
setblock ~27 ~1 ~9 grass_block
setblock ~27 ~1 ~10 grass_block
setblock ~27 ~ ~11 grass_block
setblock ~27 ~ ~12 coarse_dirt
setblock ~28 ~1 ~-4 grass_block
setblock ~28 ~2 ~-3 grass_block
setblock ~28 ~2 ~-2 andesite
setblock ~28 ~2 ~-1 grass_block
setblock ~28 ~2 ~ coarse_dirt
setblock ~28 ~2 ~1 grass_block
setblock ~28 ~2 ~2 grass_block
setblock ~28 ~2 ~3 grass_block
setblock ~28 ~2 ~4 grass_block
setblock ~28 ~2 ~5 grass_block
setblock ~28 ~2 ~6 grass_block
setblock ~28 ~1 ~7 andesite
setblock ~28 ~1 ~8 grass_block
setblock ~28 ~1 ~9 andesite
setblock ~28 ~ ~10 grass_block
setblock ~28 ~ ~11 moss_block
setblock ~29 ~1 ~-2 grass_block
setblock ~29 ~1 ~-1 coarse_dirt
setblock ~29 ~2 ~ grass_block
setblock ~29 ~2 ~1 grass_block
setblock ~29 ~2 ~2 grass_block
setblock ~29 ~2 ~3 andesite
setblock ~29 ~1 ~4 coarse_dirt
setblock ~29 ~1 ~5 grass_block
setblock ~29 ~1 ~6 andesite
setblock ~29 ~1 ~7 grass_block
setblock ~29 ~ ~8 grass_block
setblock ~29 ~ ~9 grass_block
setblock ~29 ~ ~10 coarse_dirt
setblock ~30 ~ ~-1 grass_block
setblock ~30 ~ ~ moss_block
setblock ~30 ~1 ~1 grass_block
setblock ~30 ~1 ~2 grass_block
setblock ~30 ~1 ~3 grass_block
setblock ~30 ~1 ~4 grass_block
setblock ~30 ~ ~5 grass_block
setblock ~30 ~ ~6 coarse_dirt
setblock ~30 ~ ~7 grass_block
setblock ~30 ~ ~8 grass_block
fill ~-4 ~4 ~-20 ~-3 ~5 ~-19 andesite
setblock ~-4 ~6 ~-20 andesite keep
fill ~-12 ~7 ~-16 ~-11 ~8 ~-15 cobblestone
setblock ~-12 ~9 ~-16 cobblestone keep
fill ~-13 ~8 ~-14 ~-12 ~9 ~-13 mossy_cobblestone
setblock ~-13 ~10 ~-14 mossy_cobblestone keep
fill ~15 ~10 ~3 ~16 ~11 ~4 cobblestone
setblock ~15 ~12 ~3 cobblestone keep
fill ~-19 ~4 ~6 ~-18 ~5 ~7 stone
setblock ~-19 ~6 ~6 stone keep
fill ~-15 ~11 ~-6 ~-14 ~12 ~-5 mossy_cobblestone
setblock ~-15 ~13 ~-6 mossy_cobblestone keep
fill ~-1 ~10 ~16 ~ ~11 ~17 andesite
setblock ~-1 ~12 ~16 andesite keep
fill ~8 ~2 ~-22 ~9 ~3 ~-21 andesite
setblock ~8 ~4 ~-22 andesite keep
fill ~14 ~10 ~-7 ~15 ~11 ~-6 cobblestone
setblock ~14 ~12 ~-7 cobblestone keep
fill ~-17 ~6 ~8 ~-16 ~7 ~9 andesite
setblock ~-17 ~8 ~8 andesite keep
fill ~1 ~4 ~24 ~2 ~5 ~25 andesite
setblock ~1 ~6 ~24 andesite keep
fill ~7 ~3 ~-22 ~8 ~4 ~-21 andesite
setblock ~7 ~5 ~-22 andesite keep
fill ~4 ~10 ~18 ~5 ~11 ~19 stone
setblock ~4 ~12 ~18 stone keep
setblock ~14 ~11 ~5 water
setblock ~15 ~10 ~4 water
setblock ~16 ~8 ~4 water
setblock ~17 ~7 ~5 water
setblock ~18 ~7 ~4 water
setblock ~19 ~6 ~4 water
setblock ~20 ~5 ~5 water
setblock ~21 ~5 ~4 water
setblock ~22 ~5 ~4 water
setblock ~23 ~4 ~5 water
place feature minecraft:birch ~22 ~ ~-19
place feature minecraft:fancy_oak ~-14 ~13 ~8
place feature minecraft:spruce ~10 ~2 ~22
place feature minecraft:oak ~15 ~3 ~15
place feature minecraft:spruce ~-8 ~5 ~-20
place feature minecraft:birch ~-28 ~ ~-16
place feature minecraft:fancy_oak ~20 ~8 ~-3
place feature minecraft:birch ~-29 ~ ~4
place feature minecraft:spruce ~-13 ~ ~-27
place feature minecraft:spruce ~20 ~6 ~-10
place feature minecraft:fancy_oak ~21 ~1 ~17
place feature minecraft:spruce ~-13 ~5 ~20
place feature minecraft:birch ~18 ~8 ~-7
place feature minecraft:spruce ~-5 ~ ~31
place feature minecraft:oak ~-17 ~10 ~-4
place feature minecraft:spruce ~-16 ~6 ~-17
place feature minecraft:spruce ~-20 ~4 ~-1
place feature minecraft:birch ~17 ~1 ~19
place feature minecraft:birch ~-11 ~4 ~22
place feature minecraft:oak ~6 ~ ~27
place feature minecraft:spruce ~14 ~3 ~16
place feature minecraft:spruce ~-10 ~5 ~21
place feature minecraft:birch ~-7 ~9 ~14
place feature minecraft:spruce ~-2 ~8 ~20
setblock ~16 ~8 ~6 poppy keep
setblock ~16 ~10 ~-1 cornflower keep
setblock ~15 ~11 ~-1 lily_of_the_valley keep
setblock ~-10 ~16 ~8 lily_of_the_valley keep
setblock ~-13 ~ ~26 dandelion keep
setblock ~ ~16 ~13 dandelion keep
setblock ~3 ~ ~27 lily_of_the_valley keep
setblock ~-27 ~ ~2 oxeye_daisy keep
setblock ~10 ~6 ~18 lily_of_the_valley keep
setblock ~-4 ~16 ~8 oxeye_daisy keep
setblock ~16 ~10 ~ cornflower keep
setblock ~-6 ~16 ~10 dandelion keep
setblock ~20 ~ ~-14 short_grass keep
setblock ~30 ~ ~-6 fern keep
setblock ~-8 ~7 ~-18 short_grass keep
setblock ~8 ~2 ~-26 poppy keep
setblock ~-10 ~16 ~-3 lily_of_the_valley keep
setblock ~-12 ~11 ~-11 dandelion keep
setblock ~-2 ~15 ~13 short_grass keep
setblock ~19 ~ ~-19 sweet_berry_bush[age=2] keep
setblock ~ ~16 ~13 oxeye_daisy keep
setblock ~-5 ~16 ~-12 dandelion keep
setblock ~-10 ~16 ~-6 cornflower keep
setblock ~-14 ~9 ~-14 oxeye_daisy keep
setblock ~-10 ~9 ~13 fern keep
setblock ~-11 ~16 ~-5 short_grass keep
setblock ~-11 ~16 ~-5 sweet_berry_bush[age=2] keep
setblock ~13 ~4 ~16 lily_of_the_valley keep
setblock ~-20 ~5 ~-15 fern keep
setblock ~13 ~ ~26 short_grass keep
setblock ~-16 ~12 ~-1 short_grass keep
setblock ~-16 ~ ~27 fern keep
setblock ~27 ~3 ~-4 oxeye_daisy keep
setblock ~24 ~6 ~-1 poppy keep
setblock ~7 ~16 ~-10 short_grass keep
setblock ~12 ~10 ~-14 dandelion keep
setblock ~ ~5 ~24 lily_of_the_valley keep
setblock ~13 ~14 ~-5 short_grass keep
setblock ~4 ~2 ~25 short_grass keep
setblock ~-14 ~4 ~21 lily_of_the_valley keep
setblock ~-7 ~16 ~-9 oxeye_daisy keep
setblock ~-3 ~16 ~8 azure_bluet keep
setblock ~20 ~7 ~3 sweet_berry_bush[age=2] keep
setblock ~9 ~11 ~15 short_grass keep
setblock ~19 ~ ~-18 dandelion keep
setblock ~-3 ~9 ~17 dandelion keep
setblock ~-9 ~16 ~2 poppy keep
setblock ~-12 ~ ~-26 azure_bluet keep
setblock ~12 ~12 ~-8 short_grass keep
setblock ~6 ~ ~27 poppy keep
setblock ~10 ~16 ~2 lily_of_the_valley keep
setblock ~24 ~2 ~11 cornflower keep
setblock ~6 ~9 ~-18 sweet_berry_bush[age=2] keep
setblock ~25 ~ ~-12 short_grass keep
setblock ~-14 ~13 ~-2 oxeye_daisy keep
setblock ~-4 ~16 ~10 cornflower keep
setblock ~25 ~ ~-12 short_grass keep
setblock ~26 ~4 ~3 short_grass keep
setblock ~19 ~4 ~10 sweet_berry_bush[age=2] keep
fill ~-2 ~ ~-29 ~2 ~5 ~-29 air
fill ~-1 ~ ~-29 ~1 ~ ~-29 mossy_stone_brick_stairs[facing=south]
setblock ~-2 ~ ~-29 mossy_cobblestone
setblock ~2 ~ ~-29 mossy_cobblestone
setblock ~-2 ~1 ~-29 mossy_cobblestone_wall
setblock ~2 ~1 ~-29 mossy_cobblestone_wall
fill ~-2 ~1 ~-28 ~2 ~6 ~-28 air
fill ~-1 ~1 ~-28 ~1 ~1 ~-28 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-28 ~1 ~ ~-28 stone
setblock ~-2 ~1 ~-28 mossy_cobblestone
setblock ~2 ~1 ~-28 mossy_cobblestone
setblock ~-2 ~2 ~-28 mossy_cobblestone_wall
setblock ~2 ~2 ~-28 mossy_cobblestone_wall
fill ~-2 ~2 ~-27 ~2 ~7 ~-27 air
fill ~-1 ~2 ~-27 ~1 ~2 ~-27 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-27 ~1 ~1 ~-27 stone
setblock ~-2 ~2 ~-27 mossy_cobblestone
setblock ~2 ~2 ~-27 mossy_cobblestone
setblock ~-2 ~3 ~-27 mossy_cobblestone_wall
setblock ~2 ~3 ~-27 mossy_cobblestone_wall
fill ~-2 ~3 ~-26 ~2 ~8 ~-26 air
fill ~-1 ~3 ~-26 ~1 ~3 ~-26 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-26 ~1 ~2 ~-26 stone
setblock ~-2 ~3 ~-26 mossy_cobblestone
setblock ~2 ~3 ~-26 mossy_cobblestone
setblock ~-2 ~4 ~-26 mossy_cobblestone_wall
setblock ~2 ~4 ~-26 mossy_cobblestone_wall
setblock ~-2 ~5 ~-26 lantern
setblock ~2 ~5 ~-26 lantern
fill ~-2 ~4 ~-25 ~2 ~9 ~-25 air
fill ~-1 ~4 ~-25 ~1 ~4 ~-25 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-25 ~1 ~3 ~-25 stone
setblock ~-2 ~4 ~-25 mossy_cobblestone
setblock ~2 ~4 ~-25 mossy_cobblestone
setblock ~-2 ~5 ~-25 mossy_cobblestone_wall
setblock ~2 ~5 ~-25 mossy_cobblestone_wall
fill ~-2 ~5 ~-24 ~2 ~10 ~-24 air
fill ~-1 ~5 ~-24 ~1 ~5 ~-24 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-24 ~1 ~4 ~-24 stone
setblock ~-2 ~5 ~-24 mossy_cobblestone
setblock ~2 ~5 ~-24 mossy_cobblestone
setblock ~-2 ~6 ~-24 mossy_cobblestone_wall
setblock ~2 ~6 ~-24 mossy_cobblestone_wall
fill ~-2 ~6 ~-23 ~2 ~11 ~-23 air
fill ~-1 ~6 ~-23 ~1 ~6 ~-23 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-23 ~1 ~5 ~-23 stone
setblock ~-2 ~6 ~-23 mossy_cobblestone
setblock ~2 ~6 ~-23 mossy_cobblestone
setblock ~-2 ~7 ~-23 mossy_cobblestone_wall
setblock ~2 ~7 ~-23 mossy_cobblestone_wall
fill ~-2 ~7 ~-22 ~2 ~12 ~-22 air
fill ~-1 ~7 ~-22 ~1 ~7 ~-22 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-22 ~1 ~6 ~-22 stone
setblock ~-2 ~7 ~-22 mossy_cobblestone
setblock ~2 ~7 ~-22 mossy_cobblestone
setblock ~-2 ~8 ~-22 mossy_cobblestone_wall
setblock ~2 ~8 ~-22 mossy_cobblestone_wall
setblock ~-2 ~9 ~-22 lantern
setblock ~2 ~9 ~-22 lantern
fill ~-2 ~8 ~-21 ~2 ~13 ~-21 air
fill ~-1 ~8 ~-21 ~1 ~8 ~-21 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-21 ~1 ~7 ~-21 stone
setblock ~-2 ~8 ~-21 mossy_cobblestone
setblock ~2 ~8 ~-21 mossy_cobblestone
setblock ~-2 ~9 ~-21 mossy_cobblestone_wall
setblock ~2 ~9 ~-21 mossy_cobblestone_wall
fill ~-2 ~9 ~-20 ~2 ~14 ~-20 air
fill ~-1 ~9 ~-20 ~1 ~9 ~-20 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-20 ~1 ~8 ~-20 stone
setblock ~-2 ~9 ~-20 mossy_cobblestone
setblock ~2 ~9 ~-20 mossy_cobblestone
setblock ~-2 ~10 ~-20 mossy_cobblestone_wall
setblock ~2 ~10 ~-20 mossy_cobblestone_wall
fill ~-2 ~10 ~-19 ~2 ~15 ~-19 air
fill ~-1 ~10 ~-19 ~1 ~10 ~-19 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-19 ~1 ~9 ~-19 stone
setblock ~-2 ~10 ~-19 mossy_cobblestone
setblock ~2 ~10 ~-19 mossy_cobblestone
setblock ~-2 ~11 ~-19 mossy_cobblestone_wall
setblock ~2 ~11 ~-19 mossy_cobblestone_wall
fill ~-2 ~11 ~-18 ~2 ~16 ~-18 air
fill ~-1 ~11 ~-18 ~1 ~11 ~-18 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-18 ~1 ~10 ~-18 stone
setblock ~-2 ~11 ~-18 mossy_cobblestone
setblock ~2 ~11 ~-18 mossy_cobblestone
setblock ~-2 ~12 ~-18 mossy_cobblestone_wall
setblock ~2 ~12 ~-18 mossy_cobblestone_wall
setblock ~-2 ~13 ~-18 lantern
setblock ~2 ~13 ~-18 lantern
fill ~-2 ~12 ~-17 ~2 ~17 ~-17 air
fill ~-1 ~12 ~-17 ~1 ~12 ~-17 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-17 ~1 ~11 ~-17 stone
setblock ~-2 ~12 ~-17 mossy_cobblestone
setblock ~2 ~12 ~-17 mossy_cobblestone
setblock ~-2 ~13 ~-17 mossy_cobblestone_wall
setblock ~2 ~13 ~-17 mossy_cobblestone_wall
fill ~-2 ~13 ~-16 ~2 ~18 ~-16 air
fill ~-1 ~13 ~-16 ~1 ~13 ~-16 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-16 ~1 ~12 ~-16 stone
setblock ~-2 ~13 ~-16 mossy_cobblestone
setblock ~2 ~13 ~-16 mossy_cobblestone
setblock ~-2 ~14 ~-16 mossy_cobblestone_wall
setblock ~2 ~14 ~-16 mossy_cobblestone_wall
fill ~-2 ~14 ~-15 ~2 ~19 ~-15 air
fill ~-1 ~14 ~-15 ~1 ~14 ~-15 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-15 ~1 ~13 ~-15 stone
setblock ~-2 ~14 ~-15 mossy_cobblestone
setblock ~2 ~14 ~-15 mossy_cobblestone
setblock ~-2 ~15 ~-15 mossy_cobblestone_wall
setblock ~2 ~15 ~-15 mossy_cobblestone_wall
fill ~-2 ~15 ~-14 ~2 ~20 ~-14 air
fill ~-1 ~15 ~-14 ~1 ~15 ~-14 mossy_stone_brick_stairs[facing=south]
fill ~-1 ~ ~-14 ~1 ~14 ~-14 stone
setblock ~-2 ~15 ~-14 mossy_cobblestone
setblock ~2 ~15 ~-14 mossy_cobblestone
setblock ~-2 ~16 ~-14 mossy_cobblestone_wall
setblock ~2 ~16 ~-14 mossy_cobblestone_wall
setblock ~-2 ~17 ~-14 lantern
setblock ~2 ~17 ~-14 lantern
summon minecraft:text_display ~ ~2 ~-31 {billboard:"center",text:{text:"SUBIDA A LA CASA",color:"gold",bold:1b},background:1073741824}
