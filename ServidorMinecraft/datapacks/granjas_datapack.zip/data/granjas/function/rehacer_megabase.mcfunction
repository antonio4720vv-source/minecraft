execute unless entity @e[type=minecraft:marker,tag=granjas_mega,limit=1] run tellraw @s {"text":"No encuentro la megabase anterior. Usa /function granjas:megabase donde la quieras.","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega0
