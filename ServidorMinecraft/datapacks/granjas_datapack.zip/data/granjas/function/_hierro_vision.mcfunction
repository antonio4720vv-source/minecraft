kill @e[type=minecraft:zombie,name=Asustador,distance=..14]
fill ~-2 ~10 ~-2 ~2 ~10 ~-1 air replace minecraft:red_bed
setblock ~-2 ~10 ~2 red_bed[facing=south,part=foot]
setblock ~0 ~10 ~2 red_bed[facing=south,part=foot]
setblock ~2 ~10 ~2 red_bed[facing=south,part=foot]
setblock ~-2 ~10 ~3 red_bed[facing=south,part=head]
setblock ~0 ~10 ~3 red_bed[facing=south,part=head]
setblock ~2 ~10 ~3 red_bed[facing=south,part=head]
fill ~-2 ~9 ~5 ~3 ~12 ~9 air
fill ~-2 ~9 ~5 ~3 ~9 ~6 smooth_stone
fill ~-2 ~10 ~5 ~3 ~11 ~6 glass
fill ~-1 ~10 ~5 ~2 ~11 ~5 air
fill ~-2 ~12 ~5 ~3 ~12 ~6 glass
fill ~-1 ~11 ~4 ~2 ~11 ~4 air
fill ~-8 ~5 ~-8 ~9 ~5 ~9 air replace water
fill ~0 ~4 ~-8 ~1 ~4 ~9 air
fill ~-8 ~5 ~-8 ~-8 ~5 ~9 water
fill ~9 ~5 ~-8 ~9 ~5 ~9 water
fill ~0 ~4 ~-8 ~1 ~4 ~-8 water
fill ~0 ~4 ~9 ~1 ~4 ~9 water
summon minecraft:zombie ~0 ~10 ~5 {PersistenceRequired:1b,CustomName:"Asustador",equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
