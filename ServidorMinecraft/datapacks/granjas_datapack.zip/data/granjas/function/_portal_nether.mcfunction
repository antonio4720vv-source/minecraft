tellraw @s {"text":"Construyendo PORTAL DEL NETHER decorado...","color":"yellow"}
fill ~-8 ~-1 ~-8 ~8 ~11 ~8 air
fill ~-8 ~-1 ~-8 ~8 ~-1 ~8 blackstone
fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 polished_blackstone_bricks
fill ~-4 ~-1 ~-3 ~4 ~-1 ~3 polished_blackstone
fill ~-3 ~-1 ~-1 ~3 ~-1 ~1 crying_obsidian
setblock ~-7 ~-1 ~-7 crimson_nylium
setblock ~7 ~-1 ~-7 warped_nylium
setblock ~-7 ~-1 ~7 crimson_nylium
setblock ~7 ~-1 ~7 warped_nylium
setblock ~-5 ~-1 ~7 crimson_nylium
setblock ~5 ~-1 ~-7 warped_nylium
setblock ~-7 ~-1 ~-6 crimson_nylium
setblock ~-6 ~-1 ~-7 crimson_nylium
setblock ~6 ~-1 ~7 warped_nylium
setblock ~7 ~-1 ~6 warped_nylium
fill ~-2 ~ ~ ~2 ~5 ~ obsidian
fill ~-1 ~1 ~ ~1 ~4 ~ nether_portal[axis=x]
fill ~-3 ~ ~ ~-3 ~4 ~ polished_blackstone_wall
setblock ~-3 ~5 ~ gilded_blackstone
fill ~3 ~ ~ ~3 ~4 ~ polished_blackstone_wall
setblock ~3 ~5 ~ gilded_blackstone
fill ~-3 ~6 ~ ~3 ~6 ~ polished_blackstone_brick_slab[type=bottom]
setblock ~ ~6 ~ chiseled_polished_blackstone
setblock ~ ~7 ~ soul_campfire[lit=true]
setblock ~-2 ~ ~-1 crying_obsidian
setblock ~-2 ~ ~1 crying_obsidian
setblock ~2 ~ ~-1 crying_obsidian
setblock ~2 ~ ~1 crying_obsidian
fill ~-6 ~ ~-6 ~-6 ~5 ~-6 polished_basalt
setblock ~-6 ~6 ~-6 chiseled_nether_bricks
setblock ~-6 ~7 ~-6 soul_lantern
fill ~6 ~ ~-6 ~6 ~5 ~-6 polished_basalt
setblock ~6 ~6 ~-6 chiseled_nether_bricks
setblock ~6 ~7 ~-6 soul_lantern
fill ~-6 ~ ~6 ~-6 ~5 ~6 polished_basalt
setblock ~-6 ~6 ~6 chiseled_nether_bricks
setblock ~-6 ~7 ~6 soul_lantern
fill ~6 ~ ~6 ~6 ~5 ~6 polished_basalt
setblock ~6 ~6 ~6 chiseled_nether_bricks
setblock ~6 ~7 ~6 soul_lantern
fill ~-6 ~ ~ ~-6 ~2 ~ red_nether_bricks
setblock ~-6 ~3 ~ shroomlight
fill ~6 ~ ~ ~6 ~2 ~ red_nether_bricks
setblock ~6 ~3 ~ shroomlight
setblock ~-7 ~ ~-5 crimson_fungus
setblock ~-5 ~ ~-7 crimson_roots
setblock ~-7 ~ ~7 crimson_roots
setblock ~7 ~ ~-5 warped_fungus
setblock ~5 ~ ~-7 warped_roots
setblock ~7 ~ ~7 warped_roots
setblock ~-7 ~ ~-7 crimson_fungus
setblock ~7 ~ ~-7 warped_fungus
fill ~-8 ~ ~-8 ~8 ~ ~-8 nether_brick_fence
fill ~-8 ~ ~8 ~-2 ~ ~8 nether_brick_fence
fill ~2 ~ ~8 ~8 ~ ~8 nether_brick_fence
fill ~-8 ~ ~-8 ~-8 ~ ~8 nether_brick_fence
fill ~8 ~ ~-8 ~8 ~ ~8 nether_brick_fence
fill ~-1 ~ ~8 ~1 ~ ~8 air
fill ~-1 ~-1 ~7 ~1 ~-1 ~9 polished_blackstone_bricks
summon minecraft:text_display ~ ~9 ~ {billboard:"center",text:{text:"PORTAL AL NETHER",color:"red",bold:1b},background:1073741824}
tellraw @s {"text":"Portal del Nether listo. Lleva armadura de oro para que los piglins no te ataquen.","color":"green"}
