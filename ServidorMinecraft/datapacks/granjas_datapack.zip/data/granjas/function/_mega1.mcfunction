execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega1b
schedule function granjas:_mega2 4s replace
