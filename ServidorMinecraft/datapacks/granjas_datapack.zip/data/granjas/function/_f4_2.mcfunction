execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run function granjas:_f4_2b
schedule function granjas:_f4_3 3s replace
