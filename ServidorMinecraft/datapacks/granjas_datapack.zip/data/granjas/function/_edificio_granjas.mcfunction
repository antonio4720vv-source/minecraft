function granjas:_edif_a
function granjas:_edif_b
