execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run function granjas:_f3_1b
schedule function granjas:_f3_2 3s replace
