execute at @e[type=minecraft:marker,tag=granjas_f1,limit=1] run function granjas:_f1_2b
schedule function granjas:_f1_3 3s replace
