execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~0 ~ ~0 run forceload add ~ ~
tellraw @a {"text":"[TODO] Empezando la fase 4...","color":"yellow"}
execute at @e[type=minecraft:marker,tag=granjas_todo,limit=1] positioned ~0 ~ ~0 run function granjas:fase4
