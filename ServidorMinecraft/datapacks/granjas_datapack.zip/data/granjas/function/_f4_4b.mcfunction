tellraw @a {"text":"[Fase 4] Bunker: dormitorio, encantamientos, almacen y escalera...","color":"yellow"}
fill ~7 ~-28 ~3 ~48 ~-19 ~34 deepslate_tiles
fill ~8 ~-26 ~4 ~47 ~-20 ~33 air
fill ~8 ~-27 ~4 ~47 ~-27 ~33 polished_deepslate
setblock ~10 ~-19 ~6 sea_lantern
setblock ~10 ~-19 ~12 sea_lantern
setblock ~10 ~-19 ~18 sea_lantern
setblock ~10 ~-19 ~24 sea_lantern
setblock ~10 ~-19 ~30 sea_lantern
setblock ~16 ~-19 ~6 sea_lantern
setblock ~16 ~-19 ~12 sea_lantern
setblock ~16 ~-19 ~18 sea_lantern
setblock ~16 ~-19 ~24 sea_lantern
setblock ~16 ~-19 ~30 sea_lantern
setblock ~22 ~-19 ~6 sea_lantern
setblock ~22 ~-19 ~12 sea_lantern
setblock ~22 ~-19 ~18 sea_lantern
setblock ~22 ~-19 ~24 sea_lantern
setblock ~22 ~-19 ~30 sea_lantern
setblock ~28 ~-19 ~6 sea_lantern
setblock ~28 ~-19 ~12 sea_lantern
setblock ~28 ~-19 ~18 sea_lantern
setblock ~28 ~-19 ~24 sea_lantern
setblock ~28 ~-19 ~30 sea_lantern
setblock ~34 ~-19 ~6 sea_lantern
setblock ~34 ~-19 ~12 sea_lantern
setblock ~34 ~-19 ~18 sea_lantern
setblock ~34 ~-19 ~24 sea_lantern
setblock ~34 ~-19 ~30 sea_lantern
setblock ~40 ~-19 ~6 sea_lantern
setblock ~40 ~-19 ~12 sea_lantern
setblock ~40 ~-19 ~18 sea_lantern
setblock ~40 ~-19 ~24 sea_lantern
setblock ~40 ~-19 ~30 sea_lantern
setblock ~46 ~-19 ~6 sea_lantern
setblock ~46 ~-19 ~12 sea_lantern
setblock ~46 ~-19 ~18 sea_lantern
setblock ~46 ~-19 ~24 sea_lantern
setblock ~46 ~-19 ~30 sea_lantern
setblock ~8 ~-23 ~14 deepslate_bricks
setblock ~12 ~-23 ~14 deepslate_bricks
setblock ~16 ~-23 ~14 deepslate_bricks
setblock ~20 ~-23 ~14 deepslate_bricks
setblock ~24 ~-23 ~14 deepslate_bricks
setblock ~28 ~-23 ~14 deepslate_bricks
setblock ~32 ~-23 ~14 deepslate_bricks
setblock ~36 ~-23 ~14 deepslate_bricks
setblock ~40 ~-23 ~14 deepslate_bricks
setblock ~44 ~-23 ~14 deepslate_bricks
fill ~8 ~-26 ~14 ~47 ~-20 ~14 deepslate_bricks
fill ~18 ~-26 ~4 ~18 ~-20 ~13 deepslate_bricks
fill ~28 ~-26 ~4 ~28 ~-20 ~33 deepslate_bricks
fill ~12 ~-26 ~14 ~13 ~-25 ~14 air
fill ~22 ~-26 ~14 ~23 ~-25 ~14 air
fill ~36 ~-26 ~14 ~37 ~-25 ~14 air
fill ~18 ~-26 ~8 ~18 ~-25 ~9 air
fill ~28 ~-26 ~8 ~28 ~-25 ~9 air
fill ~28 ~-26 ~23 ~28 ~-25 ~24 air
fill ~36 ~-26 ~34 ~38 ~-24 ~34 air
setblock ~10 ~-26 ~6 red_bed[facing=north,part=foot]
setblock ~10 ~-26 ~5 red_bed[facing=north,part=head]
setblock ~12 ~-26 ~6 blue_bed[facing=north,part=foot]
setblock ~12 ~-26 ~5 blue_bed[facing=north,part=head]
setblock ~11 ~-26 ~5 barrel[facing=up]
setblock ~11 ~-25 ~5 lantern
fill ~16 ~-26 ~5 ~16 ~-25 ~8 barrel[facing=west]
fill ~9 ~-26 ~9 ~13 ~-26 ~11 red_carpet
setblock ~9 ~-26 ~13 crafting_table
setblock ~10 ~-26 ~13 furnace[facing=north]
setblock ~11 ~-26 ~13 smoker[facing=north]
setblock ~12 ~-26 ~13 blast_furnace[facing=north]
setblock ~14 ~-26 ~13 ender_chest[facing=north]
setblock ~23 ~-26 ~8 enchanting_table
fill ~21 ~-26 ~6 ~25 ~-25 ~6 bookshelf
fill ~21 ~-26 ~10 ~25 ~-25 ~10 bookshelf
fill ~21 ~-26 ~7 ~21 ~-25 ~9 bookshelf
fill ~25 ~-26 ~7 ~25 ~-25 ~9 bookshelf
fill ~23 ~-26 ~10 ~23 ~-25 ~10 air
fill ~22 ~-26 ~7 ~24 ~-26 ~9 purple_carpet
setblock ~23 ~-26 ~8 enchanting_table
setblock ~19 ~-26 ~12 brewing_stand
setblock ~20 ~-26 ~12 brewing_stand
setblock ~21 ~-26 ~12 water_cauldron[level=3]
setblock ~24 ~-26 ~12 anvil[facing=east]
setblock ~25 ~-26 ~12 smithing_table
setblock ~26 ~-26 ~12 grindstone[face=floor,facing=north]
setblock ~27 ~-26 ~5 barrel[facing=west]{Items:[{Slot:0b,id:"minecraft:blaze_powder",count:16},{Slot:1b,id:"minecraft:nether_wart",count:32},{Slot:2b,id:"minecraft:glass_bottle",count:16},{Slot:3b,id:"minecraft:lapis_lazuli",count:64}]}
fill ~29 ~-26 ~4 ~47 ~-24 ~4 barrel[facing=south]
fill ~29 ~-26 ~13 ~47 ~-24 ~13 barrel[facing=north]
fill ~32 ~-26 ~8 ~44 ~-25 ~9 barrel[facing=up]
setblock ~9 ~-24 ~16 light[level=15]
setblock ~9 ~-24 ~19 light[level=15]
setblock ~9 ~-24 ~22 light[level=15]
setblock ~9 ~-24 ~25 light[level=15]
setblock ~12 ~-24 ~16 light[level=15]
setblock ~12 ~-24 ~19 light[level=15]
setblock ~12 ~-24 ~22 light[level=15]
setblock ~12 ~-24 ~25 light[level=15]
setblock ~15 ~-24 ~16 light[level=15]
setblock ~15 ~-24 ~19 light[level=15]
setblock ~15 ~-24 ~22 light[level=15]
setblock ~15 ~-24 ~25 light[level=15]
setblock ~18 ~-24 ~16 light[level=15]
setblock ~18 ~-24 ~19 light[level=15]
setblock ~18 ~-24 ~22 light[level=15]
setblock ~18 ~-24 ~25 light[level=15]
setblock ~21 ~-24 ~16 light[level=15]
setblock ~21 ~-24 ~19 light[level=15]
setblock ~21 ~-24 ~22 light[level=15]
setblock ~21 ~-24 ~25 light[level=15]
setblock ~24 ~-24 ~16 light[level=15]
setblock ~24 ~-24 ~19 light[level=15]
setblock ~24 ~-24 ~22 light[level=15]
setblock ~24 ~-24 ~25 light[level=15]
setblock ~27 ~-24 ~16 light[level=15]
setblock ~27 ~-24 ~19 light[level=15]
setblock ~27 ~-24 ~22 light[level=15]
setblock ~27 ~-24 ~25 light[level=15]
summon minecraft:text_display ~13 ~-23 ~9 {billboard:"center",text:{text:"DORMITORIO",color:"yellow",bold:1b},background:1073741824}
summon minecraft:text_display ~23 ~-22 ~8 {billboard:"center",text:{text:"ENCANTAMIENTOS Y POCIONES",color:"yellow",bold:1b},background:1073741824}
summon minecraft:text_display ~38 ~-22 ~8 {billboard:"center",text:{text:"ALMACEN",color:"yellow",bold:1b},background:1073741824}
fill ~35 ~-1 ~61 ~39 ~4 ~61 deepslate_bricks
fill ~36 ~ ~61 ~38 ~3 ~61 air
fill ~36 ~-1 ~61 ~38 ~-1 ~61 deepslate_brick_stairs[facing=south]
setblock ~37 ~3 ~61 light[level=15]
fill ~35 ~-2 ~60 ~39 ~3 ~60 deepslate_bricks
fill ~36 ~-1 ~60 ~38 ~2 ~60 air
fill ~36 ~-2 ~60 ~38 ~-2 ~60 deepslate_brick_stairs[facing=south]
fill ~35 ~-3 ~59 ~39 ~2 ~59 deepslate_bricks
fill ~36 ~-2 ~59 ~38 ~1 ~59 air
fill ~36 ~-3 ~59 ~38 ~-3 ~59 deepslate_brick_stairs[facing=south]
fill ~35 ~-4 ~58 ~39 ~1 ~58 deepslate_bricks
fill ~36 ~-3 ~58 ~38 ~ ~58 air
fill ~36 ~-4 ~58 ~38 ~-4 ~58 deepslate_brick_stairs[facing=south]
setblock ~37 ~ ~58 light[level=15]
fill ~35 ~-5 ~57 ~39 ~ ~57 deepslate_bricks
fill ~36 ~-4 ~57 ~38 ~-1 ~57 air
fill ~36 ~-5 ~57 ~38 ~-5 ~57 deepslate_brick_stairs[facing=south]
fill ~35 ~-6 ~56 ~39 ~-1 ~56 deepslate_bricks
fill ~36 ~-5 ~56 ~38 ~-2 ~56 air
fill ~36 ~-6 ~56 ~38 ~-6 ~56 deepslate_brick_stairs[facing=south]
fill ~35 ~-7 ~55 ~39 ~-2 ~55 deepslate_bricks
fill ~36 ~-6 ~55 ~38 ~-3 ~55 air
fill ~36 ~-7 ~55 ~38 ~-7 ~55 deepslate_brick_stairs[facing=south]
setblock ~37 ~-3 ~55 light[level=15]
fill ~35 ~-8 ~54 ~39 ~-3 ~54 deepslate_bricks
fill ~36 ~-7 ~54 ~38 ~-4 ~54 air
fill ~36 ~-8 ~54 ~38 ~-8 ~54 deepslate_brick_stairs[facing=south]
fill ~35 ~-9 ~53 ~39 ~-4 ~53 deepslate_bricks
fill ~36 ~-8 ~53 ~38 ~-5 ~53 air
fill ~36 ~-9 ~53 ~38 ~-9 ~53 deepslate_brick_stairs[facing=south]
fill ~35 ~-10 ~52 ~39 ~-5 ~52 deepslate_bricks
fill ~36 ~-9 ~52 ~38 ~-6 ~52 air
fill ~36 ~-10 ~52 ~38 ~-10 ~52 deepslate_brick_stairs[facing=south]
setblock ~37 ~-6 ~52 light[level=15]
fill ~35 ~-11 ~51 ~39 ~-6 ~51 deepslate_bricks
fill ~36 ~-10 ~51 ~38 ~-7 ~51 air
fill ~36 ~-11 ~51 ~38 ~-11 ~51 deepslate_brick_stairs[facing=south]
fill ~35 ~-12 ~50 ~39 ~-7 ~50 deepslate_bricks
fill ~36 ~-11 ~50 ~38 ~-8 ~50 air
fill ~36 ~-12 ~50 ~38 ~-12 ~50 deepslate_brick_stairs[facing=south]
fill ~35 ~-13 ~49 ~39 ~-8 ~49 deepslate_bricks
fill ~36 ~-12 ~49 ~38 ~-9 ~49 air
fill ~36 ~-13 ~49 ~38 ~-13 ~49 deepslate_brick_stairs[facing=south]
setblock ~37 ~-9 ~49 light[level=15]
fill ~35 ~-14 ~48 ~39 ~-9 ~48 deepslate_bricks
fill ~36 ~-13 ~48 ~38 ~-10 ~48 air
fill ~36 ~-14 ~48 ~38 ~-14 ~48 deepslate_brick_stairs[facing=south]
fill ~35 ~-15 ~47 ~39 ~-10 ~47 deepslate_bricks
fill ~36 ~-14 ~47 ~38 ~-11 ~47 air
fill ~36 ~-15 ~47 ~38 ~-15 ~47 deepslate_brick_stairs[facing=south]
fill ~35 ~-16 ~46 ~39 ~-11 ~46 deepslate_bricks
fill ~36 ~-15 ~46 ~38 ~-12 ~46 air
fill ~36 ~-16 ~46 ~38 ~-16 ~46 deepslate_brick_stairs[facing=south]
setblock ~37 ~-12 ~46 light[level=15]
fill ~35 ~-17 ~45 ~39 ~-12 ~45 deepslate_bricks
fill ~36 ~-16 ~45 ~38 ~-13 ~45 air
fill ~36 ~-17 ~45 ~38 ~-17 ~45 deepslate_brick_stairs[facing=south]
fill ~35 ~-18 ~44 ~39 ~-13 ~44 deepslate_bricks
fill ~36 ~-17 ~44 ~38 ~-14 ~44 air
fill ~36 ~-18 ~44 ~38 ~-18 ~44 deepslate_brick_stairs[facing=south]
fill ~35 ~-19 ~43 ~39 ~-14 ~43 deepslate_bricks
fill ~36 ~-18 ~43 ~38 ~-15 ~43 air
fill ~36 ~-19 ~43 ~38 ~-19 ~43 deepslate_brick_stairs[facing=south]
setblock ~37 ~-15 ~43 light[level=15]
fill ~35 ~-20 ~42 ~39 ~-15 ~42 deepslate_bricks
fill ~36 ~-19 ~42 ~38 ~-16 ~42 air
fill ~36 ~-20 ~42 ~38 ~-20 ~42 deepslate_brick_stairs[facing=south]
fill ~35 ~-21 ~41 ~39 ~-16 ~41 deepslate_bricks
fill ~36 ~-20 ~41 ~38 ~-17 ~41 air
fill ~36 ~-21 ~41 ~38 ~-21 ~41 deepslate_brick_stairs[facing=south]
fill ~35 ~-22 ~40 ~39 ~-17 ~40 deepslate_bricks
fill ~36 ~-21 ~40 ~38 ~-18 ~40 air
fill ~36 ~-22 ~40 ~38 ~-22 ~40 deepslate_brick_stairs[facing=south]
setblock ~37 ~-18 ~40 light[level=15]
fill ~35 ~-23 ~39 ~39 ~-18 ~39 deepslate_bricks
fill ~36 ~-22 ~39 ~38 ~-19 ~39 air
fill ~36 ~-23 ~39 ~38 ~-23 ~39 deepslate_brick_stairs[facing=south]
fill ~35 ~-24 ~38 ~39 ~-19 ~38 deepslate_bricks
fill ~36 ~-23 ~38 ~38 ~-20 ~38 air
fill ~36 ~-24 ~38 ~38 ~-24 ~38 deepslate_brick_stairs[facing=south]
fill ~35 ~-25 ~37 ~39 ~-20 ~37 deepslate_bricks
fill ~36 ~-24 ~37 ~38 ~-21 ~37 air
fill ~36 ~-25 ~37 ~38 ~-25 ~37 deepslate_brick_stairs[facing=south]
setblock ~37 ~-21 ~37 light[level=15]
fill ~35 ~-26 ~36 ~39 ~-21 ~36 deepslate_bricks
fill ~36 ~-25 ~36 ~38 ~-22 ~36 air
fill ~36 ~-26 ~36 ~38 ~-26 ~36 deepslate_brick_stairs[facing=south]
fill ~35 ~-27 ~35 ~39 ~-22 ~35 deepslate_bricks
fill ~36 ~-26 ~35 ~38 ~-23 ~35 air
fill ~36 ~-27 ~35 ~38 ~-27 ~35 deepslate_brick_stairs[facing=south]
fill ~36 ~-27 ~35 ~38 ~-27 ~35 polished_deepslate
fill ~36 ~-26 ~35 ~38 ~-24 ~35 air
fill ~35 ~-1 ~62 ~39 ~-1 ~64 polished_deepslate
fill ~35 ~4 ~57 ~39 ~4 ~64 deepslate_tile_slab[type=bottom]
fill ~35 ~ ~64 ~35 ~3 ~64 deepslate_brick_wall
fill ~39 ~ ~64 ~39 ~3 ~64 deepslate_brick_wall
setblock ~34 ~ ~64 lantern
setblock ~40 ~ ~64 lantern
summon minecraft:text_display ~37 ~3 ~65 {billboard:"center",text:{text:"BUNKER\nbaja por la escalera",color:"gold",bold:1b},background:1073741824}
