tellraw @s {"text":"Construyendo CASA de madera...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~13 ~11 ~12 air
fill ~-1 ~-1 ~-1 ~13 ~-1 ~12 grass_block
fill ~ ~-1 ~ ~12 ~-1 ~10 cobblestone
fill ~1 ~-1 ~1 ~11 ~-1 ~9 oak_planks
fill ~1 ~ ~1 ~11 ~3 ~9 oak_planks hollow
fill ~1 ~ ~1 ~1 ~3 ~1 oak_log
fill ~11 ~ ~1 ~11 ~3 ~1 oak_log
fill ~1 ~ ~9 ~1 ~3 ~9 oak_log
fill ~11 ~ ~9 ~11 ~3 ~9 oak_log
fill ~ ~3 ~ ~12 ~3 ~10 spruce_planks
fill ~1 ~3 ~1 ~11 ~3 ~9 oak_planks
fill ~ ~4 ~ ~12 ~4 ~ spruce_stairs[facing=south]
fill ~ ~4 ~10 ~12 ~4 ~10 spruce_stairs[facing=north]
fill ~1 ~4 ~1 ~1 ~4 ~9 oak_planks
fill ~11 ~4 ~1 ~11 ~4 ~9 oak_planks
fill ~ ~5 ~1 ~12 ~5 ~1 spruce_stairs[facing=south]
fill ~ ~5 ~9 ~12 ~5 ~9 spruce_stairs[facing=north]
fill ~1 ~5 ~2 ~1 ~5 ~8 oak_planks
fill ~11 ~5 ~2 ~11 ~5 ~8 oak_planks
fill ~ ~6 ~2 ~12 ~6 ~2 spruce_stairs[facing=south]
fill ~ ~6 ~8 ~12 ~6 ~8 spruce_stairs[facing=north]
fill ~1 ~6 ~3 ~1 ~6 ~7 oak_planks
fill ~11 ~6 ~3 ~11 ~6 ~7 oak_planks
fill ~ ~7 ~3 ~12 ~7 ~3 spruce_stairs[facing=south]
fill ~ ~7 ~7 ~12 ~7 ~7 spruce_stairs[facing=north]
fill ~1 ~7 ~4 ~1 ~7 ~6 oak_planks
fill ~11 ~7 ~4 ~11 ~7 ~6 oak_planks
fill ~ ~8 ~4 ~12 ~8 ~4 spruce_stairs[facing=south]
fill ~ ~8 ~6 ~12 ~8 ~6 spruce_stairs[facing=north]
fill ~1 ~8 ~5 ~1 ~8 ~5 oak_planks
fill ~11 ~8 ~5 ~11 ~8 ~5 oak_planks
fill ~ ~9 ~5 ~12 ~9 ~5 spruce_slab[type=bottom]
fill ~3 ~1 ~1 ~3 ~2 ~1 glass_pane[east=true,west=true]
fill ~3 ~1 ~9 ~3 ~2 ~9 glass_pane[east=true,west=true]
fill ~4 ~1 ~1 ~4 ~2 ~1 glass_pane[east=true,west=true]
fill ~4 ~1 ~9 ~4 ~2 ~9 glass_pane[east=true,west=true]
fill ~8 ~1 ~1 ~8 ~2 ~1 glass_pane[east=true,west=true]
fill ~8 ~1 ~9 ~8 ~2 ~9 glass_pane[east=true,west=true]
fill ~9 ~1 ~1 ~9 ~2 ~1 glass_pane[east=true,west=true]
fill ~9 ~1 ~9 ~9 ~2 ~9 glass_pane[east=true,west=true]
fill ~1 ~1 ~4 ~1 ~2 ~4 glass_pane[north=true,south=true]
fill ~11 ~1 ~4 ~11 ~2 ~4 glass_pane[north=true,south=true]
fill ~1 ~1 ~6 ~1 ~2 ~6 glass_pane[north=true,south=true]
fill ~11 ~1 ~6 ~11 ~2 ~6 glass_pane[north=true,south=true]
setblock ~6 ~ ~9 iron_door[half=lower,facing=north,hinge=left]
setblock ~6 ~1 ~9 iron_door[half=upper,facing=north,hinge=left]
setblock ~7 ~1 ~10 stone_button[face=wall,facing=south]
setblock ~7 ~1 ~8 stone_button[face=wall,facing=north]
fill ~5 ~-1 ~10 ~7 ~-1 ~12 cobblestone
setblock ~4 ~ ~10 lantern
setblock ~8 ~ ~10 lantern
setblock ~2 ~ ~3 red_bed[facing=north,part=foot]
setblock ~2 ~ ~2 red_bed[facing=north,part=head]
setblock ~4 ~ ~3 blue_bed[facing=north,part=foot]
setblock ~4 ~ ~2 blue_bed[facing=north,part=head]
setblock ~3 ~ ~2 oak_planks
setblock ~3 ~1 ~2 lantern
fill ~10 ~ ~2 ~10 ~1 ~4 barrel[facing=west]
setblock ~10 ~ ~5 crafting_table
setblock ~10 ~ ~6 furnace[facing=west]
setblock ~10 ~ ~7 smoker[facing=west]
setblock ~10 ~ ~8 anvil[facing=north]
setblock ~2 ~ ~8 enchanting_table
fill ~2 ~ ~6 ~2 ~1 ~6 bookshelf
setblock ~2 ~ ~7 bookshelf
setblock ~3 ~ ~8 bookshelf
fill ~5 ~ ~4 ~7 ~ ~6 red_carpet
setblock ~5 ~2 ~5 lantern[hanging=true]
setblock ~8 ~2 ~5 lantern[hanging=true]
setblock ~3 ~2 ~7 lantern[hanging=true]
setblock ~7 ~ ~2 oak_fence
setblock ~7 ~1 ~2 flower_pot
summon minecraft:text_display ~6 ~3 ~11 {billboard:"center",text:{text:"CASA",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Casa lista: 2 camas, 6 barriles, mesa de crafteo, horno, ahumador, yunque y mesa de encantar. Puerta de hierro con boton (los zombis no la rompen).","color":"green"}
