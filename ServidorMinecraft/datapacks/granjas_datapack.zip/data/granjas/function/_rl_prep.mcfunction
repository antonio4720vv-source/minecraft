kill @e[type=minecraft:marker,tag=riel_w]
kill @e[type=minecraft:marker,tag=riel_s]
$execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run summon minecraft:marker ~3 ~$(y) ~-10 {Tags:["riel_w"]}
$execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run summon minecraft:marker ~3 ~$(y) ~-10 {Tags:["riel_s"]}
execute store result score #wx rieles run data get entity @e[type=minecraft:marker,tag=riel_w,limit=1] Pos[0]
execute store result score #wy rieles run data get entity @e[type=minecraft:marker,tag=riel_w,limit=1] Pos[1]
execute store result score #wz rieles run data get entity @e[type=minecraft:marker,tag=riel_w,limit=1] Pos[2]
$execute store result score #tx rieles run data get entity @e[type=minecraft:marker,tag=$(tag),limit=1] Pos[0]
$execute store result score #ty rieles run data get entity @e[type=minecraft:marker,tag=$(tag),limit=1] Pos[1]
$execute store result score #tz rieles run data get entity @e[type=minecraft:marker,tag=$(tag),limit=1] Pos[2]
$scoreboard players remove #tx rieles $(sep)
scoreboard players remove #tz rieles 6
scoreboard players remove #ty rieles 1
scoreboard players operation #remx rieles = #tx rieles
scoreboard players operation #remx rieles -= #wx rieles
scoreboard players operation #remz rieles = #tz rieles
scoreboard players operation #remz rieles -= #wz rieles
scoreboard players operation #dy rieles = #ty rieles
scoreboard players operation #dy rieles -= #wy rieles
scoreboard players set #sx rieles 1
execute if score #remx rieles matches ..-1 run scoreboard players set #sx rieles -1
execute if score #remx rieles matches ..-1 run scoreboard players operation #remx rieles *= #-1 rieles
scoreboard players set #sz rieles 1
execute if score #remz rieles matches ..-1 run scoreboard players set #sz rieles -1
execute if score #remz rieles matches ..-1 run scoreboard players operation #remz rieles *= #-1 rieles
scoreboard players operation #ady rieles = #dy rieles
execute if score #ady rieles matches ..-1 run scoreboard players operation #ady rieles *= #-1 rieles
data modify storage granjas:riel p set from storage granjas:riel l
scoreboard players set #i rieles 0
scoreboard players set #corner rieles 0
scoreboard players set #hecho rieles 0
execute if score #remx rieles matches 1.. run function granjas:_rl_ejex
execute if score #remx rieles matches 0 run function granjas:_rl_ejez
scoreboard players operation #fdx rieles = #edx rieles
scoreboard players operation #fdz rieles = #edz rieles
scoreboard players operation #fox rieles = #eox rieles
scoreboard players operation #foz rieles = #eoz rieles
execute as @e[type=minecraft:marker,tag=riel_w,limit=1] at @s run forceload add ~ ~
schedule function granjas:_rl_tick 1t replace
