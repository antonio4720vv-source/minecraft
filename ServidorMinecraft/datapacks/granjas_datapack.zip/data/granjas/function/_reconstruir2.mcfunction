execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] run function granjas:_aplanar3
execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] run function granjas:_construir
execute at @e[type=minecraft:marker,tag=granjas_hub,limit=1] positioned ~-58 ~-7 ~-40 run kill @e[type=minecraft:item,dx=122,dy=60,dz=62]
