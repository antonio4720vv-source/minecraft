tellraw @a {"text":"Construyendo las 8 granjas alrededor de la plaza...","color":"yellow"}
fill ~-58 ~-1 ~-3 ~62 ~-1 ~3 stone_bricks
fill ~-4 ~-1 ~-6 ~4 ~-1 ~6 polished_andesite
setblock ~-58 ~ ~-3 lantern
setblock ~-58 ~ ~3 lantern
setblock ~-50 ~ ~-3 lantern
setblock ~-50 ~ ~3 lantern
setblock ~-42 ~ ~-3 lantern
setblock ~-42 ~ ~3 lantern
setblock ~-34 ~ ~-3 lantern
setblock ~-34 ~ ~3 lantern
setblock ~-26 ~ ~-3 lantern
setblock ~-26 ~ ~3 lantern
setblock ~-18 ~ ~-3 lantern
setblock ~-18 ~ ~3 lantern
setblock ~-10 ~ ~-3 lantern
setblock ~-10 ~ ~3 lantern
setblock ~-2 ~ ~-3 lantern
setblock ~-2 ~ ~3 lantern
setblock ~6 ~ ~-3 lantern
setblock ~6 ~ ~3 lantern
setblock ~14 ~ ~-3 lantern
setblock ~14 ~ ~3 lantern
setblock ~22 ~ ~-3 lantern
setblock ~22 ~ ~3 lantern
setblock ~30 ~ ~-3 lantern
setblock ~30 ~ ~3 lantern
setblock ~38 ~ ~-3 lantern
setblock ~38 ~ ~3 lantern
setblock ~46 ~ ~-3 lantern
setblock ~46 ~ ~3 lantern
setblock ~54 ~ ~-3 lantern
setblock ~54 ~ ~3 lantern
setblock ~62 ~ ~-3 lantern
setblock ~62 ~ ~3 lantern
execute positioned ~-48 ~ ~-30 run function granjas:_hierro
execute positioned ~-20 ~ ~-26 run function granjas:_experiencia
execute positioned ~-2 ~ ~-24 run function granjas:_aldeanos
execute positioned ~24 ~ ~-34 run function granjas:_mobs
execute positioned ~-48 ~ ~12 run function granjas:_comercio
execute positioned ~-10 ~ ~13 run function granjas:_cana
execute positioned ~10 ~ ~12 run function granjas:_comida
execute positioned ~30 ~ ~12 run function granjas:_hornos
execute positioned ~48 ~ ~-14 run function granjas:_casa
summon minecraft:text_display ~ ~3 ~ {billboard:"center",text:{text:"PLAZA DE GRANJAS\nNorte: hierro, experiencia, criadero, mobs\nSur: comercio, cana, comida, hornos\nEste: la CASA",color:"aqua",bold:1b}}
function granjas:respaldo_on
tellraw @a {"text":"Listo! Las 8 granjas estan alrededor de la plaza. El modo respaldo esta ACTIVADO.","color":"green"}
