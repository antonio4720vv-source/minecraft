execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega2b
schedule function granjas:_mega3 4s replace
