execute at @e[type=minecraft:marker,tag=granjas_f1,limit=1] run forceload add ~-2 ~-4 ~70 ~26
tellraw @a {"text":"[Fase 1] Preparando terreno de 72 x 30 bloques al ESTE y SUR. Tarda unos 25 segundos. No te alejes.","color":"gold"}
schedule function granjas:_f1_1 5s replace
