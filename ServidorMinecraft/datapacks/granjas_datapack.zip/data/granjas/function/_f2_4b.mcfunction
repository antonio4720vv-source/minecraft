tellraw @a {"text":"[Fase 2] 10 granjas de bambu...","color":"yellow"}
fill ~67 ~-1 ~ ~156 ~-1 ~38 polished_andesite
summon minecraft:text_display ~66 ~3 ~19 {billboard:"center",text:{text:"PABELLON\nfilas 1-2: BAMBU | 3: SANDIA | 4: CALABAZA\nbarriles en el lado oeste de cada granja",color:"aqua",bold:1b},background:1073741824}
execute positioned ~72 ~ ~6 run function granjas:_bambu
execute positioned ~89 ~ ~6 run function granjas:_bambu
execute positioned ~106 ~ ~6 run function granjas:_bambu
execute positioned ~123 ~ ~6 run function granjas:_bambu
execute positioned ~140 ~ ~6 run function granjas:_bambu
execute positioned ~72 ~ ~15 run function granjas:_bambu
execute positioned ~89 ~ ~15 run function granjas:_bambu
execute positioned ~106 ~ ~15 run function granjas:_bambu
execute positioned ~123 ~ ~15 run function granjas:_bambu
execute positioned ~140 ~ ~15 run function granjas:_bambu
