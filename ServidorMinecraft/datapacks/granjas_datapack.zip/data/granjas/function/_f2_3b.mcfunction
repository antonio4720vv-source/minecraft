tellraw @a {"text":"[Fase 2] Invernadero con 10 cultivos...","color":"yellow"}
fill ~2 ~-1 ~22 ~58 ~-1 ~45 stone_bricks
fill ~3 ~ ~23 ~57 ~5 ~44 air
fill ~2 ~ ~22 ~58 ~4 ~22 glass
fill ~2 ~ ~45 ~58 ~4 ~45 glass
fill ~2 ~ ~22 ~2 ~4 ~45 glass
fill ~58 ~ ~22 ~58 ~4 ~45 glass
fill ~2 ~5 ~22 ~58 ~5 ~45 glass
fill ~2 ~ ~22 ~2 ~5 ~22 stripped_birch_log
fill ~2 ~ ~45 ~2 ~5 ~45 stripped_birch_log
fill ~10 ~ ~22 ~10 ~5 ~22 stripped_birch_log
fill ~10 ~ ~45 ~10 ~5 ~45 stripped_birch_log
fill ~18 ~ ~22 ~18 ~5 ~22 stripped_birch_log
fill ~18 ~ ~45 ~18 ~5 ~45 stripped_birch_log
fill ~26 ~ ~22 ~26 ~5 ~22 stripped_birch_log
fill ~26 ~ ~45 ~26 ~5 ~45 stripped_birch_log
fill ~34 ~ ~22 ~34 ~5 ~22 stripped_birch_log
fill ~34 ~ ~45 ~34 ~5 ~45 stripped_birch_log
fill ~42 ~ ~22 ~42 ~5 ~22 stripped_birch_log
fill ~42 ~ ~45 ~42 ~5 ~45 stripped_birch_log
fill ~50 ~ ~22 ~50 ~5 ~22 stripped_birch_log
fill ~50 ~ ~45 ~50 ~5 ~45 stripped_birch_log
fill ~58 ~ ~22 ~58 ~5 ~22 stripped_birch_log
fill ~58 ~ ~45 ~58 ~5 ~45 stripped_birch_log
fill ~4 ~-1 ~24 ~12 ~-1 ~32 dirt
fill ~4 ~-1 ~24 ~12 ~-1 ~32 farmland[moisture=7]
setblock ~8 ~-1 ~28 water
fill ~4 ~ ~24 ~12 ~ ~32 wheat[age=7]
setblock ~8 ~ ~28 lily_pad
setblock ~3 ~ ~23 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:wheat_seeds",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~8 ~3 ~28 {billboard:"center",text:{text:"TRIGO",color:"yellow",bold:1b},background:1073741824}
fill ~15 ~-1 ~24 ~23 ~-1 ~32 dirt
fill ~15 ~-1 ~24 ~23 ~-1 ~32 farmland[moisture=7]
setblock ~19 ~-1 ~28 water
fill ~15 ~ ~24 ~23 ~ ~32 carrots[age=7]
setblock ~19 ~ ~28 lily_pad
setblock ~14 ~ ~23 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:carrot",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~19 ~3 ~28 {billboard:"center",text:{text:"ZANAHORIAS",color:"yellow",bold:1b},background:1073741824}
fill ~26 ~-1 ~24 ~34 ~-1 ~32 dirt
fill ~26 ~-1 ~24 ~34 ~-1 ~32 farmland[moisture=7]
setblock ~30 ~-1 ~28 water
fill ~26 ~ ~24 ~34 ~ ~32 potatoes[age=7]
setblock ~30 ~ ~28 lily_pad
setblock ~25 ~ ~23 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:potato",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~30 ~3 ~28 {billboard:"center",text:{text:"PAPAS",color:"yellow",bold:1b},background:1073741824}
fill ~37 ~-1 ~24 ~45 ~-1 ~32 dirt
fill ~37 ~-1 ~24 ~45 ~-1 ~32 farmland[moisture=7]
setblock ~41 ~-1 ~28 water
fill ~37 ~ ~24 ~45 ~ ~32 beetroots[age=3]
setblock ~41 ~ ~28 lily_pad
setblock ~36 ~ ~23 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:beetroot_seeds",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~41 ~3 ~28 {billboard:"center",text:{text:"REMOLACHAS",color:"yellow",bold:1b},background:1073741824}
fill ~48 ~-1 ~24 ~56 ~-1 ~32 dirt
fill ~48 ~-1 ~24 ~56 ~-1 ~32 grass_block
fill ~48 ~ ~24 ~56 ~ ~24 sweet_berry_bush[age=3]
fill ~48 ~ ~26 ~56 ~ ~26 sweet_berry_bush[age=3]
fill ~48 ~ ~28 ~56 ~ ~28 sweet_berry_bush[age=3]
fill ~48 ~ ~30 ~56 ~ ~30 sweet_berry_bush[age=3]
fill ~48 ~ ~32 ~56 ~ ~32 sweet_berry_bush[age=3]
setblock ~47 ~ ~23 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:sweet_berries",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~52 ~3 ~28 {billboard:"center",text:{text:"BAYAS DULCES",color:"yellow",bold:1b},background:1073741824}
fill ~4 ~-1 ~35 ~12 ~-1 ~43 dirt
fill ~4 ~-1 ~35 ~12 ~-1 ~43 moss_block
setblock ~4 ~4 ~35 jungle_planks
setblock ~4 ~3 ~35 cave_vines_plant[berries=true]
setblock ~4 ~2 ~35 cave_vines[berries=true,age=25]
setblock ~4 ~4 ~37 jungle_planks
setblock ~4 ~3 ~37 cave_vines_plant[berries=true]
setblock ~4 ~2 ~37 cave_vines[berries=true,age=25]
setblock ~4 ~4 ~39 jungle_planks
setblock ~4 ~3 ~39 cave_vines_plant[berries=true]
setblock ~4 ~2 ~39 cave_vines[berries=true,age=25]
setblock ~4 ~4 ~41 jungle_planks
setblock ~4 ~3 ~41 cave_vines_plant[berries=true]
setblock ~4 ~2 ~41 cave_vines[berries=true,age=25]
setblock ~4 ~4 ~43 jungle_planks
setblock ~4 ~3 ~43 cave_vines_plant[berries=true]
setblock ~4 ~2 ~43 cave_vines[berries=true,age=25]
setblock ~6 ~4 ~35 jungle_planks
setblock ~6 ~3 ~35 cave_vines_plant[berries=true]
setblock ~6 ~2 ~35 cave_vines[berries=true,age=25]
setblock ~6 ~4 ~37 jungle_planks
setblock ~6 ~3 ~37 cave_vines_plant[berries=true]
setblock ~6 ~2 ~37 cave_vines[berries=true,age=25]
setblock ~6 ~4 ~39 jungle_planks
setblock ~6 ~3 ~39 cave_vines_plant[berries=true]
setblock ~6 ~2 ~39 cave_vines[berries=true,age=25]
setblock ~6 ~4 ~41 jungle_planks
setblock ~6 ~3 ~41 cave_vines_plant[berries=true]
setblock ~6 ~2 ~41 cave_vines[berries=true,age=25]
setblock ~6 ~4 ~43 jungle_planks
setblock ~6 ~3 ~43 cave_vines_plant[berries=true]
setblock ~6 ~2 ~43 cave_vines[berries=true,age=25]
setblock ~8 ~4 ~35 jungle_planks
setblock ~8 ~3 ~35 cave_vines_plant[berries=true]
setblock ~8 ~2 ~35 cave_vines[berries=true,age=25]
setblock ~8 ~4 ~37 jungle_planks
setblock ~8 ~3 ~37 cave_vines_plant[berries=true]
setblock ~8 ~2 ~37 cave_vines[berries=true,age=25]
setblock ~8 ~4 ~39 jungle_planks
setblock ~8 ~3 ~39 cave_vines_plant[berries=true]
setblock ~8 ~2 ~39 cave_vines[berries=true,age=25]
setblock ~8 ~4 ~41 jungle_planks
setblock ~8 ~3 ~41 cave_vines_plant[berries=true]
setblock ~8 ~2 ~41 cave_vines[berries=true,age=25]
setblock ~8 ~4 ~43 jungle_planks
setblock ~8 ~3 ~43 cave_vines_plant[berries=true]
setblock ~8 ~2 ~43 cave_vines[berries=true,age=25]
setblock ~10 ~4 ~35 jungle_planks
setblock ~10 ~3 ~35 cave_vines_plant[berries=true]
setblock ~10 ~2 ~35 cave_vines[berries=true,age=25]
setblock ~10 ~4 ~37 jungle_planks
setblock ~10 ~3 ~37 cave_vines_plant[berries=true]
setblock ~10 ~2 ~37 cave_vines[berries=true,age=25]
setblock ~10 ~4 ~39 jungle_planks
setblock ~10 ~3 ~39 cave_vines_plant[berries=true]
setblock ~10 ~2 ~39 cave_vines[berries=true,age=25]
setblock ~10 ~4 ~41 jungle_planks
setblock ~10 ~3 ~41 cave_vines_plant[berries=true]
setblock ~10 ~2 ~41 cave_vines[berries=true,age=25]
setblock ~10 ~4 ~43 jungle_planks
setblock ~10 ~3 ~43 cave_vines_plant[berries=true]
setblock ~10 ~2 ~43 cave_vines[berries=true,age=25]
setblock ~12 ~4 ~35 jungle_planks
setblock ~12 ~3 ~35 cave_vines_plant[berries=true]
setblock ~12 ~2 ~35 cave_vines[berries=true,age=25]
setblock ~12 ~4 ~37 jungle_planks
setblock ~12 ~3 ~37 cave_vines_plant[berries=true]
setblock ~12 ~2 ~37 cave_vines[berries=true,age=25]
setblock ~12 ~4 ~39 jungle_planks
setblock ~12 ~3 ~39 cave_vines_plant[berries=true]
setblock ~12 ~2 ~39 cave_vines[berries=true,age=25]
setblock ~12 ~4 ~41 jungle_planks
setblock ~12 ~3 ~41 cave_vines_plant[berries=true]
setblock ~12 ~2 ~41 cave_vines[berries=true,age=25]
setblock ~12 ~4 ~43 jungle_planks
setblock ~12 ~3 ~43 cave_vines_plant[berries=true]
setblock ~12 ~2 ~43 cave_vines[berries=true,age=25]
setblock ~3 ~ ~34 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:glow_berries",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~8 ~3 ~39 {billboard:"center",text:{text:"BAYAS LUMINOSAS",color:"yellow",bold:1b},background:1073741824}
fill ~15 ~-1 ~35 ~23 ~-1 ~43 dirt
fill ~15 ~-1 ~35 ~23 ~-1 ~43 grass_block
fill ~16 ~ ~36 ~16 ~2 ~36 jungle_log
setblock ~16 ~ ~35 cocoa[age=2,facing=south]
setblock ~16 ~ ~37 cocoa[age=2,facing=north]
setblock ~16 ~1 ~35 cocoa[age=2,facing=south]
setblock ~16 ~1 ~37 cocoa[age=2,facing=north]
setblock ~16 ~2 ~35 cocoa[age=2,facing=south]
setblock ~16 ~2 ~37 cocoa[age=2,facing=north]
fill ~16 ~ ~39 ~16 ~2 ~39 jungle_log
setblock ~16 ~ ~38 cocoa[age=2,facing=south]
setblock ~16 ~ ~40 cocoa[age=2,facing=north]
setblock ~16 ~1 ~38 cocoa[age=2,facing=south]
setblock ~16 ~1 ~40 cocoa[age=2,facing=north]
setblock ~16 ~2 ~38 cocoa[age=2,facing=south]
setblock ~16 ~2 ~40 cocoa[age=2,facing=north]
fill ~16 ~ ~42 ~16 ~2 ~42 jungle_log
setblock ~16 ~ ~41 cocoa[age=2,facing=south]
setblock ~16 ~ ~43 cocoa[age=2,facing=north]
setblock ~16 ~1 ~41 cocoa[age=2,facing=south]
setblock ~16 ~1 ~43 cocoa[age=2,facing=north]
setblock ~16 ~2 ~41 cocoa[age=2,facing=south]
setblock ~16 ~2 ~43 cocoa[age=2,facing=north]
fill ~19 ~ ~36 ~19 ~2 ~36 jungle_log
setblock ~19 ~ ~35 cocoa[age=2,facing=south]
setblock ~19 ~ ~37 cocoa[age=2,facing=north]
setblock ~19 ~1 ~35 cocoa[age=2,facing=south]
setblock ~19 ~1 ~37 cocoa[age=2,facing=north]
setblock ~19 ~2 ~35 cocoa[age=2,facing=south]
setblock ~19 ~2 ~37 cocoa[age=2,facing=north]
fill ~19 ~ ~39 ~19 ~2 ~39 jungle_log
setblock ~19 ~ ~38 cocoa[age=2,facing=south]
setblock ~19 ~ ~40 cocoa[age=2,facing=north]
setblock ~19 ~1 ~38 cocoa[age=2,facing=south]
setblock ~19 ~1 ~40 cocoa[age=2,facing=north]
setblock ~19 ~2 ~38 cocoa[age=2,facing=south]
setblock ~19 ~2 ~40 cocoa[age=2,facing=north]
fill ~19 ~ ~42 ~19 ~2 ~42 jungle_log
setblock ~19 ~ ~41 cocoa[age=2,facing=south]
setblock ~19 ~ ~43 cocoa[age=2,facing=north]
setblock ~19 ~1 ~41 cocoa[age=2,facing=south]
setblock ~19 ~1 ~43 cocoa[age=2,facing=north]
setblock ~19 ~2 ~41 cocoa[age=2,facing=south]
setblock ~19 ~2 ~43 cocoa[age=2,facing=north]
fill ~22 ~ ~36 ~22 ~2 ~36 jungle_log
setblock ~22 ~ ~35 cocoa[age=2,facing=south]
setblock ~22 ~ ~37 cocoa[age=2,facing=north]
setblock ~22 ~1 ~35 cocoa[age=2,facing=south]
setblock ~22 ~1 ~37 cocoa[age=2,facing=north]
setblock ~22 ~2 ~35 cocoa[age=2,facing=south]
setblock ~22 ~2 ~37 cocoa[age=2,facing=north]
fill ~22 ~ ~39 ~22 ~2 ~39 jungle_log
setblock ~22 ~ ~38 cocoa[age=2,facing=south]
setblock ~22 ~ ~40 cocoa[age=2,facing=north]
setblock ~22 ~1 ~38 cocoa[age=2,facing=south]
setblock ~22 ~1 ~40 cocoa[age=2,facing=north]
setblock ~22 ~2 ~38 cocoa[age=2,facing=south]
setblock ~22 ~2 ~40 cocoa[age=2,facing=north]
fill ~22 ~ ~42 ~22 ~2 ~42 jungle_log
setblock ~22 ~ ~41 cocoa[age=2,facing=south]
setblock ~22 ~ ~43 cocoa[age=2,facing=north]
setblock ~22 ~1 ~41 cocoa[age=2,facing=south]
setblock ~22 ~1 ~43 cocoa[age=2,facing=north]
setblock ~22 ~2 ~41 cocoa[age=2,facing=south]
setblock ~22 ~2 ~43 cocoa[age=2,facing=north]
setblock ~14 ~ ~34 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:cocoa_beans",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~19 ~3 ~39 {billboard:"center",text:{text:"CACAO",color:"yellow",bold:1b},background:1073741824}
fill ~26 ~-1 ~35 ~34 ~-1 ~43 dirt
fill ~26 ~-1 ~35 ~34 ~-1 ~43 sand
fill ~26 ~-1 ~36 ~34 ~-1 ~36 water
fill ~26 ~-1 ~39 ~34 ~-1 ~39 water
fill ~26 ~-1 ~42 ~34 ~-1 ~42 water
fill ~26 ~ ~35 ~34 ~1 ~35 sugar_cane
fill ~26 ~ ~37 ~34 ~1 ~37 sugar_cane
fill ~26 ~ ~38 ~34 ~1 ~38 sugar_cane
fill ~26 ~ ~40 ~34 ~1 ~40 sugar_cane
fill ~26 ~ ~41 ~34 ~1 ~41 sugar_cane
fill ~26 ~ ~43 ~34 ~1 ~43 sugar_cane
setblock ~25 ~ ~34 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:sugar_cane",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~30 ~3 ~39 {billboard:"center",text:{text:"CANA DE AZUCAR",color:"yellow",bold:1b},background:1073741824}
fill ~37 ~-1 ~35 ~45 ~-1 ~43 dirt
fill ~37 ~-1 ~35 ~45 ~-1 ~43 mycelium
setblock ~37 ~ ~35 red_mushroom
setblock ~37 ~ ~37 red_mushroom
setblock ~37 ~ ~39 red_mushroom
setblock ~37 ~ ~41 red_mushroom
setblock ~37 ~ ~43 red_mushroom
setblock ~38 ~ ~36 red_mushroom
setblock ~38 ~ ~38 red_mushroom
setblock ~38 ~ ~40 red_mushroom
setblock ~38 ~ ~42 red_mushroom
setblock ~39 ~ ~35 red_mushroom
setblock ~39 ~ ~37 red_mushroom
setblock ~39 ~ ~39 red_mushroom
setblock ~39 ~ ~41 red_mushroom
setblock ~39 ~ ~43 red_mushroom
setblock ~40 ~ ~36 red_mushroom
setblock ~40 ~ ~38 red_mushroom
setblock ~40 ~ ~40 red_mushroom
setblock ~40 ~ ~42 red_mushroom
setblock ~41 ~ ~35 red_mushroom
setblock ~41 ~ ~37 red_mushroom
setblock ~41 ~ ~39 red_mushroom
setblock ~41 ~ ~41 red_mushroom
setblock ~41 ~ ~43 red_mushroom
setblock ~42 ~ ~36 red_mushroom
setblock ~42 ~ ~38 red_mushroom
setblock ~42 ~ ~40 red_mushroom
setblock ~42 ~ ~42 red_mushroom
setblock ~43 ~ ~35 red_mushroom
setblock ~43 ~ ~37 red_mushroom
setblock ~43 ~ ~39 red_mushroom
setblock ~43 ~ ~41 red_mushroom
setblock ~43 ~ ~43 red_mushroom
setblock ~44 ~ ~36 red_mushroom
setblock ~44 ~ ~38 red_mushroom
setblock ~44 ~ ~40 red_mushroom
setblock ~44 ~ ~42 red_mushroom
setblock ~45 ~ ~35 red_mushroom
setblock ~45 ~ ~37 red_mushroom
setblock ~45 ~ ~39 red_mushroom
setblock ~45 ~ ~41 red_mushroom
setblock ~45 ~ ~43 red_mushroom
setblock ~36 ~ ~34 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:red_mushroom",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~41 ~3 ~39 {billboard:"center",text:{text:"HONGOS ROJOS",color:"yellow",bold:1b},background:1073741824}
fill ~48 ~-1 ~35 ~56 ~-1 ~43 dirt
fill ~48 ~-1 ~35 ~56 ~-1 ~43 mycelium
setblock ~48 ~ ~36 brown_mushroom
setblock ~48 ~ ~38 brown_mushroom
setblock ~48 ~ ~40 brown_mushroom
setblock ~48 ~ ~42 brown_mushroom
setblock ~49 ~ ~35 brown_mushroom
setblock ~49 ~ ~37 brown_mushroom
setblock ~49 ~ ~39 brown_mushroom
setblock ~49 ~ ~41 brown_mushroom
setblock ~49 ~ ~43 brown_mushroom
setblock ~50 ~ ~36 brown_mushroom
setblock ~50 ~ ~38 brown_mushroom
setblock ~50 ~ ~40 brown_mushroom
setblock ~50 ~ ~42 brown_mushroom
setblock ~51 ~ ~35 brown_mushroom
setblock ~51 ~ ~37 brown_mushroom
setblock ~51 ~ ~39 brown_mushroom
setblock ~51 ~ ~41 brown_mushroom
setblock ~51 ~ ~43 brown_mushroom
setblock ~52 ~ ~36 brown_mushroom
setblock ~52 ~ ~38 brown_mushroom
setblock ~52 ~ ~40 brown_mushroom
setblock ~52 ~ ~42 brown_mushroom
setblock ~53 ~ ~35 brown_mushroom
setblock ~53 ~ ~37 brown_mushroom
setblock ~53 ~ ~39 brown_mushroom
setblock ~53 ~ ~41 brown_mushroom
setblock ~53 ~ ~43 brown_mushroom
setblock ~54 ~ ~36 brown_mushroom
setblock ~54 ~ ~38 brown_mushroom
setblock ~54 ~ ~40 brown_mushroom
setblock ~54 ~ ~42 brown_mushroom
setblock ~55 ~ ~35 brown_mushroom
setblock ~55 ~ ~37 brown_mushroom
setblock ~55 ~ ~39 brown_mushroom
setblock ~55 ~ ~41 brown_mushroom
setblock ~55 ~ ~43 brown_mushroom
setblock ~56 ~ ~36 brown_mushroom
setblock ~56 ~ ~38 brown_mushroom
setblock ~56 ~ ~40 brown_mushroom
setblock ~56 ~ ~42 brown_mushroom
setblock ~47 ~ ~34 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:brown_mushroom",count:64},{Slot:1b,id:"minecraft:bone_meal",count:64}]}
summon minecraft:text_display ~52 ~3 ~39 {billboard:"center",text:{text:"HONGOS MARRONES",color:"yellow",bold:1b},background:1073741824}
setblock ~4 ~4 ~23 light[level=15] keep
setblock ~4 ~4 ~33 light[level=15] keep
setblock ~4 ~4 ~44 light[level=15] keep
setblock ~9 ~4 ~23 light[level=15] keep
setblock ~9 ~4 ~33 light[level=15] keep
setblock ~9 ~4 ~44 light[level=15] keep
setblock ~14 ~4 ~23 light[level=15] keep
setblock ~14 ~4 ~33 light[level=15] keep
setblock ~14 ~4 ~44 light[level=15] keep
setblock ~19 ~4 ~23 light[level=15] keep
setblock ~19 ~4 ~33 light[level=15] keep
setblock ~19 ~4 ~44 light[level=15] keep
setblock ~24 ~4 ~23 light[level=15] keep
setblock ~24 ~4 ~33 light[level=15] keep
setblock ~24 ~4 ~44 light[level=15] keep
setblock ~29 ~4 ~23 light[level=15] keep
setblock ~29 ~4 ~33 light[level=15] keep
setblock ~29 ~4 ~44 light[level=15] keep
setblock ~34 ~4 ~23 light[level=15] keep
setblock ~34 ~4 ~33 light[level=15] keep
setblock ~34 ~4 ~44 light[level=15] keep
setblock ~39 ~4 ~23 light[level=15] keep
setblock ~39 ~4 ~33 light[level=15] keep
setblock ~39 ~4 ~44 light[level=15] keep
setblock ~44 ~4 ~23 light[level=15] keep
setblock ~44 ~4 ~33 light[level=15] keep
setblock ~44 ~4 ~44 light[level=15] keep
setblock ~49 ~4 ~23 light[level=15] keep
setblock ~49 ~4 ~33 light[level=15] keep
setblock ~49 ~4 ~44 light[level=15] keep
setblock ~54 ~4 ~23 light[level=15] keep
setblock ~54 ~4 ~33 light[level=15] keep
setblock ~54 ~4 ~44 light[level=15] keep
fill ~2 ~ ~33 ~2 ~1 ~34 air
fill ~58 ~ ~33 ~58 ~1 ~34 air
summon minecraft:text_display ~1 ~3 ~34 {billboard:"center",text:{text:"INVERNADERO\n10 cultivos - barril de semillas en cada esquina",color:"gold",bold:1b},background:1073741824}
