tellraw @s {"text":"Edificio: paredes, ventanas, escaleras y luces...","color":"yellow"}
fill ~-1 ~ ~-1 ~52 ~35 ~-1 stone_bricks
fill ~-1 ~ ~28 ~52 ~35 ~28 stone_bricks
fill ~-1 ~ ~-1 ~-1 ~35 ~28 stone_bricks
fill ~52 ~ ~-1 ~52 ~35 ~28 stone_bricks
fill ~-1 ~36 ~-1 ~52 ~72 ~-1 stone_bricks
fill ~-1 ~36 ~28 ~52 ~72 ~28 stone_bricks
fill ~-1 ~36 ~-1 ~-1 ~72 ~28 stone_bricks
fill ~52 ~36 ~-1 ~52 ~72 ~28 stone_bricks
fill ~ ~1 ~-1 ~51 ~2 ~-1 glass
fill ~ ~1 ~28 ~51 ~2 ~28 glass
fill ~52 ~1 ~ ~52 ~2 ~27 glass
fill ~ ~9 ~-1 ~51 ~10 ~-1 glass
fill ~ ~9 ~28 ~51 ~10 ~28 glass
fill ~52 ~9 ~ ~52 ~10 ~27 glass
fill ~ ~19 ~-1 ~51 ~20 ~-1 glass
fill ~ ~19 ~28 ~51 ~20 ~28 glass
fill ~52 ~19 ~ ~52 ~20 ~27 glass
fill ~ ~26 ~-1 ~51 ~27 ~-1 glass
fill ~ ~26 ~28 ~51 ~27 ~28 glass
fill ~52 ~26 ~ ~52 ~27 ~27 glass
fill ~ ~34 ~-1 ~51 ~35 ~-1 glass
fill ~ ~34 ~28 ~51 ~35 ~28 glass
fill ~52 ~34 ~ ~52 ~35 ~27 glass
fill ~ ~52 ~-1 ~51 ~53 ~-1 glass
fill ~ ~52 ~28 ~51 ~53 ~28 glass
fill ~52 ~52 ~ ~52 ~53 ~27 glass
fill ~-1 ~ ~-1 ~-1 ~72 ~-1 chiseled_stone_bricks
fill ~-1 ~ ~28 ~-1 ~72 ~28 chiseled_stone_bricks
fill ~5 ~ ~-1 ~5 ~72 ~-1 chiseled_stone_bricks
fill ~5 ~ ~28 ~5 ~72 ~28 chiseled_stone_bricks
fill ~11 ~ ~-1 ~11 ~72 ~-1 chiseled_stone_bricks
fill ~11 ~ ~28 ~11 ~72 ~28 chiseled_stone_bricks
fill ~17 ~ ~-1 ~17 ~72 ~-1 chiseled_stone_bricks
fill ~17 ~ ~28 ~17 ~72 ~28 chiseled_stone_bricks
fill ~23 ~ ~-1 ~23 ~72 ~-1 chiseled_stone_bricks
fill ~23 ~ ~28 ~23 ~72 ~28 chiseled_stone_bricks
fill ~29 ~ ~-1 ~29 ~72 ~-1 chiseled_stone_bricks
fill ~29 ~ ~28 ~29 ~72 ~28 chiseled_stone_bricks
fill ~35 ~ ~-1 ~35 ~72 ~-1 chiseled_stone_bricks
fill ~35 ~ ~28 ~35 ~72 ~28 chiseled_stone_bricks
fill ~41 ~ ~-1 ~41 ~72 ~-1 chiseled_stone_bricks
fill ~41 ~ ~28 ~41 ~72 ~28 chiseled_stone_bricks
fill ~47 ~ ~-1 ~47 ~72 ~-1 chiseled_stone_bricks
fill ~47 ~ ~28 ~47 ~72 ~28 chiseled_stone_bricks
fill ~25 ~ ~28 ~27 ~2 ~28 air
fill ~24 ~-1 ~29 ~28 ~-1 ~31 polished_andesite
setblock ~24 ~ ~29 lantern
setblock ~28 ~ ~29 lantern
fill ~-1 ~73 ~-1 ~52 ~73 ~-1 stone_brick_wall
fill ~-1 ~73 ~28 ~52 ~73 ~28 stone_brick_wall
fill ~-1 ~73 ~-1 ~-1 ~73 ~28 stone_brick_wall
fill ~52 ~73 ~-1 ~52 ~73 ~28 stone_brick_wall
fill ~-7 ~ ~-1 ~-7 ~36 ~28 stone_bricks
fill ~-7 ~ ~-1 ~-1 ~36 ~-1 stone_bricks
fill ~-7 ~ ~28 ~-1 ~36 ~28 stone_bricks
fill ~-6 ~ ~ ~-2 ~36 ~27 air
fill ~-4 ~ ~ ~-4 ~36 ~27 glass
fill ~-7 ~37 ~-1 ~-7 ~73 ~28 stone_bricks
fill ~-7 ~37 ~-1 ~-1 ~73 ~-1 stone_bricks
fill ~-7 ~37 ~28 ~-1 ~73 ~28 stone_bricks
fill ~-6 ~37 ~ ~-2 ~73 ~27 air
fill ~-4 ~37 ~ ~-4 ~73 ~27 glass
fill ~-7 ~73 ~-1 ~-1 ~73 ~28 stone_bricks
fill ~-6 ~-1 ~ ~-2 ~-1 ~27 stone_bricks
fill ~-6 ~-1 ~4 ~-2 ~-1 ~4 stone_bricks
fill ~-4 ~ ~4 ~-4 ~2 ~4 air
fill ~-1 ~ ~4 ~-1 ~1 ~4 air
fill ~-6 ~7 ~13 ~-2 ~7 ~13 stone_bricks
fill ~-4 ~8 ~13 ~-4 ~10 ~13 air
fill ~-1 ~8 ~13 ~-1 ~9 ~13 air
fill ~-6 ~17 ~2 ~-2 ~17 ~2 stone_bricks
fill ~-4 ~18 ~2 ~-4 ~20 ~2 air
fill ~-1 ~18 ~2 ~-1 ~19 ~2 air
fill ~-6 ~24 ~10 ~-2 ~24 ~10 stone_bricks
fill ~-4 ~25 ~10 ~-4 ~27 ~10 air
fill ~-1 ~25 ~10 ~-1 ~26 ~10 air
fill ~-6 ~32 ~1 ~-2 ~32 ~1 stone_bricks
fill ~-4 ~33 ~1 ~-4 ~35 ~1 air
fill ~-1 ~33 ~1 ~-1 ~34 ~1 air
fill ~-6 ~50 ~20 ~-2 ~50 ~20 stone_bricks
fill ~-4 ~51 ~20 ~-4 ~53 ~20 air
fill ~-1 ~51 ~20 ~-1 ~52 ~20 air
fill ~-3 ~ ~5 ~-2 ~ ~5 stone_brick_stairs[facing=south]
fill ~-3 ~1 ~5 ~-2 ~3 ~5 air
fill ~-3 ~1 ~6 ~-2 ~1 ~6 stone_brick_stairs[facing=south]
fill ~-3 ~2 ~6 ~-2 ~4 ~6 air
fill ~-3 ~2 ~7 ~-2 ~2 ~7 stone_brick_stairs[facing=south]
fill ~-3 ~3 ~7 ~-2 ~5 ~7 air
fill ~-3 ~3 ~8 ~-2 ~3 ~8 stone_brick_stairs[facing=south]
fill ~-3 ~4 ~8 ~-2 ~6 ~8 air
fill ~-3 ~4 ~9 ~-2 ~4 ~9 stone_brick_stairs[facing=south]
fill ~-3 ~5 ~9 ~-2 ~7 ~9 air
fill ~-3 ~5 ~10 ~-2 ~5 ~10 stone_brick_stairs[facing=south]
fill ~-3 ~6 ~10 ~-2 ~8 ~10 air
fill ~-3 ~6 ~11 ~-2 ~6 ~11 stone_brick_stairs[facing=south]
fill ~-3 ~7 ~11 ~-2 ~9 ~11 air
fill ~-3 ~7 ~12 ~-2 ~7 ~12 stone_brick_stairs[facing=south]
fill ~-3 ~8 ~12 ~-2 ~10 ~12 air
fill ~-6 ~8 ~12 ~-5 ~8 ~12 stone_brick_stairs[facing=north]
fill ~-6 ~9 ~12 ~-5 ~11 ~12 air
fill ~-6 ~9 ~11 ~-5 ~9 ~11 stone_brick_stairs[facing=north]
fill ~-6 ~10 ~11 ~-5 ~12 ~11 air
fill ~-6 ~10 ~10 ~-5 ~10 ~10 stone_brick_stairs[facing=north]
fill ~-6 ~11 ~10 ~-5 ~13 ~10 air
fill ~-6 ~11 ~9 ~-5 ~11 ~9 stone_brick_stairs[facing=north]
fill ~-6 ~12 ~9 ~-5 ~14 ~9 air
fill ~-6 ~12 ~8 ~-5 ~12 ~8 stone_brick_stairs[facing=north]
fill ~-6 ~13 ~8 ~-5 ~15 ~8 air
fill ~-6 ~13 ~7 ~-5 ~13 ~7 stone_brick_stairs[facing=north]
fill ~-6 ~14 ~7 ~-5 ~16 ~7 air
fill ~-6 ~14 ~6 ~-5 ~14 ~6 stone_brick_stairs[facing=north]
fill ~-6 ~15 ~6 ~-5 ~17 ~6 air
fill ~-6 ~15 ~5 ~-5 ~15 ~5 stone_brick_stairs[facing=north]
fill ~-6 ~16 ~5 ~-5 ~18 ~5 air
fill ~-6 ~16 ~4 ~-5 ~16 ~4 stone_brick_stairs[facing=north]
fill ~-6 ~17 ~4 ~-5 ~19 ~4 air
fill ~-6 ~17 ~3 ~-5 ~17 ~3 stone_brick_stairs[facing=north]
fill ~-6 ~18 ~3 ~-5 ~20 ~3 air
fill ~-3 ~18 ~3 ~-2 ~18 ~3 stone_brick_stairs[facing=south]
fill ~-3 ~19 ~3 ~-2 ~21 ~3 air
fill ~-3 ~19 ~4 ~-2 ~19 ~4 stone_brick_stairs[facing=south]
fill ~-3 ~20 ~4 ~-2 ~22 ~4 air
fill ~-3 ~20 ~5 ~-2 ~20 ~5 stone_brick_stairs[facing=south]
fill ~-3 ~21 ~5 ~-2 ~23 ~5 air
fill ~-3 ~21 ~6 ~-2 ~21 ~6 stone_brick_stairs[facing=south]
fill ~-3 ~22 ~6 ~-2 ~24 ~6 air
fill ~-3 ~22 ~7 ~-2 ~22 ~7 stone_brick_stairs[facing=south]
fill ~-3 ~23 ~7 ~-2 ~25 ~7 air
fill ~-3 ~23 ~8 ~-2 ~23 ~8 stone_brick_stairs[facing=south]
fill ~-3 ~24 ~8 ~-2 ~26 ~8 air
fill ~-3 ~24 ~9 ~-2 ~24 ~9 stone_brick_stairs[facing=south]
fill ~-3 ~25 ~9 ~-2 ~27 ~9 air
fill ~-6 ~25 ~9 ~-5 ~25 ~9 stone_brick_stairs[facing=north]
fill ~-6 ~26 ~9 ~-5 ~28 ~9 air
fill ~-6 ~26 ~8 ~-5 ~26 ~8 stone_brick_stairs[facing=north]
fill ~-6 ~27 ~8 ~-5 ~29 ~8 air
fill ~-6 ~27 ~7 ~-5 ~27 ~7 stone_brick_stairs[facing=north]
fill ~-6 ~28 ~7 ~-5 ~30 ~7 air
fill ~-6 ~28 ~6 ~-5 ~28 ~6 stone_brick_stairs[facing=north]
fill ~-6 ~29 ~6 ~-5 ~31 ~6 air
fill ~-6 ~29 ~5 ~-5 ~29 ~5 stone_brick_stairs[facing=north]
fill ~-6 ~30 ~5 ~-5 ~32 ~5 air
fill ~-6 ~30 ~4 ~-5 ~30 ~4 stone_brick_stairs[facing=north]
fill ~-6 ~31 ~4 ~-5 ~33 ~4 air
fill ~-6 ~31 ~3 ~-5 ~31 ~3 stone_brick_stairs[facing=north]
fill ~-6 ~32 ~3 ~-5 ~34 ~3 air
fill ~-6 ~32 ~2 ~-5 ~32 ~2 stone_brick_stairs[facing=north]
fill ~-6 ~33 ~2 ~-5 ~35 ~2 air
fill ~-3 ~33 ~2 ~-2 ~33 ~2 stone_brick_stairs[facing=south]
fill ~-3 ~34 ~2 ~-2 ~36 ~2 air
fill ~-3 ~34 ~3 ~-2 ~34 ~3 stone_brick_stairs[facing=south]
fill ~-3 ~35 ~3 ~-2 ~37 ~3 air
fill ~-3 ~35 ~4 ~-2 ~35 ~4 stone_brick_stairs[facing=south]
fill ~-3 ~36 ~4 ~-2 ~38 ~4 air
fill ~-3 ~36 ~5 ~-2 ~36 ~5 stone_brick_stairs[facing=south]
fill ~-3 ~37 ~5 ~-2 ~39 ~5 air
fill ~-3 ~37 ~6 ~-2 ~37 ~6 stone_brick_stairs[facing=south]
fill ~-3 ~38 ~6 ~-2 ~40 ~6 air
fill ~-3 ~38 ~7 ~-2 ~38 ~7 stone_brick_stairs[facing=south]
fill ~-3 ~39 ~7 ~-2 ~41 ~7 air
fill ~-3 ~39 ~8 ~-2 ~39 ~8 stone_brick_stairs[facing=south]
fill ~-3 ~40 ~8 ~-2 ~42 ~8 air
fill ~-3 ~40 ~9 ~-2 ~40 ~9 stone_brick_stairs[facing=south]
fill ~-3 ~41 ~9 ~-2 ~43 ~9 air
fill ~-3 ~41 ~10 ~-2 ~41 ~10 stone_brick_stairs[facing=south]
fill ~-3 ~42 ~10 ~-2 ~44 ~10 air
fill ~-3 ~42 ~11 ~-2 ~42 ~11 stone_brick_stairs[facing=south]
fill ~-3 ~43 ~11 ~-2 ~45 ~11 air
fill ~-3 ~43 ~12 ~-2 ~43 ~12 stone_brick_stairs[facing=south]
fill ~-3 ~44 ~12 ~-2 ~46 ~12 air
fill ~-3 ~44 ~13 ~-2 ~44 ~13 stone_brick_stairs[facing=south]
fill ~-3 ~45 ~13 ~-2 ~47 ~13 air
fill ~-3 ~45 ~14 ~-2 ~45 ~14 stone_brick_stairs[facing=south]
fill ~-3 ~46 ~14 ~-2 ~48 ~14 air
fill ~-3 ~46 ~15 ~-2 ~46 ~15 stone_brick_stairs[facing=south]
fill ~-3 ~47 ~15 ~-2 ~49 ~15 air
fill ~-3 ~47 ~16 ~-2 ~47 ~16 stone_brick_stairs[facing=south]
fill ~-3 ~48 ~16 ~-2 ~50 ~16 air
fill ~-3 ~48 ~17 ~-2 ~48 ~17 stone_brick_stairs[facing=south]
fill ~-3 ~49 ~17 ~-2 ~51 ~17 air
fill ~-3 ~49 ~18 ~-2 ~49 ~18 stone_brick_stairs[facing=south]
fill ~-3 ~50 ~18 ~-2 ~52 ~18 air
fill ~-3 ~50 ~19 ~-2 ~50 ~19 stone_brick_stairs[facing=south]
fill ~-3 ~51 ~19 ~-2 ~53 ~19 air
setblock ~2 ~2 ~2 light[level=15] keep
setblock ~2 ~2 ~8 light[level=15] keep
setblock ~2 ~2 ~14 light[level=15] keep
setblock ~2 ~2 ~20 light[level=15] keep
setblock ~2 ~2 ~26 light[level=15] keep
setblock ~8 ~2 ~2 light[level=15] keep
setblock ~8 ~2 ~8 light[level=15] keep
setblock ~8 ~2 ~14 light[level=15] keep
setblock ~8 ~2 ~20 light[level=15] keep
setblock ~8 ~2 ~26 light[level=15] keep
setblock ~14 ~2 ~2 light[level=15] keep
setblock ~14 ~2 ~8 light[level=15] keep
setblock ~14 ~2 ~14 light[level=15] keep
setblock ~14 ~2 ~20 light[level=15] keep
setblock ~14 ~2 ~26 light[level=15] keep
setblock ~20 ~2 ~2 light[level=15] keep
setblock ~20 ~2 ~8 light[level=15] keep
setblock ~20 ~2 ~14 light[level=15] keep
setblock ~20 ~2 ~20 light[level=15] keep
setblock ~20 ~2 ~26 light[level=15] keep
setblock ~26 ~2 ~2 light[level=15] keep
setblock ~26 ~2 ~8 light[level=15] keep
setblock ~26 ~2 ~14 light[level=15] keep
setblock ~26 ~2 ~20 light[level=15] keep
setblock ~26 ~2 ~26 light[level=15] keep
setblock ~32 ~2 ~2 light[level=15] keep
setblock ~32 ~2 ~8 light[level=15] keep
setblock ~32 ~2 ~14 light[level=15] keep
setblock ~32 ~2 ~20 light[level=15] keep
setblock ~32 ~2 ~26 light[level=15] keep
setblock ~38 ~2 ~2 light[level=15] keep
setblock ~38 ~2 ~8 light[level=15] keep
setblock ~38 ~2 ~14 light[level=15] keep
setblock ~38 ~2 ~20 light[level=15] keep
setblock ~38 ~2 ~26 light[level=15] keep
setblock ~44 ~2 ~2 light[level=15] keep
setblock ~44 ~2 ~8 light[level=15] keep
setblock ~44 ~2 ~14 light[level=15] keep
setblock ~44 ~2 ~20 light[level=15] keep
setblock ~44 ~2 ~26 light[level=15] keep
setblock ~50 ~2 ~2 light[level=15] keep
setblock ~50 ~2 ~8 light[level=15] keep
setblock ~50 ~2 ~14 light[level=15] keep
setblock ~50 ~2 ~20 light[level=15] keep
setblock ~50 ~2 ~26 light[level=15] keep
setblock ~2 ~10 ~2 light[level=15] keep
setblock ~2 ~10 ~8 light[level=15] keep
setblock ~2 ~10 ~14 light[level=15] keep
setblock ~2 ~10 ~20 light[level=15] keep
setblock ~2 ~10 ~26 light[level=15] keep
setblock ~8 ~10 ~2 light[level=15] keep
setblock ~8 ~10 ~8 light[level=15] keep
setblock ~8 ~10 ~14 light[level=15] keep
setblock ~8 ~10 ~20 light[level=15] keep
setblock ~8 ~10 ~26 light[level=15] keep
setblock ~14 ~10 ~2 light[level=15] keep
setblock ~14 ~10 ~8 light[level=15] keep
setblock ~14 ~10 ~14 light[level=15] keep
setblock ~14 ~10 ~20 light[level=15] keep
setblock ~14 ~10 ~26 light[level=15] keep
setblock ~20 ~10 ~2 light[level=15] keep
setblock ~20 ~10 ~8 light[level=15] keep
setblock ~20 ~10 ~14 light[level=15] keep
setblock ~20 ~10 ~20 light[level=15] keep
setblock ~20 ~10 ~26 light[level=15] keep
setblock ~26 ~10 ~2 light[level=15] keep
setblock ~26 ~10 ~8 light[level=15] keep
setblock ~26 ~10 ~14 light[level=15] keep
setblock ~26 ~10 ~20 light[level=15] keep
setblock ~26 ~10 ~26 light[level=15] keep
setblock ~32 ~10 ~2 light[level=15] keep
setblock ~32 ~10 ~8 light[level=15] keep
setblock ~32 ~10 ~14 light[level=15] keep
setblock ~32 ~10 ~20 light[level=15] keep
setblock ~32 ~10 ~26 light[level=15] keep
setblock ~38 ~10 ~2 light[level=15] keep
setblock ~38 ~10 ~8 light[level=15] keep
setblock ~38 ~10 ~14 light[level=15] keep
setblock ~38 ~10 ~20 light[level=15] keep
setblock ~38 ~10 ~26 light[level=15] keep
setblock ~44 ~10 ~2 light[level=15] keep
setblock ~44 ~10 ~8 light[level=15] keep
setblock ~44 ~10 ~14 light[level=15] keep
setblock ~44 ~10 ~20 light[level=15] keep
setblock ~44 ~10 ~26 light[level=15] keep
setblock ~50 ~10 ~2 light[level=15] keep
setblock ~50 ~10 ~8 light[level=15] keep
setblock ~50 ~10 ~14 light[level=15] keep
setblock ~50 ~10 ~20 light[level=15] keep
setblock ~50 ~10 ~26 light[level=15] keep
setblock ~2 ~14 ~2 light[level=15] keep
setblock ~2 ~14 ~8 light[level=15] keep
setblock ~2 ~14 ~14 light[level=15] keep
setblock ~2 ~14 ~20 light[level=15] keep
setblock ~2 ~14 ~26 light[level=15] keep
setblock ~8 ~14 ~2 light[level=15] keep
setblock ~8 ~14 ~8 light[level=15] keep
setblock ~8 ~14 ~14 light[level=15] keep
setblock ~8 ~14 ~20 light[level=15] keep
setblock ~8 ~14 ~26 light[level=15] keep
setblock ~14 ~14 ~2 light[level=15] keep
setblock ~14 ~14 ~8 light[level=15] keep
setblock ~14 ~14 ~14 light[level=15] keep
setblock ~14 ~14 ~20 light[level=15] keep
setblock ~14 ~14 ~26 light[level=15] keep
setblock ~20 ~14 ~2 light[level=15] keep
setblock ~20 ~14 ~8 light[level=15] keep
setblock ~20 ~14 ~14 light[level=15] keep
setblock ~20 ~14 ~20 light[level=15] keep
setblock ~20 ~14 ~26 light[level=15] keep
setblock ~26 ~14 ~2 light[level=15] keep
setblock ~26 ~14 ~8 light[level=15] keep
setblock ~26 ~14 ~14 light[level=15] keep
setblock ~26 ~14 ~20 light[level=15] keep
setblock ~26 ~14 ~26 light[level=15] keep
setblock ~32 ~14 ~2 light[level=15] keep
setblock ~32 ~14 ~8 light[level=15] keep
setblock ~32 ~14 ~14 light[level=15] keep
setblock ~32 ~14 ~20 light[level=15] keep
setblock ~32 ~14 ~26 light[level=15] keep
setblock ~38 ~14 ~2 light[level=15] keep
setblock ~38 ~14 ~8 light[level=15] keep
setblock ~38 ~14 ~14 light[level=15] keep
setblock ~38 ~14 ~20 light[level=15] keep
setblock ~38 ~14 ~26 light[level=15] keep
setblock ~44 ~14 ~2 light[level=15] keep
setblock ~44 ~14 ~8 light[level=15] keep
setblock ~44 ~14 ~14 light[level=15] keep
setblock ~44 ~14 ~20 light[level=15] keep
setblock ~44 ~14 ~26 light[level=15] keep
setblock ~50 ~14 ~2 light[level=15] keep
setblock ~50 ~14 ~8 light[level=15] keep
setblock ~50 ~14 ~14 light[level=15] keep
setblock ~50 ~14 ~20 light[level=15] keep
setblock ~50 ~14 ~26 light[level=15] keep
setblock ~2 ~20 ~2 light[level=15] keep
setblock ~2 ~20 ~8 light[level=15] keep
setblock ~2 ~20 ~14 light[level=15] keep
setblock ~2 ~20 ~20 light[level=15] keep
setblock ~2 ~20 ~26 light[level=15] keep
setblock ~8 ~20 ~2 light[level=15] keep
setblock ~8 ~20 ~8 light[level=15] keep
setblock ~8 ~20 ~14 light[level=15] keep
setblock ~8 ~20 ~20 light[level=15] keep
setblock ~8 ~20 ~26 light[level=15] keep
setblock ~14 ~20 ~2 light[level=15] keep
setblock ~14 ~20 ~8 light[level=15] keep
setblock ~14 ~20 ~14 light[level=15] keep
setblock ~14 ~20 ~20 light[level=15] keep
setblock ~14 ~20 ~26 light[level=15] keep
setblock ~20 ~20 ~2 light[level=15] keep
setblock ~20 ~20 ~8 light[level=15] keep
setblock ~20 ~20 ~14 light[level=15] keep
setblock ~20 ~20 ~20 light[level=15] keep
setblock ~20 ~20 ~26 light[level=15] keep
setblock ~26 ~20 ~2 light[level=15] keep
setblock ~26 ~20 ~8 light[level=15] keep
setblock ~26 ~20 ~14 light[level=15] keep
setblock ~26 ~20 ~20 light[level=15] keep
setblock ~26 ~20 ~26 light[level=15] keep
setblock ~32 ~20 ~2 light[level=15] keep
setblock ~32 ~20 ~8 light[level=15] keep
setblock ~32 ~20 ~14 light[level=15] keep
setblock ~32 ~20 ~20 light[level=15] keep
setblock ~32 ~20 ~26 light[level=15] keep
setblock ~38 ~20 ~2 light[level=15] keep
setblock ~38 ~20 ~8 light[level=15] keep
setblock ~38 ~20 ~14 light[level=15] keep
setblock ~38 ~20 ~20 light[level=15] keep
setblock ~38 ~20 ~26 light[level=15] keep
setblock ~44 ~20 ~2 light[level=15] keep
setblock ~44 ~20 ~8 light[level=15] keep
setblock ~44 ~20 ~14 light[level=15] keep
setblock ~44 ~20 ~20 light[level=15] keep
setblock ~44 ~20 ~26 light[level=15] keep
setblock ~50 ~20 ~2 light[level=15] keep
setblock ~50 ~20 ~8 light[level=15] keep
setblock ~50 ~20 ~14 light[level=15] keep
setblock ~50 ~20 ~20 light[level=15] keep
setblock ~50 ~20 ~26 light[level=15] keep
setblock ~2 ~27 ~2 light[level=15] keep
setblock ~2 ~27 ~8 light[level=15] keep
setblock ~2 ~27 ~14 light[level=15] keep
setblock ~2 ~27 ~20 light[level=15] keep
setblock ~2 ~27 ~26 light[level=15] keep
setblock ~8 ~27 ~2 light[level=15] keep
setblock ~8 ~27 ~8 light[level=15] keep
setblock ~8 ~27 ~14 light[level=15] keep
setblock ~8 ~27 ~20 light[level=15] keep
setblock ~8 ~27 ~26 light[level=15] keep
setblock ~14 ~27 ~2 light[level=15] keep
setblock ~14 ~27 ~8 light[level=15] keep
setblock ~14 ~27 ~14 light[level=15] keep
setblock ~14 ~27 ~20 light[level=15] keep
setblock ~14 ~27 ~26 light[level=15] keep
setblock ~20 ~27 ~2 light[level=15] keep
setblock ~20 ~27 ~8 light[level=15] keep
setblock ~20 ~27 ~14 light[level=15] keep
setblock ~20 ~27 ~20 light[level=15] keep
setblock ~20 ~27 ~26 light[level=15] keep
setblock ~26 ~27 ~2 light[level=15] keep
setblock ~26 ~27 ~8 light[level=15] keep
setblock ~26 ~27 ~14 light[level=15] keep
setblock ~26 ~27 ~20 light[level=15] keep
setblock ~26 ~27 ~26 light[level=15] keep
setblock ~32 ~27 ~2 light[level=15] keep
setblock ~32 ~27 ~8 light[level=15] keep
setblock ~32 ~27 ~14 light[level=15] keep
setblock ~32 ~27 ~20 light[level=15] keep
setblock ~32 ~27 ~26 light[level=15] keep
setblock ~38 ~27 ~2 light[level=15] keep
setblock ~38 ~27 ~8 light[level=15] keep
setblock ~38 ~27 ~14 light[level=15] keep
setblock ~38 ~27 ~20 light[level=15] keep
setblock ~38 ~27 ~26 light[level=15] keep
setblock ~44 ~27 ~2 light[level=15] keep
setblock ~44 ~27 ~8 light[level=15] keep
setblock ~44 ~27 ~14 light[level=15] keep
setblock ~44 ~27 ~20 light[level=15] keep
setblock ~44 ~27 ~26 light[level=15] keep
setblock ~50 ~27 ~2 light[level=15] keep
setblock ~50 ~27 ~8 light[level=15] keep
setblock ~50 ~27 ~14 light[level=15] keep
setblock ~50 ~27 ~20 light[level=15] keep
setblock ~50 ~27 ~26 light[level=15] keep
setblock ~2 ~35 ~2 light[level=15] keep
setblock ~2 ~35 ~8 light[level=15] keep
setblock ~2 ~35 ~14 light[level=15] keep
setblock ~2 ~35 ~20 light[level=15] keep
setblock ~2 ~35 ~26 light[level=15] keep
setblock ~8 ~35 ~2 light[level=15] keep
setblock ~8 ~35 ~8 light[level=15] keep
setblock ~8 ~35 ~14 light[level=15] keep
setblock ~8 ~35 ~20 light[level=15] keep
setblock ~8 ~35 ~26 light[level=15] keep
setblock ~14 ~35 ~2 light[level=15] keep
setblock ~14 ~35 ~8 light[level=15] keep
setblock ~14 ~35 ~14 light[level=15] keep
setblock ~14 ~35 ~20 light[level=15] keep
setblock ~14 ~35 ~26 light[level=15] keep
setblock ~20 ~35 ~2 light[level=15] keep
setblock ~20 ~35 ~8 light[level=15] keep
setblock ~20 ~35 ~14 light[level=15] keep
setblock ~20 ~35 ~20 light[level=15] keep
setblock ~20 ~35 ~26 light[level=15] keep
setblock ~26 ~35 ~2 light[level=15] keep
setblock ~26 ~35 ~8 light[level=15] keep
setblock ~26 ~35 ~14 light[level=15] keep
setblock ~26 ~35 ~20 light[level=15] keep
setblock ~26 ~35 ~26 light[level=15] keep
setblock ~32 ~35 ~2 light[level=15] keep
setblock ~32 ~35 ~8 light[level=15] keep
setblock ~32 ~35 ~14 light[level=15] keep
setblock ~32 ~35 ~20 light[level=15] keep
setblock ~32 ~35 ~26 light[level=15] keep
setblock ~38 ~35 ~2 light[level=15] keep
setblock ~38 ~35 ~8 light[level=15] keep
setblock ~38 ~35 ~14 light[level=15] keep
setblock ~38 ~35 ~20 light[level=15] keep
setblock ~38 ~35 ~26 light[level=15] keep
setblock ~44 ~35 ~2 light[level=15] keep
setblock ~44 ~35 ~8 light[level=15] keep
setblock ~44 ~35 ~14 light[level=15] keep
setblock ~44 ~35 ~20 light[level=15] keep
setblock ~44 ~35 ~26 light[level=15] keep
setblock ~50 ~35 ~2 light[level=15] keep
setblock ~50 ~35 ~8 light[level=15] keep
setblock ~50 ~35 ~14 light[level=15] keep
setblock ~50 ~35 ~20 light[level=15] keep
setblock ~50 ~35 ~26 light[level=15] keep
setblock ~2 ~41 ~2 light[level=15] keep
setblock ~2 ~41 ~8 light[level=15] keep
setblock ~2 ~41 ~14 light[level=15] keep
setblock ~2 ~41 ~20 light[level=15] keep
setblock ~2 ~41 ~26 light[level=15] keep
setblock ~8 ~41 ~2 light[level=15] keep
setblock ~8 ~41 ~8 light[level=15] keep
setblock ~8 ~41 ~14 light[level=15] keep
setblock ~8 ~41 ~20 light[level=15] keep
setblock ~8 ~41 ~26 light[level=15] keep
setblock ~14 ~41 ~2 light[level=15] keep
setblock ~14 ~41 ~8 light[level=15] keep
setblock ~14 ~41 ~14 light[level=15] keep
setblock ~14 ~41 ~20 light[level=15] keep
setblock ~14 ~41 ~26 light[level=15] keep
setblock ~20 ~41 ~2 light[level=15] keep
setblock ~20 ~41 ~8 light[level=15] keep
setblock ~20 ~41 ~14 light[level=15] keep
setblock ~20 ~41 ~20 light[level=15] keep
setblock ~20 ~41 ~26 light[level=15] keep
setblock ~26 ~41 ~2 light[level=15] keep
setblock ~26 ~41 ~8 light[level=15] keep
setblock ~26 ~41 ~14 light[level=15] keep
setblock ~26 ~41 ~20 light[level=15] keep
setblock ~26 ~41 ~26 light[level=15] keep
setblock ~32 ~41 ~2 light[level=15] keep
setblock ~32 ~41 ~8 light[level=15] keep
setblock ~32 ~41 ~14 light[level=15] keep
setblock ~32 ~41 ~20 light[level=15] keep
setblock ~32 ~41 ~26 light[level=15] keep
setblock ~38 ~41 ~2 light[level=15] keep
setblock ~38 ~41 ~8 light[level=15] keep
setblock ~38 ~41 ~14 light[level=15] keep
setblock ~38 ~41 ~20 light[level=15] keep
setblock ~38 ~41 ~26 light[level=15] keep
setblock ~44 ~41 ~2 light[level=15] keep
setblock ~44 ~41 ~8 light[level=15] keep
setblock ~44 ~41 ~14 light[level=15] keep
setblock ~44 ~41 ~20 light[level=15] keep
setblock ~44 ~41 ~26 light[level=15] keep
setblock ~50 ~41 ~2 light[level=15] keep
setblock ~50 ~41 ~8 light[level=15] keep
setblock ~50 ~41 ~14 light[level=15] keep
setblock ~50 ~41 ~20 light[level=15] keep
setblock ~50 ~41 ~26 light[level=15] keep
setblock ~2 ~47 ~2 light[level=15] keep
setblock ~2 ~47 ~8 light[level=15] keep
setblock ~2 ~47 ~14 light[level=15] keep
setblock ~2 ~47 ~20 light[level=15] keep
setblock ~2 ~47 ~26 light[level=15] keep
setblock ~8 ~47 ~2 light[level=15] keep
setblock ~8 ~47 ~8 light[level=15] keep
setblock ~8 ~47 ~14 light[level=15] keep
setblock ~8 ~47 ~20 light[level=15] keep
setblock ~8 ~47 ~26 light[level=15] keep
setblock ~14 ~47 ~2 light[level=15] keep
setblock ~14 ~47 ~8 light[level=15] keep
setblock ~14 ~47 ~14 light[level=15] keep
setblock ~14 ~47 ~20 light[level=15] keep
setblock ~14 ~47 ~26 light[level=15] keep
setblock ~20 ~47 ~2 light[level=15] keep
setblock ~20 ~47 ~8 light[level=15] keep
setblock ~20 ~47 ~14 light[level=15] keep
setblock ~20 ~47 ~20 light[level=15] keep
setblock ~20 ~47 ~26 light[level=15] keep
setblock ~26 ~47 ~2 light[level=15] keep
setblock ~26 ~47 ~8 light[level=15] keep
setblock ~26 ~47 ~14 light[level=15] keep
setblock ~26 ~47 ~20 light[level=15] keep
setblock ~26 ~47 ~26 light[level=15] keep
setblock ~32 ~47 ~2 light[level=15] keep
setblock ~32 ~47 ~8 light[level=15] keep
setblock ~32 ~47 ~14 light[level=15] keep
setblock ~32 ~47 ~20 light[level=15] keep
setblock ~32 ~47 ~26 light[level=15] keep
setblock ~38 ~47 ~2 light[level=15] keep
setblock ~38 ~47 ~8 light[level=15] keep
setblock ~38 ~47 ~14 light[level=15] keep
setblock ~38 ~47 ~20 light[level=15] keep
setblock ~38 ~47 ~26 light[level=15] keep
setblock ~44 ~47 ~2 light[level=15] keep
setblock ~44 ~47 ~8 light[level=15] keep
setblock ~44 ~47 ~14 light[level=15] keep
setblock ~44 ~47 ~20 light[level=15] keep
setblock ~44 ~47 ~26 light[level=15] keep
setblock ~50 ~47 ~2 light[level=15] keep
setblock ~50 ~47 ~8 light[level=15] keep
setblock ~50 ~47 ~14 light[level=15] keep
setblock ~50 ~47 ~20 light[level=15] keep
setblock ~50 ~47 ~26 light[level=15] keep
setblock ~2 ~53 ~2 light[level=15] keep
setblock ~2 ~53 ~8 light[level=15] keep
setblock ~2 ~53 ~14 light[level=15] keep
setblock ~2 ~53 ~20 light[level=15] keep
setblock ~2 ~53 ~26 light[level=15] keep
setblock ~8 ~53 ~2 light[level=15] keep
setblock ~8 ~53 ~8 light[level=15] keep
setblock ~8 ~53 ~14 light[level=15] keep
setblock ~8 ~53 ~20 light[level=15] keep
setblock ~8 ~53 ~26 light[level=15] keep
setblock ~14 ~53 ~2 light[level=15] keep
setblock ~14 ~53 ~8 light[level=15] keep
setblock ~14 ~53 ~14 light[level=15] keep
setblock ~14 ~53 ~20 light[level=15] keep
setblock ~14 ~53 ~26 light[level=15] keep
setblock ~20 ~53 ~2 light[level=15] keep
setblock ~20 ~53 ~8 light[level=15] keep
setblock ~20 ~53 ~14 light[level=15] keep
setblock ~20 ~53 ~20 light[level=15] keep
setblock ~20 ~53 ~26 light[level=15] keep
setblock ~26 ~53 ~2 light[level=15] keep
setblock ~26 ~53 ~8 light[level=15] keep
setblock ~26 ~53 ~14 light[level=15] keep
setblock ~26 ~53 ~20 light[level=15] keep
setblock ~26 ~53 ~26 light[level=15] keep
setblock ~32 ~53 ~2 light[level=15] keep
setblock ~32 ~53 ~8 light[level=15] keep
setblock ~32 ~53 ~14 light[level=15] keep
setblock ~32 ~53 ~20 light[level=15] keep
setblock ~32 ~53 ~26 light[level=15] keep
setblock ~38 ~53 ~2 light[level=15] keep
setblock ~38 ~53 ~8 light[level=15] keep
setblock ~38 ~53 ~14 light[level=15] keep
setblock ~38 ~53 ~20 light[level=15] keep
setblock ~38 ~53 ~26 light[level=15] keep
setblock ~44 ~53 ~2 light[level=15] keep
setblock ~44 ~53 ~8 light[level=15] keep
setblock ~44 ~53 ~14 light[level=15] keep
setblock ~44 ~53 ~20 light[level=15] keep
setblock ~44 ~53 ~26 light[level=15] keep
setblock ~50 ~53 ~2 light[level=15] keep
setblock ~50 ~53 ~8 light[level=15] keep
setblock ~50 ~53 ~14 light[level=15] keep
setblock ~50 ~53 ~20 light[level=15] keep
setblock ~50 ~53 ~26 light[level=15] keep
setblock ~2 ~59 ~2 light[level=15] keep
setblock ~2 ~59 ~8 light[level=15] keep
setblock ~2 ~59 ~14 light[level=15] keep
setblock ~2 ~59 ~20 light[level=15] keep
setblock ~2 ~59 ~26 light[level=15] keep
setblock ~8 ~59 ~2 light[level=15] keep
setblock ~8 ~59 ~8 light[level=15] keep
setblock ~8 ~59 ~14 light[level=15] keep
setblock ~8 ~59 ~20 light[level=15] keep
setblock ~8 ~59 ~26 light[level=15] keep
setblock ~14 ~59 ~2 light[level=15] keep
setblock ~14 ~59 ~8 light[level=15] keep
setblock ~14 ~59 ~14 light[level=15] keep
setblock ~14 ~59 ~20 light[level=15] keep
setblock ~14 ~59 ~26 light[level=15] keep
setblock ~20 ~59 ~2 light[level=15] keep
setblock ~20 ~59 ~8 light[level=15] keep
setblock ~20 ~59 ~14 light[level=15] keep
setblock ~20 ~59 ~20 light[level=15] keep
setblock ~20 ~59 ~26 light[level=15] keep
setblock ~26 ~59 ~2 light[level=15] keep
setblock ~26 ~59 ~8 light[level=15] keep
setblock ~26 ~59 ~14 light[level=15] keep
setblock ~26 ~59 ~20 light[level=15] keep
setblock ~26 ~59 ~26 light[level=15] keep
setblock ~32 ~59 ~2 light[level=15] keep
setblock ~32 ~59 ~8 light[level=15] keep
setblock ~32 ~59 ~14 light[level=15] keep
setblock ~32 ~59 ~20 light[level=15] keep
setblock ~32 ~59 ~26 light[level=15] keep
setblock ~38 ~59 ~2 light[level=15] keep
setblock ~38 ~59 ~8 light[level=15] keep
setblock ~38 ~59 ~14 light[level=15] keep
setblock ~38 ~59 ~20 light[level=15] keep
setblock ~38 ~59 ~26 light[level=15] keep
setblock ~44 ~59 ~2 light[level=15] keep
setblock ~44 ~59 ~8 light[level=15] keep
setblock ~44 ~59 ~14 light[level=15] keep
setblock ~44 ~59 ~20 light[level=15] keep
setblock ~44 ~59 ~26 light[level=15] keep
setblock ~50 ~59 ~2 light[level=15] keep
setblock ~50 ~59 ~8 light[level=15] keep
setblock ~50 ~59 ~14 light[level=15] keep
setblock ~50 ~59 ~20 light[level=15] keep
setblock ~50 ~59 ~26 light[level=15] keep
setblock ~2 ~69 ~2 light[level=15] keep
setblock ~2 ~69 ~8 light[level=15] keep
setblock ~2 ~69 ~14 light[level=15] keep
setblock ~2 ~69 ~20 light[level=15] keep
setblock ~2 ~69 ~26 light[level=15] keep
setblock ~8 ~69 ~2 light[level=15] keep
setblock ~8 ~69 ~8 light[level=15] keep
setblock ~8 ~69 ~14 light[level=15] keep
setblock ~8 ~69 ~20 light[level=15] keep
setblock ~8 ~69 ~26 light[level=15] keep
setblock ~14 ~69 ~2 light[level=15] keep
setblock ~14 ~69 ~8 light[level=15] keep
setblock ~14 ~69 ~14 light[level=15] keep
setblock ~14 ~69 ~20 light[level=15] keep
setblock ~14 ~69 ~26 light[level=15] keep
setblock ~20 ~69 ~2 light[level=15] keep
setblock ~20 ~69 ~8 light[level=15] keep
setblock ~20 ~69 ~14 light[level=15] keep
setblock ~20 ~69 ~20 light[level=15] keep
setblock ~20 ~69 ~26 light[level=15] keep
setblock ~26 ~69 ~2 light[level=15] keep
setblock ~26 ~69 ~8 light[level=15] keep
setblock ~26 ~69 ~14 light[level=15] keep
setblock ~26 ~69 ~20 light[level=15] keep
setblock ~26 ~69 ~26 light[level=15] keep
setblock ~32 ~69 ~2 light[level=15] keep
setblock ~32 ~69 ~8 light[level=15] keep
setblock ~32 ~69 ~14 light[level=15] keep
setblock ~32 ~69 ~20 light[level=15] keep
setblock ~32 ~69 ~26 light[level=15] keep
setblock ~38 ~69 ~2 light[level=15] keep
setblock ~38 ~69 ~8 light[level=15] keep
setblock ~38 ~69 ~14 light[level=15] keep
setblock ~38 ~69 ~20 light[level=15] keep
setblock ~38 ~69 ~26 light[level=15] keep
setblock ~44 ~69 ~2 light[level=15] keep
setblock ~44 ~69 ~8 light[level=15] keep
setblock ~44 ~69 ~14 light[level=15] keep
setblock ~44 ~69 ~20 light[level=15] keep
setblock ~44 ~69 ~26 light[level=15] keep
setblock ~50 ~69 ~2 light[level=15] keep
setblock ~50 ~69 ~8 light[level=15] keep
setblock ~50 ~69 ~14 light[level=15] keep
setblock ~50 ~69 ~20 light[level=15] keep
setblock ~50 ~69 ~26 light[level=15] keep
setblock ~-3 ~2 ~2 light[level=15] keep
setblock ~-6 ~2 ~2 light[level=15] keep
setblock ~-3 ~2 ~7 light[level=15] keep
setblock ~-6 ~2 ~7 light[level=15] keep
setblock ~-3 ~2 ~12 light[level=15] keep
setblock ~-6 ~2 ~12 light[level=15] keep
setblock ~-3 ~2 ~17 light[level=15] keep
setblock ~-6 ~2 ~17 light[level=15] keep
setblock ~-3 ~2 ~22 light[level=15] keep
setblock ~-6 ~2 ~22 light[level=15] keep
setblock ~-3 ~2 ~27 light[level=15] keep
setblock ~-6 ~2 ~27 light[level=15] keep
setblock ~-3 ~7 ~2 light[level=15] keep
setblock ~-6 ~7 ~2 light[level=15] keep
setblock ~-3 ~7 ~7 light[level=15] keep
setblock ~-6 ~7 ~7 light[level=15] keep
setblock ~-3 ~7 ~12 light[level=15] keep
setblock ~-6 ~7 ~12 light[level=15] keep
setblock ~-3 ~7 ~17 light[level=15] keep
setblock ~-6 ~7 ~17 light[level=15] keep
setblock ~-3 ~7 ~22 light[level=15] keep
setblock ~-6 ~7 ~22 light[level=15] keep
setblock ~-3 ~7 ~27 light[level=15] keep
setblock ~-6 ~7 ~27 light[level=15] keep
setblock ~-3 ~12 ~2 light[level=15] keep
setblock ~-6 ~12 ~2 light[level=15] keep
setblock ~-3 ~12 ~7 light[level=15] keep
setblock ~-6 ~12 ~7 light[level=15] keep
setblock ~-3 ~12 ~12 light[level=15] keep
setblock ~-6 ~12 ~12 light[level=15] keep
setblock ~-3 ~12 ~17 light[level=15] keep
setblock ~-6 ~12 ~17 light[level=15] keep
setblock ~-3 ~12 ~22 light[level=15] keep
setblock ~-6 ~12 ~22 light[level=15] keep
setblock ~-3 ~12 ~27 light[level=15] keep
setblock ~-6 ~12 ~27 light[level=15] keep
setblock ~-3 ~17 ~2 light[level=15] keep
setblock ~-6 ~17 ~2 light[level=15] keep
setblock ~-3 ~17 ~7 light[level=15] keep
setblock ~-6 ~17 ~7 light[level=15] keep
setblock ~-3 ~17 ~12 light[level=15] keep
setblock ~-6 ~17 ~12 light[level=15] keep
setblock ~-3 ~17 ~17 light[level=15] keep
setblock ~-6 ~17 ~17 light[level=15] keep
setblock ~-3 ~17 ~22 light[level=15] keep
setblock ~-6 ~17 ~22 light[level=15] keep
setblock ~-3 ~17 ~27 light[level=15] keep
setblock ~-6 ~17 ~27 light[level=15] keep
setblock ~-3 ~22 ~2 light[level=15] keep
setblock ~-6 ~22 ~2 light[level=15] keep
setblock ~-3 ~22 ~7 light[level=15] keep
setblock ~-6 ~22 ~7 light[level=15] keep
setblock ~-3 ~22 ~12 light[level=15] keep
setblock ~-6 ~22 ~12 light[level=15] keep
setblock ~-3 ~22 ~17 light[level=15] keep
setblock ~-6 ~22 ~17 light[level=15] keep
setblock ~-3 ~22 ~22 light[level=15] keep
setblock ~-6 ~22 ~22 light[level=15] keep
setblock ~-3 ~22 ~27 light[level=15] keep
setblock ~-6 ~22 ~27 light[level=15] keep
setblock ~-3 ~27 ~2 light[level=15] keep
setblock ~-6 ~27 ~2 light[level=15] keep
setblock ~-3 ~27 ~7 light[level=15] keep
setblock ~-6 ~27 ~7 light[level=15] keep
setblock ~-3 ~27 ~12 light[level=15] keep
setblock ~-6 ~27 ~12 light[level=15] keep
setblock ~-3 ~27 ~17 light[level=15] keep
setblock ~-6 ~27 ~17 light[level=15] keep
setblock ~-3 ~27 ~22 light[level=15] keep
setblock ~-6 ~27 ~22 light[level=15] keep
setblock ~-3 ~27 ~27 light[level=15] keep
setblock ~-6 ~27 ~27 light[level=15] keep
setblock ~-3 ~32 ~2 light[level=15] keep
setblock ~-6 ~32 ~2 light[level=15] keep
setblock ~-3 ~32 ~7 light[level=15] keep
setblock ~-6 ~32 ~7 light[level=15] keep
setblock ~-3 ~32 ~12 light[level=15] keep
setblock ~-6 ~32 ~12 light[level=15] keep
setblock ~-3 ~32 ~17 light[level=15] keep
setblock ~-6 ~32 ~17 light[level=15] keep
setblock ~-3 ~32 ~22 light[level=15] keep
setblock ~-6 ~32 ~22 light[level=15] keep
setblock ~-3 ~32 ~27 light[level=15] keep
setblock ~-6 ~32 ~27 light[level=15] keep
setblock ~-3 ~37 ~2 light[level=15] keep
setblock ~-6 ~37 ~2 light[level=15] keep
setblock ~-3 ~37 ~7 light[level=15] keep
setblock ~-6 ~37 ~7 light[level=15] keep
setblock ~-3 ~37 ~12 light[level=15] keep
setblock ~-6 ~37 ~12 light[level=15] keep
setblock ~-3 ~37 ~17 light[level=15] keep
setblock ~-6 ~37 ~17 light[level=15] keep
setblock ~-3 ~37 ~22 light[level=15] keep
setblock ~-6 ~37 ~22 light[level=15] keep
setblock ~-3 ~37 ~27 light[level=15] keep
setblock ~-6 ~37 ~27 light[level=15] keep
setblock ~-3 ~42 ~2 light[level=15] keep
setblock ~-6 ~42 ~2 light[level=15] keep
setblock ~-3 ~42 ~7 light[level=15] keep
setblock ~-6 ~42 ~7 light[level=15] keep
setblock ~-3 ~42 ~12 light[level=15] keep
setblock ~-6 ~42 ~12 light[level=15] keep
setblock ~-3 ~42 ~17 light[level=15] keep
setblock ~-6 ~42 ~17 light[level=15] keep
setblock ~-3 ~42 ~22 light[level=15] keep
setblock ~-6 ~42 ~22 light[level=15] keep
setblock ~-3 ~42 ~27 light[level=15] keep
setblock ~-6 ~42 ~27 light[level=15] keep
setblock ~-3 ~47 ~2 light[level=15] keep
setblock ~-6 ~47 ~2 light[level=15] keep
setblock ~-3 ~47 ~7 light[level=15] keep
setblock ~-6 ~47 ~7 light[level=15] keep
setblock ~-3 ~47 ~12 light[level=15] keep
setblock ~-6 ~47 ~12 light[level=15] keep
setblock ~-3 ~47 ~17 light[level=15] keep
setblock ~-6 ~47 ~17 light[level=15] keep
setblock ~-3 ~47 ~22 light[level=15] keep
setblock ~-6 ~47 ~22 light[level=15] keep
setblock ~-3 ~47 ~27 light[level=15] keep
setblock ~-6 ~47 ~27 light[level=15] keep
setblock ~-3 ~52 ~2 light[level=15] keep
setblock ~-6 ~52 ~2 light[level=15] keep
setblock ~-3 ~52 ~7 light[level=15] keep
setblock ~-6 ~52 ~7 light[level=15] keep
setblock ~-3 ~52 ~12 light[level=15] keep
setblock ~-6 ~52 ~12 light[level=15] keep
setblock ~-3 ~52 ~17 light[level=15] keep
setblock ~-6 ~52 ~17 light[level=15] keep
setblock ~-3 ~52 ~22 light[level=15] keep
setblock ~-6 ~52 ~22 light[level=15] keep
setblock ~-3 ~52 ~27 light[level=15] keep
setblock ~-6 ~52 ~27 light[level=15] keep
setblock ~-3 ~57 ~2 light[level=15] keep
setblock ~-6 ~57 ~2 light[level=15] keep
setblock ~-3 ~57 ~7 light[level=15] keep
setblock ~-6 ~57 ~7 light[level=15] keep
setblock ~-3 ~57 ~12 light[level=15] keep
setblock ~-6 ~57 ~12 light[level=15] keep
setblock ~-3 ~57 ~17 light[level=15] keep
setblock ~-6 ~57 ~17 light[level=15] keep
setblock ~-3 ~57 ~22 light[level=15] keep
setblock ~-6 ~57 ~22 light[level=15] keep
setblock ~-3 ~57 ~27 light[level=15] keep
setblock ~-6 ~57 ~27 light[level=15] keep
setblock ~-3 ~62 ~2 light[level=15] keep
setblock ~-6 ~62 ~2 light[level=15] keep
setblock ~-3 ~62 ~7 light[level=15] keep
setblock ~-6 ~62 ~7 light[level=15] keep
setblock ~-3 ~62 ~12 light[level=15] keep
setblock ~-6 ~62 ~12 light[level=15] keep
setblock ~-3 ~62 ~17 light[level=15] keep
setblock ~-6 ~62 ~17 light[level=15] keep
setblock ~-3 ~62 ~22 light[level=15] keep
setblock ~-6 ~62 ~22 light[level=15] keep
setblock ~-3 ~62 ~27 light[level=15] keep
setblock ~-6 ~62 ~27 light[level=15] keep
setblock ~-3 ~67 ~2 light[level=15] keep
setblock ~-6 ~67 ~2 light[level=15] keep
setblock ~-3 ~67 ~7 light[level=15] keep
setblock ~-6 ~67 ~7 light[level=15] keep
setblock ~-3 ~67 ~12 light[level=15] keep
setblock ~-6 ~67 ~12 light[level=15] keep
setblock ~-3 ~67 ~17 light[level=15] keep
setblock ~-6 ~67 ~17 light[level=15] keep
setblock ~-3 ~67 ~22 light[level=15] keep
setblock ~-6 ~67 ~22 light[level=15] keep
setblock ~-3 ~67 ~27 light[level=15] keep
setblock ~-6 ~67 ~27 light[level=15] keep
summon minecraft:text_display ~26 ~4 ~30 {billboard:"center",text:{text:"EDIFICIO DE GRANJAS\npiso 0: hornos | 1: cana y sandia | 2: criaderos\n3: comercio | 4: hierro | 5: experiencia\nescaleras: puerta del lado oeste",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Edificio de granjas listo. Entra por el sur; las escaleras estan en el lado oeste (puerta en cada piso).","color":"green"}
