execute unless entity @e[type=minecraft:marker,tag=granjas_f4,limit=1] run tellraw @s {"text":"No encuentro la Fase 4. Usa /function granjas:fase4 donde la quieras.","color":"red"}
execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run function granjas:_f4_0
