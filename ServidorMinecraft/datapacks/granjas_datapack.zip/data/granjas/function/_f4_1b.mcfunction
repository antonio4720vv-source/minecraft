tellraw @a {"text":"[Fase 4] Limpiando terreno...","color":"yellow"}
execute positioned ~-4 ~-31 ~-16 run kill @e[type=!minecraft:player,tag=!granjas_f4,tag=!granjas_f3,tag=!granjas_f2,tag=!granjas_f1,tag=!granjas_mega,tag=!granjas_hub,dx=98,dy=80,dz=82]
fill ~-4 ~ ~-16 ~25 ~12 ~66 air
fill ~26 ~ ~-16 ~55 ~12 ~66 air
fill ~56 ~ ~-16 ~85 ~12 ~66 air
fill ~86 ~ ~-16 ~94 ~12 ~66 air
fill ~-4 ~13 ~-16 ~25 ~25 ~66 air
fill ~26 ~13 ~-16 ~55 ~25 ~66 air
fill ~56 ~13 ~-16 ~85 ~25 ~66 air
fill ~86 ~13 ~-16 ~94 ~25 ~66 air
fill ~-4 ~26 ~-16 ~25 ~38 ~66 air
fill ~26 ~26 ~-16 ~55 ~38 ~66 air
fill ~56 ~26 ~-16 ~85 ~38 ~66 air
fill ~86 ~26 ~-16 ~94 ~38 ~66 air
fill ~-4 ~-1 ~-16 ~25 ~-1 ~66 grass_block
fill ~26 ~-1 ~-16 ~55 ~-1 ~66 grass_block
fill ~56 ~-1 ~-16 ~85 ~-1 ~66 grass_block
fill ~86 ~-1 ~-16 ~94 ~-1 ~66 grass_block
fill ~-4 ~-4 ~-16 ~25 ~-2 ~66 dirt
fill ~26 ~-4 ~-16 ~55 ~-2 ~66 dirt
fill ~56 ~-4 ~-16 ~85 ~-2 ~66 dirt
fill ~86 ~-4 ~-16 ~94 ~-2 ~66 dirt
kill @e[type=minecraft:item,distance=..150]
