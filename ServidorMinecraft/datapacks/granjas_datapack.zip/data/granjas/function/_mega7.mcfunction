execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega7b
schedule function granjas:_mega8 4s replace
