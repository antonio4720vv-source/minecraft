execute as @e[type=minecraft:marker,tag=go_hierro] at @s run function granjas:_hierro_vision
execute store result score #n granjas if entity @e[type=minecraft:marker,tag=go_hierro]
tellraw @s [{"text":"Granjas de hierro arregladas: ","color":"green"},{"score":{"name":"#n","objective":"granjas"},"color":"yellow"},{"text":". Se arreglo el agua (los golems se quedaban parados) y las camas se movieron junto al zombi. Los aldeanos tienen que DORMIR una noche antes de que aparezcan golems.","color":"green"}]
