tellraw @a {"text":"Paredes, escaleras y granja de mobs...","color":"yellow"}
execute positioned ~-26 ~ ~-70 run function granjas:_edif_b
execute positioned ~-78 ~ ~-55 run function granjas:_mobs
