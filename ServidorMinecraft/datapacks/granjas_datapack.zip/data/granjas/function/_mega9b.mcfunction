tellraw @a {"text":"Animales, cofres, torre de elitros y casa en el arbol...","color":"yellow"}
execute positioned ~-18 ~ ~45 run function granjas:_animales
execute positioned ~10 ~ ~45 run function granjas:_cofres
execute positioned ~52 ~ ~48 run function granjas:_torre_elitros
execute positioned ~65 ~ ~0 run function granjas:_arbol
