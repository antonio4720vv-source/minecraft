execute at @e[type=minecraft:marker,tag=granjas_f4,limit=1] run function granjas:_f4_1b
schedule function granjas:_f4_2 3s replace
