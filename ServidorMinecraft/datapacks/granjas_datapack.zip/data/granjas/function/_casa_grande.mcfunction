tellraw @s {"text":"Construyendo CASA GRANDE...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~17 ~15 ~13 air
fill ~-1 ~-1 ~-1 ~17 ~-1 ~13 grass_block
fill ~ ~-1 ~ ~16 ~-1 ~12 stone_bricks
fill ~1 ~-1 ~1 ~15 ~-1 ~11 dark_oak_planks
fill ~ ~ ~ ~16 ~7 ~12 spruce_planks
fill ~1 ~ ~1 ~15 ~7 ~11 air
fill ~ ~ ~ ~ ~7 ~ stripped_dark_oak_log
fill ~16 ~ ~ ~16 ~7 ~ stripped_dark_oak_log
fill ~ ~ ~12 ~ ~7 ~12 stripped_dark_oak_log
fill ~16 ~ ~12 ~16 ~7 ~12 stripped_dark_oak_log
fill ~8 ~ ~ ~8 ~7 ~ stripped_dark_oak_log
fill ~ ~4 ~ ~16 ~4 ~12 stripped_dark_oak_log[axis=x]
fill ~1 ~4 ~1 ~15 ~4 ~11 dark_oak_planks
fill ~ ~8 ~ ~16 ~8 ~12 spruce_planks
fill ~-1 ~8 ~-1 ~17 ~8 ~-1 dark_oak_stairs[facing=south]
fill ~-1 ~8 ~13 ~17 ~8 ~13 dark_oak_stairs[facing=north]
fill ~-1 ~9 ~ ~17 ~9 ~ dark_oak_stairs[facing=south]
fill ~-1 ~9 ~12 ~17 ~9 ~12 dark_oak_stairs[facing=north]
fill ~ ~9 ~1 ~ ~9 ~11 spruce_planks
fill ~16 ~9 ~1 ~16 ~9 ~11 spruce_planks
fill ~-1 ~10 ~1 ~17 ~10 ~1 dark_oak_stairs[facing=south]
fill ~-1 ~10 ~11 ~17 ~10 ~11 dark_oak_stairs[facing=north]
fill ~ ~10 ~2 ~ ~10 ~10 spruce_planks
fill ~16 ~10 ~2 ~16 ~10 ~10 spruce_planks
fill ~-1 ~11 ~2 ~17 ~11 ~2 dark_oak_stairs[facing=south]
fill ~-1 ~11 ~10 ~17 ~11 ~10 dark_oak_stairs[facing=north]
fill ~ ~11 ~3 ~ ~11 ~9 spruce_planks
fill ~16 ~11 ~3 ~16 ~11 ~9 spruce_planks
fill ~-1 ~12 ~3 ~17 ~12 ~3 dark_oak_stairs[facing=south]
fill ~-1 ~12 ~9 ~17 ~12 ~9 dark_oak_stairs[facing=north]
fill ~ ~12 ~4 ~ ~12 ~8 spruce_planks
fill ~16 ~12 ~4 ~16 ~12 ~8 spruce_planks
fill ~-1 ~13 ~4 ~17 ~13 ~4 dark_oak_stairs[facing=south]
fill ~-1 ~13 ~8 ~17 ~13 ~8 dark_oak_stairs[facing=north]
fill ~ ~13 ~5 ~ ~13 ~7 spruce_planks
fill ~16 ~13 ~5 ~16 ~13 ~7 spruce_planks
fill ~-1 ~14 ~5 ~17 ~14 ~7 dark_oak_slab[type=bottom]
fill ~2 ~1 ~ ~2 ~2 ~ glass_pane[east=true,west=true]
fill ~2 ~1 ~12 ~2 ~2 ~12 glass_pane[east=true,west=true]
fill ~2 ~5 ~ ~2 ~6 ~ glass_pane[east=true,west=true]
fill ~2 ~5 ~12 ~2 ~6 ~12 glass_pane[east=true,west=true]
fill ~3 ~1 ~ ~3 ~2 ~ glass_pane[east=true,west=true]
fill ~3 ~1 ~12 ~3 ~2 ~12 glass_pane[east=true,west=true]
fill ~3 ~5 ~ ~3 ~6 ~ glass_pane[east=true,west=true]
fill ~3 ~5 ~12 ~3 ~6 ~12 glass_pane[east=true,west=true]
fill ~5 ~1 ~ ~5 ~2 ~ glass_pane[east=true,west=true]
fill ~5 ~1 ~12 ~5 ~2 ~12 glass_pane[east=true,west=true]
fill ~5 ~5 ~ ~5 ~6 ~ glass_pane[east=true,west=true]
fill ~5 ~5 ~12 ~5 ~6 ~12 glass_pane[east=true,west=true]
fill ~6 ~1 ~ ~6 ~2 ~ glass_pane[east=true,west=true]
fill ~6 ~1 ~12 ~6 ~2 ~12 glass_pane[east=true,west=true]
fill ~6 ~5 ~ ~6 ~6 ~ glass_pane[east=true,west=true]
fill ~6 ~5 ~12 ~6 ~6 ~12 glass_pane[east=true,west=true]
fill ~10 ~1 ~ ~10 ~2 ~ glass_pane[east=true,west=true]
fill ~10 ~1 ~12 ~10 ~2 ~12 glass_pane[east=true,west=true]
fill ~10 ~5 ~ ~10 ~6 ~ glass_pane[east=true,west=true]
fill ~10 ~5 ~12 ~10 ~6 ~12 glass_pane[east=true,west=true]
fill ~11 ~1 ~ ~11 ~2 ~ glass_pane[east=true,west=true]
fill ~11 ~1 ~12 ~11 ~2 ~12 glass_pane[east=true,west=true]
fill ~11 ~5 ~ ~11 ~6 ~ glass_pane[east=true,west=true]
fill ~11 ~5 ~12 ~11 ~6 ~12 glass_pane[east=true,west=true]
fill ~13 ~1 ~ ~13 ~2 ~ glass_pane[east=true,west=true]
fill ~13 ~1 ~12 ~13 ~2 ~12 glass_pane[east=true,west=true]
fill ~13 ~5 ~ ~13 ~6 ~ glass_pane[east=true,west=true]
fill ~13 ~5 ~12 ~13 ~6 ~12 glass_pane[east=true,west=true]
fill ~14 ~1 ~ ~14 ~2 ~ glass_pane[east=true,west=true]
fill ~14 ~1 ~12 ~14 ~2 ~12 glass_pane[east=true,west=true]
fill ~14 ~5 ~ ~14 ~6 ~ glass_pane[east=true,west=true]
fill ~14 ~5 ~12 ~14 ~6 ~12 glass_pane[east=true,west=true]
fill ~ ~1 ~3 ~ ~2 ~3 glass_pane[north=true,south=true]
fill ~16 ~1 ~3 ~16 ~2 ~3 glass_pane[north=true,south=true]
fill ~ ~5 ~3 ~ ~6 ~3 glass_pane[north=true,south=true]
fill ~16 ~5 ~3 ~16 ~6 ~3 glass_pane[north=true,south=true]
fill ~ ~1 ~4 ~ ~2 ~4 glass_pane[north=true,south=true]
fill ~16 ~1 ~4 ~16 ~2 ~4 glass_pane[north=true,south=true]
fill ~ ~5 ~4 ~ ~6 ~4 glass_pane[north=true,south=true]
fill ~16 ~5 ~4 ~16 ~6 ~4 glass_pane[north=true,south=true]
fill ~ ~1 ~8 ~ ~2 ~8 glass_pane[north=true,south=true]
fill ~16 ~1 ~8 ~16 ~2 ~8 glass_pane[north=true,south=true]
fill ~ ~5 ~8 ~ ~6 ~8 glass_pane[north=true,south=true]
fill ~16 ~5 ~8 ~16 ~6 ~8 glass_pane[north=true,south=true]
fill ~ ~1 ~9 ~ ~2 ~9 glass_pane[north=true,south=true]
fill ~16 ~1 ~9 ~16 ~2 ~9 glass_pane[north=true,south=true]
fill ~ ~5 ~9 ~ ~6 ~9 glass_pane[north=true,south=true]
fill ~16 ~5 ~9 ~16 ~6 ~9 glass_pane[north=true,south=true]
fill ~7 ~ ~12 ~9 ~2 ~12 air
setblock ~7 ~ ~12 iron_door[half=lower,facing=north,hinge=left]
setblock ~7 ~1 ~12 iron_door[half=upper,facing=north,hinge=left]
setblock ~9 ~ ~12 iron_door[half=lower,facing=north,hinge=right]
setblock ~9 ~1 ~12 iron_door[half=upper,facing=north,hinge=right]
setblock ~8 ~ ~12 spruce_planks
setblock ~8 ~1 ~12 spruce_planks
setblock ~8 ~2 ~12 spruce_planks
setblock ~8 ~1 ~13 stone_button[face=wall,facing=south]
setblock ~8 ~1 ~11 stone_button[face=wall,facing=north]
fill ~6 ~-1 ~13 ~10 ~-1 ~15 stone_bricks
setblock ~6 ~ ~13 lantern
setblock ~10 ~ ~13 lantern
setblock ~11 ~ ~10 oak_stairs[facing=east]
setblock ~11 ~ ~11 oak_stairs[facing=east]
setblock ~12 ~1 ~10 oak_stairs[facing=east]
setblock ~12 ~1 ~11 oak_stairs[facing=east]
setblock ~13 ~2 ~10 oak_stairs[facing=east]
setblock ~13 ~2 ~11 oak_stairs[facing=east]
setblock ~14 ~3 ~10 oak_stairs[facing=east]
setblock ~14 ~3 ~11 oak_stairs[facing=east]
fill ~11 ~4 ~10 ~15 ~4 ~11 air
fill ~11 ~5 ~9 ~15 ~5 ~9 oak_fence
fill ~2 ~ ~2 ~6 ~ ~6 bookshelf
fill ~3 ~ ~3 ~5 ~ ~5 air
setblock ~4 ~ ~6 air
setblock ~4 ~ ~4 enchanting_table
setblock ~15 ~ ~1 crafting_table
setblock ~14 ~ ~1 furnace[facing=south]
setblock ~13 ~ ~1 smoker[facing=south]
setblock ~12 ~ ~1 blast_furnace[facing=south]
setblock ~11 ~ ~1 brewing_stand
setblock ~10 ~ ~1 anvil[facing=east]
setblock ~9 ~ ~1 cauldron
fill ~6 ~ ~8 ~10 ~ ~10 red_carpet
setblock ~1 ~ ~10 ender_chest[facing=east]
setblock ~4 ~3 ~4 lantern[hanging=true]
setblock ~12 ~3 ~4 lantern[hanging=true]
setblock ~8 ~3 ~9 lantern[hanging=true]
setblock ~2 ~5 ~3 red_bed[facing=north,part=foot]
setblock ~2 ~5 ~2 red_bed[facing=north,part=head]
setblock ~4 ~5 ~3 blue_bed[facing=north,part=foot]
setblock ~4 ~5 ~2 blue_bed[facing=north,part=head]
fill ~1 ~5 ~5 ~1 ~6 ~9 barrel[facing=east]
fill ~15 ~5 ~1 ~15 ~6 ~6 barrel[facing=west]
fill ~3 ~5 ~6 ~9 ~5 ~9 light_blue_carpet
setblock ~4 ~7 ~5 lantern[hanging=true]
setblock ~12 ~7 ~4 lantern[hanging=true]
setblock ~8 ~7 ~9 lantern[hanging=true]
summon minecraft:text_display ~8 ~4 ~14 {billboard:"center",text:{text:"CASA",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Casa grande lista: 2 pisos, cama doble para 2, 15 barriles, cocina, mesa de encantar con 15 estanterias, pociones, yunque y cofre de ender.","color":"green"}
setblock ~1 ~5 ~2 spruce_trapdoor[half=top,open=false,facing=south]
setblock ~1 ~6 ~2 lantern
setblock ~5 ~5 ~2 spruce_trapdoor[half=top,open=false,facing=south]
setblock ~5 ~6 ~2 lantern
fill ~9 ~5 ~1 ~13 ~5 ~1 barrel[facing=south]
setblock ~14 ~5 ~1 crafting_table
