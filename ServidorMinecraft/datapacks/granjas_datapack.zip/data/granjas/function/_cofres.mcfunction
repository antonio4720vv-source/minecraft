tellraw @s {"text":"Construyendo CUARTO DE COFRES v2 (12 secciones con marcos)...","color":"yellow"}
fill ~-1 ~-1 ~-1 ~27 ~7 ~18 air
fill ~-1 ~-1 ~-1 ~27 ~-1 ~18 grass_block
fill ~ ~-1 ~ ~26 ~-1 ~16 polished_andesite
fill ~4 ~-1 ~4 ~22 ~-1 ~12 spruce_planks
fill ~ ~ ~ ~26 ~5 ~16 spruce_planks
fill ~1 ~ ~1 ~25 ~4 ~15 air
fill ~ ~ ~ ~ ~5 ~ stripped_spruce_log
fill ~26 ~ ~ ~26 ~5 ~ stripped_spruce_log
fill ~ ~ ~16 ~ ~5 ~16 stripped_spruce_log
fill ~26 ~ ~16 ~26 ~5 ~16 stripped_spruce_log
fill ~2 ~ ~15 ~2 ~2 ~15 barrel[facing=north]
setblock ~2 ~3 ~15 spruce_planks
summon minecraft:item_frame ~2 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:stone",count:1}}
fill ~3 ~ ~15 ~3 ~2 ~15 barrel[facing=north]
setblock ~3 ~3 ~15 spruce_planks
summon minecraft:item_frame ~3 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:cobblestone",count:1}}
fill ~4 ~ ~15 ~4 ~2 ~15 barrel[facing=north]
setblock ~4 ~3 ~15 spruce_planks
summon minecraft:item_frame ~4 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:deepslate",count:1}}
summon minecraft:text_display ~3 ~4 ~14 {billboard:"center",text:{text:"PIEDRAS",color:"yellow",bold:1b},background:1073741824}
fill ~6 ~ ~15 ~6 ~2 ~15 barrel[facing=north]
setblock ~6 ~3 ~15 spruce_planks
summon minecraft:item_frame ~6 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:dirt",count:1}}
fill ~7 ~ ~15 ~7 ~2 ~15 barrel[facing=north]
setblock ~7 ~3 ~15 spruce_planks
summon minecraft:item_frame ~7 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:grass_block",count:1}}
fill ~8 ~ ~15 ~8 ~2 ~15 barrel[facing=north]
setblock ~8 ~3 ~15 spruce_planks
summon minecraft:item_frame ~8 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:sand",count:1}}
summon minecraft:text_display ~7 ~4 ~14 {billboard:"center",text:{text:"TIERRA Y ARENA",color:"yellow",bold:1b},background:1073741824}
fill ~10 ~ ~15 ~10 ~2 ~15 barrel[facing=north]
setblock ~10 ~3 ~15 spruce_planks
summon minecraft:item_frame ~10 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:oak_log",count:1}}
fill ~11 ~ ~15 ~11 ~2 ~15 barrel[facing=north]
setblock ~11 ~3 ~15 spruce_planks
summon minecraft:item_frame ~11 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:spruce_log",count:1}}
fill ~12 ~ ~15 ~12 ~2 ~15 barrel[facing=north]
setblock ~12 ~3 ~15 spruce_planks
summon minecraft:item_frame ~12 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:birch_log",count:1}}
summon minecraft:text_display ~11 ~4 ~14 {billboard:"center",text:{text:"MADERA",color:"yellow",bold:1b},background:1073741824}
fill ~16 ~ ~15 ~16 ~2 ~15 barrel[facing=north]
setblock ~16 ~3 ~15 spruce_planks
summon minecraft:item_frame ~16 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:diamond",count:1}}
fill ~17 ~ ~15 ~17 ~2 ~15 barrel[facing=north]
setblock ~17 ~3 ~15 spruce_planks
summon minecraft:item_frame ~17 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:iron_ingot",count:1}}
fill ~18 ~ ~15 ~18 ~2 ~15 barrel[facing=north]
setblock ~18 ~3 ~15 spruce_planks
summon minecraft:item_frame ~18 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:gold_ingot",count:1}}
summon minecraft:text_display ~17 ~4 ~14 {billboard:"center",text:{text:"MINERALES",color:"yellow",bold:1b},background:1073741824}
fill ~20 ~ ~15 ~20 ~2 ~15 barrel[facing=north]
setblock ~20 ~3 ~15 spruce_planks
summon minecraft:item_frame ~20 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:redstone",count:1}}
fill ~21 ~ ~15 ~21 ~2 ~15 barrel[facing=north]
setblock ~21 ~3 ~15 spruce_planks
summon minecraft:item_frame ~21 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:repeater",count:1}}
fill ~22 ~ ~15 ~22 ~2 ~15 barrel[facing=north]
setblock ~22 ~3 ~15 spruce_planks
summon minecraft:item_frame ~22 ~3 ~14 {Facing:2b,Fixed:1b,Item:{id:"minecraft:comparator",count:1}}
summon minecraft:text_display ~21 ~4 ~14 {billboard:"center",text:{text:"REDSTONE",color:"yellow",bold:1b},background:1073741824}
fill ~1 ~ ~2 ~1 ~2 ~2 barrel[facing=east]
setblock ~1 ~3 ~2 spruce_planks
summon minecraft:item_frame ~2 ~3 ~2 {Facing:5b,Fixed:1b,Item:{id:"minecraft:bread",count:1}}
fill ~1 ~ ~3 ~1 ~2 ~3 barrel[facing=east]
setblock ~1 ~3 ~3 spruce_planks
summon minecraft:item_frame ~2 ~3 ~3 {Facing:5b,Fixed:1b,Item:{id:"minecraft:cooked_beef",count:1}}
fill ~1 ~ ~4 ~1 ~2 ~4 barrel[facing=east]
setblock ~1 ~3 ~4 spruce_planks
summon minecraft:item_frame ~2 ~3 ~4 {Facing:5b,Fixed:1b,Item:{id:"minecraft:golden_carrot",count:1}}
summon minecraft:text_display ~2 ~4 ~3 {billboard:"center",text:{text:"COMIDA",color:"yellow",bold:1b},background:1073741824}
fill ~1 ~ ~6 ~1 ~2 ~6 barrel[facing=east]
setblock ~1 ~3 ~6 spruce_planks
summon minecraft:item_frame ~2 ~3 ~6 {Facing:5b,Fixed:1b,Item:{id:"minecraft:gunpowder",count:1}}
fill ~1 ~ ~7 ~1 ~2 ~7 barrel[facing=east]
setblock ~1 ~3 ~7 spruce_planks
summon minecraft:item_frame ~2 ~3 ~7 {Facing:5b,Fixed:1b,Item:{id:"minecraft:bone",count:1}}
fill ~1 ~ ~8 ~1 ~2 ~8 barrel[facing=east]
setblock ~1 ~3 ~8 spruce_planks
summon minecraft:item_frame ~2 ~3 ~8 {Facing:5b,Fixed:1b,Item:{id:"minecraft:string",count:1}}
summon minecraft:text_display ~2 ~4 ~7 {billboard:"center",text:{text:"DROPS DE MOBS",color:"yellow",bold:1b},background:1073741824}
fill ~1 ~ ~10 ~1 ~2 ~10 barrel[facing=east]
setblock ~1 ~3 ~10 spruce_planks
summon minecraft:item_frame ~2 ~3 ~10 {Facing:5b,Fixed:1b,Item:{id:"minecraft:sugar_cane",count:1}}
fill ~1 ~ ~11 ~1 ~2 ~11 barrel[facing=east]
setblock ~1 ~3 ~11 spruce_planks
summon minecraft:item_frame ~2 ~3 ~11 {Facing:5b,Fixed:1b,Item:{id:"minecraft:wheat",count:1}}
fill ~1 ~ ~12 ~1 ~2 ~12 barrel[facing=east]
setblock ~1 ~3 ~12 spruce_planks
summon minecraft:item_frame ~2 ~3 ~12 {Facing:5b,Fixed:1b,Item:{id:"minecraft:pumpkin",count:1}}
summon minecraft:text_display ~2 ~4 ~11 {billboard:"center",text:{text:"GRANJAS",color:"yellow",bold:1b},background:1073741824}
fill ~25 ~ ~2 ~25 ~2 ~2 barrel[facing=west]
setblock ~25 ~3 ~2 spruce_planks
summon minecraft:item_frame ~24 ~3 ~2 {Facing:4b,Fixed:1b,Item:{id:"minecraft:diamond_pickaxe",count:1}}
fill ~25 ~ ~3 ~25 ~2 ~3 barrel[facing=west]
setblock ~25 ~3 ~3 spruce_planks
summon minecraft:item_frame ~24 ~3 ~3 {Facing:4b,Fixed:1b,Item:{id:"minecraft:diamond_sword",count:1}}
fill ~25 ~ ~4 ~25 ~2 ~4 barrel[facing=west]
setblock ~25 ~3 ~4 spruce_planks
summon minecraft:item_frame ~24 ~3 ~4 {Facing:4b,Fixed:1b,Item:{id:"minecraft:bow",count:1}}
summon minecraft:text_display ~24 ~4 ~3 {billboard:"center",text:{text:"HERRAMIENTAS Y ARMAS",color:"yellow",bold:1b},background:1073741824}
fill ~25 ~ ~6 ~25 ~2 ~6 barrel[facing=west]
setblock ~25 ~3 ~6 spruce_planks
summon minecraft:item_frame ~24 ~3 ~6 {Facing:4b,Fixed:1b,Item:{id:"minecraft:diamond_chestplate",count:1}}
fill ~25 ~ ~7 ~25 ~2 ~7 barrel[facing=west]
setblock ~25 ~3 ~7 spruce_planks
summon minecraft:item_frame ~24 ~3 ~7 {Facing:4b,Fixed:1b,Item:{id:"minecraft:diamond_helmet",count:1}}
fill ~25 ~ ~8 ~25 ~2 ~8 barrel[facing=west]
setblock ~25 ~3 ~8 spruce_planks
summon minecraft:item_frame ~24 ~3 ~8 {Facing:4b,Fixed:1b,Item:{id:"minecraft:diamond_leggings",count:1}}
summon minecraft:text_display ~24 ~4 ~7 {billboard:"center",text:{text:"ARMADURAS",color:"yellow",bold:1b},background:1073741824}
fill ~25 ~ ~10 ~25 ~2 ~10 barrel[facing=west]
setblock ~25 ~3 ~10 spruce_planks
summon minecraft:item_frame ~24 ~3 ~10 {Facing:4b,Fixed:1b,Item:{id:"minecraft:potion",count:1}}
fill ~25 ~ ~11 ~25 ~2 ~11 barrel[facing=west]
setblock ~25 ~3 ~11 spruce_planks
summon minecraft:item_frame ~24 ~3 ~11 {Facing:4b,Fixed:1b,Item:{id:"minecraft:enchanted_book",count:1}}
fill ~25 ~ ~12 ~25 ~2 ~12 barrel[facing=west]
setblock ~25 ~3 ~12 spruce_planks
summon minecraft:item_frame ~24 ~3 ~12 {Facing:4b,Fixed:1b,Item:{id:"minecraft:experience_bottle",count:1}}
summon minecraft:text_display ~24 ~4 ~11 {billboard:"center",text:{text:"POCIONES Y LIBROS",color:"yellow",bold:1b},background:1073741824}
setblock ~13 ~ ~15 barrel[facing=north]
setblock ~14 ~ ~15 barrel[facing=north]
setblock ~13 ~1 ~15 barrel[facing=north]
setblock ~13 ~2 ~15 barrel[facing=north]
setblock ~14 ~1 ~15 barrel[facing=north]
setblock ~14 ~2 ~15 barrel[facing=north]
summon minecraft:text_display ~13 ~4 ~14 {billboard:"center",text:{text:"EXTRA",color:"yellow",bold:1b},background:1073741824}
setblock ~4 ~5 ~4 glowstone
setblock ~4 ~5 ~8 glowstone
setblock ~4 ~5 ~12 glowstone
setblock ~9 ~5 ~4 glowstone
setblock ~9 ~5 ~8 glowstone
setblock ~9 ~5 ~12 glowstone
setblock ~14 ~5 ~4 glowstone
setblock ~14 ~5 ~8 glowstone
setblock ~14 ~5 ~12 glowstone
setblock ~19 ~5 ~4 glowstone
setblock ~19 ~5 ~8 glowstone
setblock ~19 ~5 ~12 glowstone
setblock ~9 ~ ~8 crafting_table
setblock ~17 ~ ~8 crafting_table
setblock ~13 ~ ~8 ender_chest[facing=north]
setblock ~11 ~ ~8 anvil[facing=east]
setblock ~15 ~ ~8 stonecutter[facing=north]
fill ~12 ~ ~1 ~14 ~2 ~1 air
setblock ~12 ~ ~ iron_door[half=lower,facing=south,hinge=left]
setblock ~12 ~1 ~ iron_door[half=upper,facing=south,hinge=left]
setblock ~14 ~ ~ iron_door[half=lower,facing=south,hinge=right]
setblock ~14 ~1 ~ iron_door[half=upper,facing=south,hinge=right]
setblock ~13 ~ ~ spruce_planks
setblock ~13 ~1 ~ spruce_planks
setblock ~13 ~1 ~-1 stone_button[face=wall,facing=north]
setblock ~13 ~1 ~1 stone_button[face=wall,facing=south]
fill ~3 ~1 ~ ~3 ~2 ~ glass_pane[east=true,west=true]
fill ~4 ~1 ~ ~4 ~2 ~ glass_pane[east=true,west=true]
fill ~8 ~1 ~ ~8 ~2 ~ glass_pane[east=true,west=true]
fill ~9 ~1 ~ ~9 ~2 ~ glass_pane[east=true,west=true]
fill ~17 ~1 ~ ~17 ~2 ~ glass_pane[east=true,west=true]
fill ~18 ~1 ~ ~18 ~2 ~ glass_pane[east=true,west=true]
fill ~22 ~1 ~ ~22 ~2 ~ glass_pane[east=true,west=true]
fill ~23 ~1 ~ ~23 ~2 ~ glass_pane[east=true,west=true]
summon minecraft:text_display ~13 ~3 ~-1 {billboard:"center",text:{text:"CUARTO DE COFRES",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Cuarto de cofres listo: 12 secciones (cada barril tiene un marco con el objeto que va ahi), cofre de ender, yunque, cortapiedras y mesas de crafteo.","color":"green"}
