tellraw @a {"text":"[Fase 4] Salon de cofres gigante...","color":"yellow"}
fill ~49 ~-1 ~-1 ~92 ~-1 ~30 polished_andesite
fill ~50 ~-1 ~ ~91 ~-1 ~29 dark_oak_planks
fill ~49 ~ ~-1 ~92 ~6 ~-1 spruce_planks
fill ~49 ~ ~30 ~92 ~6 ~30 spruce_planks
fill ~49 ~ ~-1 ~49 ~6 ~30 spruce_planks
fill ~92 ~ ~-1 ~92 ~6 ~30 spruce_planks
fill ~49 ~7 ~-1 ~92 ~7 ~30 dark_oak_planks
fill ~49 ~ ~-1 ~49 ~6 ~-1 stripped_spruce_log
fill ~49 ~ ~30 ~49 ~6 ~30 stripped_spruce_log
fill ~55 ~ ~-1 ~55 ~6 ~-1 stripped_spruce_log
fill ~55 ~ ~30 ~55 ~6 ~30 stripped_spruce_log
fill ~61 ~ ~-1 ~61 ~6 ~-1 stripped_spruce_log
fill ~61 ~ ~30 ~61 ~6 ~30 stripped_spruce_log
fill ~67 ~ ~-1 ~67 ~6 ~-1 stripped_spruce_log
fill ~67 ~ ~30 ~67 ~6 ~30 stripped_spruce_log
fill ~73 ~ ~-1 ~73 ~6 ~-1 stripped_spruce_log
fill ~73 ~ ~30 ~73 ~6 ~30 stripped_spruce_log
fill ~79 ~ ~-1 ~79 ~6 ~-1 stripped_spruce_log
fill ~79 ~ ~30 ~79 ~6 ~30 stripped_spruce_log
fill ~85 ~ ~-1 ~85 ~6 ~-1 stripped_spruce_log
fill ~85 ~ ~30 ~85 ~6 ~30 stripped_spruce_log
fill ~91 ~ ~-1 ~91 ~6 ~-1 stripped_spruce_log
fill ~91 ~ ~30 ~91 ~6 ~30 stripped_spruce_log
fill ~51 ~2 ~-1 ~53 ~4 ~-1 glass
fill ~51 ~2 ~30 ~53 ~4 ~30 glass
fill ~57 ~2 ~-1 ~59 ~4 ~-1 glass
fill ~57 ~2 ~30 ~59 ~4 ~30 glass
fill ~63 ~2 ~-1 ~65 ~4 ~-1 glass
fill ~63 ~2 ~30 ~65 ~4 ~30 glass
fill ~69 ~2 ~-1 ~71 ~4 ~-1 glass
fill ~69 ~2 ~30 ~71 ~4 ~30 glass
fill ~75 ~2 ~-1 ~77 ~4 ~-1 glass
fill ~75 ~2 ~30 ~77 ~4 ~30 glass
fill ~81 ~2 ~-1 ~83 ~4 ~-1 glass
fill ~81 ~2 ~30 ~83 ~4 ~30 glass
fill ~87 ~2 ~-1 ~89 ~4 ~-1 glass
fill ~87 ~2 ~30 ~89 ~4 ~30 glass
fill ~49 ~ ~20 ~49 ~2 ~21 air
fill ~53 ~ ~4 ~64 ~2 ~4 barrel[facing=north]
fill ~53 ~3 ~4 ~64 ~3 ~4 spruce_planks
summon minecraft:item_frame ~58 ~3 ~3 {Facing:2b,Fixed:1b,Item:{id:"minecraft:stone",count:1}}
summon minecraft:text_display ~59 ~4 ~3 {billboard:"center",text:{text:"PIEDRA",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~4 ~76 ~2 ~4 barrel[facing=north]
fill ~65 ~3 ~4 ~76 ~3 ~4 spruce_planks
summon minecraft:item_frame ~70 ~3 ~3 {Facing:2b,Fixed:1b,Item:{id:"minecraft:granite",count:1}}
summon minecraft:text_display ~71 ~4 ~3 {billboard:"center",text:{text:"ROCAS",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~4 ~88 ~2 ~4 barrel[facing=north]
fill ~77 ~3 ~4 ~88 ~3 ~4 spruce_planks
summon minecraft:item_frame ~82 ~3 ~3 {Facing:2b,Fixed:1b,Item:{id:"minecraft:cobbled_deepslate",count:1}}
summon minecraft:text_display ~83 ~4 ~3 {billboard:"center",text:{text:"DEEPSLATE",color:"yellow",bold:1b},background:1073741824}
fill ~53 ~ ~5 ~64 ~2 ~5 barrel[facing=south]
fill ~53 ~3 ~5 ~64 ~3 ~5 spruce_planks
summon minecraft:item_frame ~58 ~3 ~6 {Facing:3b,Fixed:1b,Item:{id:"minecraft:dirt",count:1}}
summon minecraft:text_display ~59 ~4 ~6 {billboard:"center",text:{text:"TIERRA",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~5 ~76 ~2 ~5 barrel[facing=south]
fill ~65 ~3 ~5 ~76 ~3 ~5 spruce_planks
summon minecraft:item_frame ~70 ~3 ~6 {Facing:3b,Fixed:1b,Item:{id:"minecraft:sand",count:1}}
summon minecraft:text_display ~71 ~4 ~6 {billboard:"center",text:{text:"ARENA Y GRAVA",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~5 ~88 ~2 ~5 barrel[facing=south]
fill ~77 ~3 ~5 ~88 ~3 ~5 spruce_planks
summon minecraft:item_frame ~82 ~3 ~6 {Facing:3b,Fixed:1b,Item:{id:"minecraft:oak_planks",count:1}}
summon minecraft:text_display ~83 ~4 ~6 {billboard:"center",text:{text:"MADERA",color:"yellow",bold:1b},background:1073741824}
fill ~52 ~ ~4 ~52 ~3 ~5 stripped_spruce_log
fill ~89 ~ ~4 ~89 ~3 ~5 stripped_spruce_log
fill ~53 ~ ~10 ~64 ~2 ~10 barrel[facing=north]
fill ~53 ~3 ~10 ~64 ~3 ~10 spruce_planks
summon minecraft:item_frame ~58 ~3 ~9 {Facing:2b,Fixed:1b,Item:{id:"minecraft:oak_log",count:1}}
summon minecraft:text_display ~59 ~4 ~9 {billboard:"center",text:{text:"TRONCOS",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~10 ~76 ~2 ~10 barrel[facing=north]
fill ~65 ~3 ~10 ~76 ~3 ~10 spruce_planks
summon minecraft:item_frame ~70 ~3 ~9 {Facing:2b,Fixed:1b,Item:{id:"minecraft:glass",count:1}}
summon minecraft:text_display ~71 ~4 ~9 {billboard:"center",text:{text:"VIDRIO",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~10 ~88 ~2 ~10 barrel[facing=north]
fill ~77 ~3 ~10 ~88 ~3 ~10 spruce_planks
summon minecraft:item_frame ~82 ~3 ~9 {Facing:2b,Fixed:1b,Item:{id:"minecraft:white_wool",count:1}}
summon minecraft:text_display ~83 ~4 ~9 {billboard:"center",text:{text:"LANA Y TINTES",color:"yellow",bold:1b},background:1073741824}
fill ~53 ~ ~11 ~64 ~2 ~11 barrel[facing=south]
fill ~53 ~3 ~11 ~64 ~3 ~11 spruce_planks
summon minecraft:item_frame ~58 ~3 ~12 {Facing:3b,Fixed:1b,Item:{id:"minecraft:white_concrete",count:1}}
summon minecraft:text_display ~59 ~4 ~12 {billboard:"center",text:{text:"CONCRETO",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~11 ~76 ~2 ~11 barrel[facing=south]
fill ~65 ~3 ~11 ~76 ~3 ~11 spruce_planks
summon minecraft:item_frame ~70 ~3 ~12 {Facing:3b,Fixed:1b,Item:{id:"minecraft:diamond",count:1}}
summon minecraft:text_display ~71 ~4 ~12 {billboard:"center",text:{text:"MINERALES",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~11 ~88 ~2 ~11 barrel[facing=south]
fill ~77 ~3 ~11 ~88 ~3 ~11 spruce_planks
summon minecraft:item_frame ~82 ~3 ~12 {Facing:3b,Fixed:1b,Item:{id:"minecraft:iron_ingot",count:1}}
summon minecraft:text_display ~83 ~4 ~12 {billboard:"center",text:{text:"LINGOTES",color:"yellow",bold:1b},background:1073741824}
fill ~52 ~ ~10 ~52 ~3 ~11 stripped_spruce_log
fill ~89 ~ ~10 ~89 ~3 ~11 stripped_spruce_log
fill ~53 ~ ~16 ~64 ~2 ~16 barrel[facing=north]
fill ~53 ~3 ~16 ~64 ~3 ~16 spruce_planks
summon minecraft:item_frame ~58 ~3 ~15 {Facing:2b,Fixed:1b,Item:{id:"minecraft:redstone",count:1}}
summon minecraft:text_display ~59 ~4 ~15 {billboard:"center",text:{text:"REDSTONE",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~16 ~76 ~2 ~16 barrel[facing=north]
fill ~65 ~3 ~16 ~76 ~3 ~16 spruce_planks
summon minecraft:item_frame ~70 ~3 ~15 {Facing:2b,Fixed:1b,Item:{id:"minecraft:piston",count:1}}
summon minecraft:text_display ~71 ~4 ~15 {billboard:"center",text:{text:"MECANISMOS",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~16 ~88 ~2 ~16 barrel[facing=north]
fill ~77 ~3 ~16 ~88 ~3 ~16 spruce_planks
summon minecraft:item_frame ~82 ~3 ~15 {Facing:2b,Fixed:1b,Item:{id:"minecraft:bread",count:1}}
summon minecraft:text_display ~83 ~4 ~15 {billboard:"center",text:{text:"COMIDA",color:"yellow",bold:1b},background:1073741824}
fill ~53 ~ ~17 ~64 ~2 ~17 barrel[facing=south]
fill ~53 ~3 ~17 ~64 ~3 ~17 spruce_planks
summon minecraft:item_frame ~58 ~3 ~18 {Facing:3b,Fixed:1b,Item:{id:"minecraft:wheat",count:1}}
summon minecraft:text_display ~59 ~4 ~18 {billboard:"center",text:{text:"CULTIVOS",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~17 ~76 ~2 ~17 barrel[facing=south]
fill ~65 ~3 ~17 ~76 ~3 ~17 spruce_planks
summon minecraft:item_frame ~70 ~3 ~18 {Facing:3b,Fixed:1b,Item:{id:"minecraft:bone",count:1}}
summon minecraft:text_display ~71 ~4 ~18 {billboard:"center",text:{text:"DROPS DE MOBS",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~17 ~88 ~2 ~17 barrel[facing=south]
fill ~77 ~3 ~17 ~88 ~3 ~17 spruce_planks
summon minecraft:item_frame ~82 ~3 ~18 {Facing:3b,Fixed:1b,Item:{id:"minecraft:ender_pearl",count:1}}
summon minecraft:text_display ~83 ~4 ~18 {billboard:"center",text:{text:"RAROS DE MOBS",color:"yellow",bold:1b},background:1073741824}
fill ~52 ~ ~16 ~52 ~3 ~17 stripped_spruce_log
fill ~89 ~ ~16 ~89 ~3 ~17 stripped_spruce_log
fill ~53 ~ ~22 ~64 ~2 ~22 barrel[facing=north]
fill ~53 ~3 ~22 ~64 ~3 ~22 spruce_planks
summon minecraft:item_frame ~58 ~3 ~21 {Facing:2b,Fixed:1b,Item:{id:"minecraft:diamond_pickaxe",count:1}}
summon minecraft:text_display ~59 ~4 ~21 {billboard:"center",text:{text:"HERRAMIENTAS",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~22 ~76 ~2 ~22 barrel[facing=north]
fill ~65 ~3 ~22 ~76 ~3 ~22 spruce_planks
summon minecraft:item_frame ~70 ~3 ~21 {Facing:2b,Fixed:1b,Item:{id:"minecraft:diamond_sword",count:1}}
summon minecraft:text_display ~71 ~4 ~21 {billboard:"center",text:{text:"ARMAS",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~22 ~88 ~2 ~22 barrel[facing=north]
fill ~77 ~3 ~22 ~88 ~3 ~22 spruce_planks
summon minecraft:item_frame ~82 ~3 ~21 {Facing:2b,Fixed:1b,Item:{id:"minecraft:diamond_chestplate",count:1}}
summon minecraft:text_display ~83 ~4 ~21 {billboard:"center",text:{text:"ARMADURAS",color:"yellow",bold:1b},background:1073741824}
fill ~53 ~ ~23 ~64 ~2 ~23 barrel[facing=south]
fill ~53 ~3 ~23 ~64 ~3 ~23 spruce_planks
summon minecraft:item_frame ~58 ~3 ~24 {Facing:3b,Fixed:1b,Item:{id:"minecraft:brewing_stand",count:1}}
summon minecraft:text_display ~59 ~4 ~24 {billboard:"center",text:{text:"POCIONES",color:"yellow",bold:1b},background:1073741824}
fill ~65 ~ ~23 ~76 ~2 ~23 barrel[facing=south]
fill ~65 ~3 ~23 ~76 ~3 ~23 spruce_planks
summon minecraft:item_frame ~70 ~3 ~24 {Facing:3b,Fixed:1b,Item:{id:"minecraft:enchanted_book",count:1}}
summon minecraft:text_display ~71 ~4 ~24 {billboard:"center",text:{text:"LIBROS",color:"yellow",bold:1b},background:1073741824}
fill ~77 ~ ~23 ~88 ~2 ~23 barrel[facing=south]
fill ~77 ~3 ~23 ~88 ~3 ~23 spruce_planks
summon minecraft:item_frame ~82 ~3 ~24 {Facing:3b,Fixed:1b,Item:{id:"minecraft:netherrack",count:1}}
summon minecraft:text_display ~83 ~4 ~24 {billboard:"center",text:{text:"NETHER Y END",color:"yellow",bold:1b},background:1073741824}
fill ~52 ~ ~22 ~52 ~3 ~23 stripped_spruce_log
fill ~89 ~ ~22 ~89 ~3 ~23 stripped_spruce_log
setblock ~54 ~6 ~2 lantern[hanging=true]
setblock ~54 ~6 ~8 lantern[hanging=true]
setblock ~54 ~6 ~14 lantern[hanging=true]
setblock ~54 ~6 ~20 lantern[hanging=true]
setblock ~54 ~6 ~26 lantern[hanging=true]
setblock ~60 ~6 ~2 lantern[hanging=true]
setblock ~60 ~6 ~8 lantern[hanging=true]
setblock ~60 ~6 ~14 lantern[hanging=true]
setblock ~60 ~6 ~20 lantern[hanging=true]
setblock ~60 ~6 ~26 lantern[hanging=true]
setblock ~66 ~6 ~2 lantern[hanging=true]
setblock ~66 ~6 ~8 lantern[hanging=true]
setblock ~66 ~6 ~14 lantern[hanging=true]
setblock ~66 ~6 ~20 lantern[hanging=true]
setblock ~66 ~6 ~26 lantern[hanging=true]
setblock ~72 ~6 ~2 lantern[hanging=true]
setblock ~72 ~6 ~8 lantern[hanging=true]
setblock ~72 ~6 ~14 lantern[hanging=true]
setblock ~72 ~6 ~20 lantern[hanging=true]
setblock ~72 ~6 ~26 lantern[hanging=true]
setblock ~78 ~6 ~2 lantern[hanging=true]
setblock ~78 ~6 ~8 lantern[hanging=true]
setblock ~78 ~6 ~14 lantern[hanging=true]
setblock ~78 ~6 ~20 lantern[hanging=true]
setblock ~78 ~6 ~26 lantern[hanging=true]
setblock ~84 ~6 ~2 lantern[hanging=true]
setblock ~84 ~6 ~8 lantern[hanging=true]
setblock ~84 ~6 ~14 lantern[hanging=true]
setblock ~84 ~6 ~20 lantern[hanging=true]
setblock ~84 ~6 ~26 lantern[hanging=true]
setblock ~90 ~6 ~2 lantern[hanging=true]
setblock ~90 ~6 ~8 lantern[hanging=true]
setblock ~90 ~6 ~14 lantern[hanging=true]
setblock ~90 ~6 ~20 lantern[hanging=true]
setblock ~90 ~6 ~26 lantern[hanging=true]
setblock ~91 ~ ~3 crafting_table
setblock ~91 ~ ~7 ender_chest[facing=west]
setblock ~91 ~ ~11 anvil[facing=north]
setblock ~91 ~ ~15 stonecutter[facing=west]
setblock ~91 ~ ~19 smithing_table
setblock ~91 ~ ~23 cartography_table
summon minecraft:text_display ~48 ~4 ~20 {billboard:"center",text:{text:"SALON DE COFRES\n864 barriles en 24 secciones",color:"gold",bold:1b},background:1073741824}
