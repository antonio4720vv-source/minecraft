execute at @e[type=minecraft:marker,tag=granjas_f3,limit=1] run function granjas:_f3_4b
schedule function granjas:_f3_5 3s replace
