kill @e[type=minecraft:marker,tag=granjas_f1]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_f1"]}
function granjas:_f1_0
