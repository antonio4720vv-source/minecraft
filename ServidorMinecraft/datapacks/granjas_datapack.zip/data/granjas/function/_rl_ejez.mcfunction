scoreboard players set #seg rieles 1
scoreboard players operation #rem rieles = #remz rieles
scoreboard players set #ult rieles 1
scoreboard players set #edx rieles 0
scoreboard players operation #edz rieles = #sz rieles
scoreboard players set #eox rieles 1
scoreboard players set #eoz rieles 0
data modify storage granjas:riel p merge value {shape:"north_south",pshape:"north_south"}
execute if score #sz rieles matches 1 run data modify storage granjas:riel p merge value {up:"ascending_south",down:"ascending_north"}
execute if score #sz rieles matches -1 run data modify storage granjas:riel p merge value {up:"ascending_north",down:"ascending_south"}
execute store result storage granjas:riel p.dx int 1 run scoreboard players get #edx rieles
execute store result storage granjas:riel p.dz int 1 run scoreboard players get #edz rieles
execute store result storage granjas:riel p.ox int 1 run scoreboard players get #eox rieles
execute store result storage granjas:riel p.oz int 1 run scoreboard players get #eoz rieles
execute store result storage granjas:riel p.fbx int -32 run scoreboard players get #edx rieles
execute store result storage granjas:riel p.fbz int -32 run scoreboard players get #edz rieles
