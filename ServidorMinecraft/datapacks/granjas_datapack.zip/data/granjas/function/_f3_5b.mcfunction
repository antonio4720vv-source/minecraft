tellraw @a {"text":"[Fase 3] Caballeriza y torre de elitros...","color":"yellow"}
execute positioned ~75 ~ ~42 run function granjas:_caballeriza
execute positioned ~112 ~ ~22 run function granjas:_torre_elitros
