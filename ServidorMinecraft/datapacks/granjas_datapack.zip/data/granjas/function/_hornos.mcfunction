tellraw @s {"text":"Construyendo HORNOS automaticos...","color":"yellow"}
fill ~-3 ~-1 ~-3 ~9 ~5 ~3 air
fill ~-3 ~-1 ~-3 ~9 ~-1 ~3 stone_bricks
fill ~-1 ~ ~-2 ~8 ~3 ~-1 stone_bricks
fill ~8 ~ ~-2 ~8 ~4 ~ stone_bricks
fill ~ ~ ~ ~7 ~ ~ hopper[facing=west]
setblock ~-1 ~ ~ barrel[facing=west]
fill ~ ~1 ~ ~7 ~1 ~ furnace[facing=south]
fill ~ ~2 ~ ~7 ~2 ~ hopper[facing=down]
fill ~-1 ~3 ~ ~7 ~3 ~ hopper[facing=east]
setblock ~-1 ~4 ~ barrel[facing=west]
fill ~ ~1 ~-1 ~7 ~1 ~-1 hopper[facing=south]
fill ~-1 ~2 ~-1 ~7 ~2 ~-1 hopper[facing=east]
setblock ~-1 ~3 ~-1 barrel[facing=west]
setblock ~-1 ~1 ~ stone_bricks
setblock ~-1 ~2 ~ stone_bricks
setblock ~-1 ~1 ~-1 stone_bricks
setblock ~-1 ~ ~-1 stone_bricks
summon minecraft:text_display ~-2 ~5 ~ {billboard:"center",text:{text:"HORNOS: arriba = lo que quieres cocinar\nmedio = carbon   abajo = lo cocinado",color:"gold",bold:1b},background:1073741824}
tellraw @s {"text":"Hornos listos (8). Desde el lado oeste: cofre de ARRIBA = minerales o comida cruda, cofre del MEDIO = carbon, cofre de ABAJO = todo cocinado.","color":"green"}
