tellraw @a {"text":"[Fase 1] Sala de comercio...","color":"yellow"}
fill ~33 ~15 ~3 ~65 ~15 ~16 stone_bricks
setblock ~53 ~15 ~9 ladder[facing=west]
fill ~33 ~16 ~3 ~65 ~19 ~16 air
fill ~33 ~16 ~3 ~65 ~19 ~3 stone_bricks
fill ~33 ~16 ~16 ~65 ~19 ~16 stone_bricks
fill ~33 ~16 ~3 ~33 ~19 ~16 stone_bricks
fill ~65 ~16 ~3 ~65 ~19 ~16 stone_bricks
fill ~35 ~17 ~16 ~36 ~18 ~16 glass
fill ~39 ~17 ~16 ~40 ~18 ~16 glass
fill ~43 ~17 ~16 ~44 ~18 ~16 glass
fill ~47 ~17 ~16 ~48 ~18 ~16 glass
fill ~51 ~17 ~16 ~52 ~18 ~16 glass
fill ~55 ~17 ~16 ~56 ~18 ~16 glass
fill ~59 ~17 ~16 ~60 ~18 ~16 glass
fill ~63 ~17 ~16 ~64 ~18 ~16 glass
fill ~33 ~16 ~3 ~33 ~19 ~3 stripped_dark_oak_log
fill ~33 ~16 ~16 ~33 ~19 ~16 stripped_dark_oak_log
fill ~39 ~16 ~3 ~39 ~19 ~3 stripped_dark_oak_log
fill ~39 ~16 ~16 ~39 ~19 ~16 stripped_dark_oak_log
fill ~45 ~16 ~3 ~45 ~19 ~3 stripped_dark_oak_log
fill ~45 ~16 ~16 ~45 ~19 ~16 stripped_dark_oak_log
fill ~51 ~16 ~3 ~51 ~19 ~3 stripped_dark_oak_log
fill ~51 ~16 ~16 ~51 ~19 ~16 stripped_dark_oak_log
fill ~57 ~16 ~3 ~57 ~19 ~3 stripped_dark_oak_log
fill ~57 ~16 ~16 ~57 ~19 ~16 stripped_dark_oak_log
fill ~63 ~16 ~3 ~63 ~19 ~3 stripped_dark_oak_log
fill ~63 ~16 ~16 ~63 ~19 ~16 stripped_dark_oak_log
fill ~33 ~20 ~3 ~65 ~20 ~16 dark_oak_planks
fill ~34 ~16 ~4 ~64 ~18 ~6 stone_bricks
setblock ~35 ~16 ~4 blast_furnace
fill ~35 ~16 ~5 ~35 ~17 ~5 air
setblock ~35 ~17 ~6 air
setblock ~35 ~18 ~6 glowstone
summon minecraft:villager ~35 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Armero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:armorer",level:1,type:"minecraft:plains"}}
setblock ~37 ~16 ~4 smoker
fill ~37 ~16 ~5 ~37 ~17 ~5 air
setblock ~37 ~17 ~6 air
setblock ~37 ~18 ~6 glowstone
summon minecraft:villager ~37 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Carnicero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:butcher",level:1,type:"minecraft:plains"}}
setblock ~39 ~16 ~4 cartography_table
fill ~39 ~16 ~5 ~39 ~17 ~5 air
setblock ~39 ~17 ~6 air
setblock ~39 ~18 ~6 glowstone
summon minecraft:villager ~39 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Cartografo",CustomNameVisible:1b,VillagerData:{profession:"minecraft:cartographer",level:1,type:"minecraft:plains"}}
setblock ~41 ~16 ~4 brewing_stand
fill ~41 ~16 ~5 ~41 ~17 ~5 air
setblock ~41 ~17 ~6 air
setblock ~41 ~18 ~6 glowstone
summon minecraft:villager ~41 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Clerigo",CustomNameVisible:1b,VillagerData:{profession:"minecraft:cleric",level:1,type:"minecraft:plains"}}
setblock ~43 ~16 ~4 composter
fill ~43 ~16 ~5 ~43 ~17 ~5 air
setblock ~43 ~17 ~6 air
setblock ~43 ~18 ~6 glowstone
summon minecraft:villager ~43 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Granjero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:farmer",level:1,type:"minecraft:plains"}}
setblock ~45 ~16 ~4 barrel
fill ~45 ~16 ~5 ~45 ~17 ~5 air
setblock ~45 ~17 ~6 air
setblock ~45 ~18 ~6 glowstone
summon minecraft:villager ~45 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Pescador",CustomNameVisible:1b,VillagerData:{profession:"minecraft:fisherman",level:1,type:"minecraft:plains"}}
setblock ~47 ~16 ~4 fletching_table
fill ~47 ~16 ~5 ~47 ~17 ~5 air
setblock ~47 ~17 ~6 air
setblock ~47 ~18 ~6 glowstone
summon minecraft:villager ~47 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Flechero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:fletcher",level:1,type:"minecraft:plains"}}
setblock ~49 ~16 ~4 cauldron
fill ~49 ~16 ~5 ~49 ~17 ~5 air
setblock ~49 ~17 ~6 air
setblock ~49 ~18 ~6 glowstone
summon minecraft:villager ~49 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Peletero",CustomNameVisible:1b,VillagerData:{profession:"minecraft:leatherworker",level:1,type:"minecraft:plains"}}
setblock ~51 ~16 ~4 lectern
fill ~51 ~16 ~5 ~51 ~17 ~5 air
setblock ~51 ~17 ~6 air
setblock ~51 ~18 ~6 glowstone
summon minecraft:villager ~51 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 1",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
setblock ~53 ~16 ~4 lectern
fill ~53 ~16 ~5 ~53 ~17 ~5 air
setblock ~53 ~17 ~6 air
setblock ~53 ~18 ~6 glowstone
summon minecraft:villager ~53 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 2",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
setblock ~55 ~16 ~4 lectern
fill ~55 ~16 ~5 ~55 ~17 ~5 air
setblock ~55 ~17 ~6 air
setblock ~55 ~18 ~6 glowstone
summon minecraft:villager ~55 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Bibliotecario 3",CustomNameVisible:1b,VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}
setblock ~57 ~16 ~4 stonecutter
fill ~57 ~16 ~5 ~57 ~17 ~5 air
setblock ~57 ~17 ~6 air
setblock ~57 ~18 ~6 glowstone
summon minecraft:villager ~57 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Albanil",CustomNameVisible:1b,VillagerData:{profession:"minecraft:mason",level:1,type:"minecraft:plains"}}
setblock ~59 ~16 ~4 loom
fill ~59 ~16 ~5 ~59 ~17 ~5 air
setblock ~59 ~17 ~6 air
setblock ~59 ~18 ~6 glowstone
summon minecraft:villager ~59 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Pastor",CustomNameVisible:1b,VillagerData:{profession:"minecraft:shepherd",level:1,type:"minecraft:plains"}}
setblock ~61 ~16 ~4 smithing_table
fill ~61 ~16 ~5 ~61 ~17 ~5 air
setblock ~61 ~17 ~6 air
setblock ~61 ~18 ~6 glowstone
summon minecraft:villager ~61 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Herrero de herramientas",CustomNameVisible:1b,VillagerData:{profession:"minecraft:toolsmith",level:1,type:"minecraft:plains"}}
setblock ~63 ~16 ~4 grindstone
fill ~63 ~16 ~5 ~63 ~17 ~5 air
setblock ~63 ~17 ~6 air
setblock ~63 ~18 ~6 glowstone
summon minecraft:villager ~63 ~16 ~5 {PersistenceRequired:1b,Xp:1,CustomName:"Herrero de armas",CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:1,type:"minecraft:plains"}}
fill ~34 ~15 ~7 ~64 ~15 ~15 polished_andesite
fill ~36 ~16 ~10 ~62 ~16 ~12 red_carpet
setblock ~37 ~19 ~9 lantern[hanging=true]
setblock ~37 ~19 ~13 lantern[hanging=true]
setblock ~43 ~19 ~9 lantern[hanging=true]
setblock ~43 ~19 ~13 lantern[hanging=true]
setblock ~49 ~19 ~9 lantern[hanging=true]
setblock ~49 ~19 ~13 lantern[hanging=true]
setblock ~55 ~19 ~9 lantern[hanging=true]
setblock ~55 ~19 ~13 lantern[hanging=true]
setblock ~61 ~19 ~9 lantern[hanging=true]
setblock ~61 ~19 ~13 lantern[hanging=true]
setblock ~54 ~16 ~9 stone_bricks
setblock ~53 ~16 ~9 ladder[facing=west]
summon minecraft:text_display ~49 ~19 ~11 {billboard:"center",text:{text:"SALA DE COMERCIO\n15 aldeanos (3 bibliotecarios)",color:"aqua",bold:1b},background:1073741824}
function granjas:respaldo_on
tellraw @a {"text":"[Fase 1] LISTA! Torre de hierro (5 granjas, barriles en la planta baja, puerta oeste) y edificio de aldeanos (4 criaderos + sala de comercio arriba). Los golems empiezan cuando los aldeanos duermen la primera noche.","color":"green"}
