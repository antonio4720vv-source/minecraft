tellraw @a {"text":"Montana con la casa y caballeriza...","color":"yellow"}
execute positioned ~-60 ~ ~70 run function granjas:_montana
execute positioned ~-72 ~ ~-12 run function granjas:_caballeriza
