execute unless entity @e[type=minecraft:marker,tag=granjas_f4,limit=1] run tellraw @s {"text":"Primero construye la Fase 4 (/function granjas:fase4): ahi esta la estacion central.","color":"red"}
execute if entity @e[type=minecraft:marker,tag=granjas_f4,limit=1] run function granjas:_rl_start
