tellraw @s {"text":"Construyendo el tren circular con estaciones...","color":"yellow"}
fill ~-45 ~ ~-40 ~45 ~2 ~-40 air
fill ~-45 ~-1 ~-40 ~45 ~-1 ~-40 stone_bricks
fill ~-45 ~ ~40 ~45 ~2 ~40 air
fill ~-45 ~-1 ~40 ~45 ~-1 ~40 stone_bricks
fill ~-45 ~ ~-40 ~-45 ~2 ~40 air
fill ~-45 ~-1 ~-40 ~-45 ~-1 ~40 stone_bricks
fill ~45 ~ ~-40 ~45 ~2 ~40 air
fill ~45 ~-1 ~-40 ~45 ~-1 ~40 stone_bricks
fill ~-44 ~ ~-40 ~44 ~ ~-40 rail[shape=east_west]
fill ~-44 ~ ~40 ~44 ~ ~40 rail[shape=east_west]
fill ~-45 ~ ~-39 ~-45 ~ ~39 rail[shape=north_south]
fill ~45 ~ ~-39 ~45 ~ ~39 rail[shape=north_south]
setblock ~-45 ~ ~-40 rail[shape=south_east]
setblock ~45 ~ ~-40 rail[shape=south_west]
setblock ~45 ~ ~40 rail[shape=north_west]
setblock ~-45 ~ ~40 rail[shape=north_east]
setblock ~-37 ~-1 ~-40 redstone_block
setblock ~-37 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~-29 ~-1 ~-40 redstone_block
setblock ~-29 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~-21 ~-1 ~-40 redstone_block
setblock ~-21 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~-13 ~-1 ~-40 redstone_block
setblock ~-13 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~-5 ~-1 ~-40 redstone_block
setblock ~-5 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~11 ~-1 ~-40 redstone_block
setblock ~11 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~19 ~-1 ~-40 redstone_block
setblock ~19 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~35 ~-1 ~-40 redstone_block
setblock ~35 ~ ~-40 powered_rail[shape=east_west,powered=true]
setblock ~45 ~-1 ~-34 redstone_block
setblock ~45 ~ ~-34 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~-26 redstone_block
setblock ~45 ~ ~-26 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~-10 redstone_block
setblock ~45 ~ ~-10 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~-2 redstone_block
setblock ~45 ~ ~-2 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~6 redstone_block
setblock ~45 ~ ~6 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~14 redstone_block
setblock ~45 ~ ~14 powered_rail[shape=north_south,powered=true]
setblock ~45 ~-1 ~22 redstone_block
setblock ~45 ~ ~22 powered_rail[shape=north_south,powered=true]
setblock ~39 ~-1 ~40 redstone_block
setblock ~39 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~31 ~-1 ~40 redstone_block
setblock ~31 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~15 ~-1 ~40 redstone_block
setblock ~15 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~7 ~-1 ~40 redstone_block
setblock ~7 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~-17 ~-1 ~40 redstone_block
setblock ~-17 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~-25 ~-1 ~40 redstone_block
setblock ~-25 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~-41 ~-1 ~40 redstone_block
setblock ~-41 ~ ~40 powered_rail[shape=east_west,powered=true]
setblock ~-45 ~-1 ~36 redstone_block
setblock ~-45 ~ ~36 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~28 redstone_block
setblock ~-45 ~ ~28 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~20 redstone_block
setblock ~-45 ~ ~20 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~12 redstone_block
setblock ~-45 ~ ~12 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~-12 redstone_block
setblock ~-45 ~ ~-12 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~-20 redstone_block
setblock ~-45 ~ ~-20 powered_rail[shape=north_south,powered=true]
setblock ~-45 ~-1 ~-36 redstone_block
setblock ~-45 ~ ~-36 powered_rail[shape=north_south,powered=true]
setblock ~4 ~ ~-40 powered_rail[shape=east_west,powered=false]
setblock ~5 ~ ~-40 powered_rail[shape=east_west,powered=false]
setblock ~4 ~ ~-39 stone_bricks
setblock ~4 ~1 ~-39 stone_button[face=floor,facing=north]
setblock ~4 ~ ~-41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~4 ~3 ~-40 {billboard:"center",text:{text:"ESTACION: GRANJAS",color:"aqua",bold:1b},background:1073741824}
setblock ~28 ~ ~-40 powered_rail[shape=east_west,powered=false]
setblock ~29 ~ ~-40 powered_rail[shape=east_west,powered=false]
setblock ~28 ~ ~-39 stone_bricks
setblock ~28 ~1 ~-39 stone_button[face=floor,facing=north]
setblock ~28 ~ ~-41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~28 ~3 ~-40 {billboard:"center",text:{text:"ESTACION: PORTAL DEL END",color:"aqua",bold:1b},background:1073741824}
setblock ~45 ~ ~-20 powered_rail[shape=north_south,powered=false]
setblock ~45 ~ ~-19 powered_rail[shape=north_south,powered=false]
setblock ~44 ~ ~-20 stone_bricks
setblock ~44 ~1 ~-20 stone_button[face=floor,facing=north]
setblock ~46 ~ ~-20 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~45 ~3 ~-20 {billboard:"center",text:{text:"ESTACION: CASA EN EL ARBOL",color:"aqua",bold:1b},background:1073741824}
setblock ~45 ~ ~30 powered_rail[shape=north_south,powered=false]
setblock ~45 ~ ~31 powered_rail[shape=north_south,powered=false]
setblock ~44 ~ ~30 stone_bricks
setblock ~44 ~1 ~30 stone_button[face=floor,facing=north]
setblock ~46 ~ ~30 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~45 ~3 ~30 {billboard:"center",text:{text:"ESTACION: TORRE DE ELITROS",color:"aqua",bold:1b},background:1073741824}
setblock ~23 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~24 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~23 ~ ~39 stone_bricks
setblock ~23 ~1 ~39 stone_button[face=floor,facing=north]
setblock ~23 ~ ~41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~23 ~3 ~40 {billboard:"center",text:{text:"ESTACION: CUARTO DE COFRES",color:"aqua",bold:1b},background:1073741824}
setblock ~2 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~3 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~2 ~ ~39 stone_bricks
setblock ~2 ~1 ~39 stone_button[face=floor,facing=north]
setblock ~2 ~ ~41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~2 ~3 ~40 {billboard:"center",text:{text:"ESTACION: PLAZA",color:"aqua",bold:1b},background:1073741824}
setblock ~-12 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~-11 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~-12 ~ ~39 stone_bricks
setblock ~-12 ~1 ~39 stone_button[face=floor,facing=north]
setblock ~-12 ~ ~41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~-12 ~3 ~40 {billboard:"center",text:{text:"ESTACION: ANIMALES",color:"aqua",bold:1b},background:1073741824}
setblock ~-36 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~-35 ~ ~40 powered_rail[shape=east_west,powered=false]
setblock ~-36 ~ ~39 stone_bricks
setblock ~-36 ~1 ~39 stone_button[face=floor,facing=north]
setblock ~-36 ~ ~41 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~-36 ~3 ~40 {billboard:"center",text:{text:"ESTACION: CASA EN LA MONTANA",color:"aqua",bold:1b},background:1073741824}
setblock ~-45 ~ ~ powered_rail[shape=north_south,powered=false]
setblock ~-45 ~ ~1 powered_rail[shape=north_south,powered=false]
setblock ~-44 ~ ~ stone_bricks
setblock ~-44 ~1 ~ stone_button[face=floor,facing=north]
setblock ~-46 ~ ~ barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~-45 ~3 ~ {billboard:"center",text:{text:"ESTACION: CABALLERIZA",color:"aqua",bold:1b},background:1073741824}
setblock ~-45 ~ ~-30 powered_rail[shape=north_south,powered=false]
setblock ~-45 ~ ~-29 powered_rail[shape=north_south,powered=false]
setblock ~-44 ~ ~-30 stone_bricks
setblock ~-44 ~1 ~-30 stone_button[face=floor,facing=north]
setblock ~-46 ~ ~-30 barrel[facing=up]{Items:[{Slot:0b,id:"minecraft:minecart",count:8}]}
summon minecraft:text_display ~-45 ~3 ~-30 {billboard:"center",text:{text:"ESTACION: GRANJA DE MOBS",color:"aqua",bold:1b},background:1073741824}
