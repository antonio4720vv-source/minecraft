tellraw @a {"text":"[Fase 3] Casa grande en la cima y casa en el arbol...","color":"yellow"}
execute positioned ~35 ~ ~40 run function granjas:_montana_casa
execute positioned ~85 ~ ~24 run function granjas:_arbol
