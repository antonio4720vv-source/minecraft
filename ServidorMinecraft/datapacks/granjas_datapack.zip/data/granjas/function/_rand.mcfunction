setblock ~ ~ ~ scaffolding
scoreboard players remove #c rieles 1
execute if score #c rieles matches ..0 run fill ~ ~1 ~ ~ ~2 ~ air
execute if score #c rieles matches 1.. positioned ~ ~1 ~ run function granjas:_rand
