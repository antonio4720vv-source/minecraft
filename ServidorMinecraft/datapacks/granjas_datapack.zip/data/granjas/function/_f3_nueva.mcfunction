kill @e[type=minecraft:marker,tag=granjas_f3]
summon minecraft:marker ~ ~ ~ {Tags:["granjas_f3"]}
function granjas:_f3_0
