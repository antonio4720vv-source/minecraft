scoreboard players set #on granjas 0
tellraw @a {"text":"Modo respaldo DESACTIVADO: ahora las granjas solo funcionan con sus mecanismos normales.","color":"yellow"}
