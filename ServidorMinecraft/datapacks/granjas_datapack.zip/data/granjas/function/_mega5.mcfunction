execute at @e[type=minecraft:marker,tag=granjas_mega,limit=1] run function granjas:_mega5b
schedule function granjas:_mega6 4s replace
